<?php
ini_set ( "display_errors", "1" );
session_start ();
require_once ($_SERVER ['DOCUMENT_ROOT'] . '/mvc/library/constant.path.php');
require_once (LIBRARY_ROOT . 'common.inc.php');
require_once (LANGUAGE_ROOT . 'lang.en.php');
require_once (CONFIG_ROOT . 'constants.php');
ini_set ( "log_errors", 1 );
ini_set ( "error_log", "config/php-error.log" );
if (isset ( $_REQUEST ['controller'] ) && ! empty ( $_REQUEST ['controller'] )) {
	
	$controller = $_REQUEST ['controller'];

} else {
	$controller = 'main'; // default controller
}
if (isset ( $_REQUEST ['function'] ) && ! empty ( $_REQUEST ['function'] )) {
	$function = $_REQUEST ['function'];
	$url = explode ( "/", @$_REQUEST ['function'] );
	if (count ( $url ) > 1) {
		$controller = $url [0];
		$function = $url [1];
	}
} else {
	$function = 'home'; // default function
}
$fn = SITE_ROOT . 'controller/' . $controller . 'Controller.php';
if (file_exists ( $fn )) {
	require_once ($fn);
	$controllerClass = $controller . 'Controller';
	if (! method_exists ( $controllerClass, $function )) {
		header ( "location:" . SITE_PATH . "404.php?param=functionError" );
		die ( $function . ' function not found' );
	}
	$obj = new $controllerClass ();
	$obj->$function ();
} else {
	header ( "location:" . SITE_PATH . "404.php?param=controllerError" );
	die ( $controller . ' controller not found' );
}

?>