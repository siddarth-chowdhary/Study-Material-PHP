<?php
class mainController extends common{
/*uncomment the last line to see the working*/
	function home() {
   		$this->loadView("header");
		$this->loadView("main_reg_login");
		$this->loadView("main_body");
		$this->loadView("main_footer");
		//header('Location: index.php?controller=main&function=test');
	}
/*this is an example of model class included and result displayed on the page*/
	function test(){
			$arr = $this->loadModel('createTest','getTestCategories',array('id'=>1));
			$this->loadView("main_body",$arr);
	}
	
}
