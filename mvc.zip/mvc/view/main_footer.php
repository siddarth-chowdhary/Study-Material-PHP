<?php 
echo 'this is footer<br>';

