<?php 
echo 'this is body<br><pre>';
print_r($arrData);
