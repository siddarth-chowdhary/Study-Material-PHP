<html>
	<head>
		<title>NO!</title>
		</head>
	<body>
		<h2>
		<tt>
		There is nothing here..
		Go back..
		<br/>
		<a href="index.php">Or Move to index Page</a>
		</tt>
		</h2>
	</body>
</html> 

