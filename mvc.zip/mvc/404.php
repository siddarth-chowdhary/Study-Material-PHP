 ERROR BOy
 <style type="text/css">
 body {
 		background-image: url("http:/test_scheduler.com/images/404.jpg");
 	}
 </style>	
 	<html>
 	<head>
 		<title>TestScheduler</title>
 	</head>
 	<body>
<?php
 if($_REQUEST['param']=="controllerError") {
 	echo "ERROR Code e9999!<br/><br/> ";
 }
 else if($_REQUEST['param']=="functionError") {
 	echo "ERROR Code e9998!<br/><br/><br/><br/>";
 }
 else if($_REQUEST['param']=="internalMethodError") {
 	echo "ERROR Code e9997!<br/><br/>";
 } else {

 }
 ?> <br/><br/><br/><br/><br/><br/><br/><br/>
FIND WAY HOME BY CLICKING
<a href="http://test_scheduler.com">HOME</a>
 	</body>
 	</html>