<?php
include MODEL_PATH . "db_connect.php";
class createTestModel extends dbConnectModel {
	function __construct() {
		parent::__construct ();
	}
	
/*write functions like these to use models*/
	public function getTestCategories($arrArgs) {
		try {
			$categoryArray = array ();
			$data ['tables'] = 'category';
			$data ['columns'] = array (
					'name',
					'id' 
			);
			$data ['conditions'] = array (
					'created_by' => $arrArgs ['id'] 
			);
			
			$result = $this->_db->select ( $data );
			
			while ( $row = $result->fetch ( PDO::FETCH_ASSOC ) ) {
				$categoryArray ['category_name'] [] = $row ['name'];
				$categoryArray ['category_id'] [] = $row ['id'];
			}
			return $categoryArray;
		} catch ( Exception $e ) {
			$this->handleException ( $e->getMessage () );
		}
	}
	
}
