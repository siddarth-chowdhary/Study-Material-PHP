<?php
echo json_encode($_REQUEST);

