To make element editable via textarea just add `editable-textarea` attribute 
pointing to model in scope. You can also wrap content into `<pre>` tags to keep linebreaks.
Data can be submitted by *Ctrl + Enter*.