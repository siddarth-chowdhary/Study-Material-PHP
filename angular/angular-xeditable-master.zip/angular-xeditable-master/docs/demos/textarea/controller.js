app.controller('TextareaCtrl', function($scope) {
  $scope.user = {
    desc: 'Awesome user \ndescription!'
  };
});