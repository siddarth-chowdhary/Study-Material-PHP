app.controller('DevText', function($scope) {
  $scope.user = {
    name: 'awesome user'
  };  
});