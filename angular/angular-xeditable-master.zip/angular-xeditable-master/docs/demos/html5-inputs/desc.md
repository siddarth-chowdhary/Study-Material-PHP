Following HTML5 types are supported via `editable-xxx` directive:

* email
* tel
* number
* search
* range
* url
* color
* date
* datetime
* time
* month
* week

Please [check browser support](http://caniuse.com/) before using particular type in your project.