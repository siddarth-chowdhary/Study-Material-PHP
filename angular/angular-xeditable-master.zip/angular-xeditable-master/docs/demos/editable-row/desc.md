To create editable row in table you should place editable elements in cells with `e-form` attribute pointing to form's name. The form itself can appear later (e.g. in last column) but it will work. Don't forget to add 
`editable-form` attribute to the form. The form behavior is absolutely the same as described in
[Editable form section](#editable-form)
