To create editable select (dropdown) just set `editable-select` attribute pointing to model.
To pass dropdown options you should define `e-ng-options` attribute
that works like normal angular `ng-options` but is transfered to underlying `<select>` from original element.
