Just define `e-multiple` attribute that will be transfered to select as `multiple`.
