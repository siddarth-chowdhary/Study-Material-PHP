Just wrap the whole table into `<form>` tag with `editable-form` attribute.
Note that using `oncancel` hook allows you to revert all changes and put table into original state.