To load select options from remote url you should define `onshow` attribute pointing to scope function.
The result of function should be a $http promise, it allows to disable element while loading.