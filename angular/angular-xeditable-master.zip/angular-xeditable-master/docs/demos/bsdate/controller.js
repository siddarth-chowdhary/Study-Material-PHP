app.controller('BsdateCtrl', function($scope) {
  $scope.user = {
    dob: new Date(1984, 4, 15)
  };
});