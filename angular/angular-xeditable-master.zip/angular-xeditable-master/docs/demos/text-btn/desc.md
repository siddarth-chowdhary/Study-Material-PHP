To trigger edit-in-place by external button you should define `e-form` attribute.
Value of it is the name of variable to be created in scope that allows you to show / hide editor manually.
