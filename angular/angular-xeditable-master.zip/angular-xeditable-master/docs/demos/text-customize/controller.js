app.controller('TextCustomizeCtrl', function($scope) {
  $scope.user = {
    name: 'awesome user'
  };  
});