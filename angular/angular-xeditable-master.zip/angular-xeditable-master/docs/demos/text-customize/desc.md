To define attributes for input (e.g. `style` or `placeholder`) you can define them
on the original element with `e-*` prefix (e.g. `e-style` or `e-placeholder`). 
When input will appear these attributes will be transfered to it.
