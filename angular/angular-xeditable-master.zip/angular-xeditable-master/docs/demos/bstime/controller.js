app.controller('BstimeCtrl', function($scope) {
  $scope.user = {
    time: new Date(1984, 4, 15, 19, 20)
  };
});