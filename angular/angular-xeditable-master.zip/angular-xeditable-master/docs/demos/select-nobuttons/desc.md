To hide *Ok* and *Cancel* buttons you may set `buttons="no"` attribute.
New value will be saved automatically after change.