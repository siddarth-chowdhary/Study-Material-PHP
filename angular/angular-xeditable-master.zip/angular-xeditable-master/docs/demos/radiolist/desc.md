To create list of radios use `editable-radiolist` attribute pointing to model.
Also you should define `e-ng-options` attribute to set value and display items.
By default, radioboxes aligned *horizontally*. To align *vertically* just add following **CSS**:

    .editable-radiolist label {
      display: block;
    }
