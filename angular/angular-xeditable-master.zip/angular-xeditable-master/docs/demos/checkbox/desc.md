To make element editable via checkbox just add `editable-checkbox` attribute 
pointing to model in scope. Set `e-title` attribute to define text shown with checkbox.