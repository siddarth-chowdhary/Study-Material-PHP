app.controller('CheckboxCtrl', function($scope) {
  $scope.user = {
    remember: true
  };  
});