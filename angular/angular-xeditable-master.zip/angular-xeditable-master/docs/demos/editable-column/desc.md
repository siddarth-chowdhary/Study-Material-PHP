To create editable column in table you should place editable elements in cells with `e-form` attribute pointing to form's name. The form itself can appear in column header or footer. The form behavior is absolutely the same as described in
[Editable form section](#editable-form)
