<?php
ini_set('display_errors', 1);
require 'Slim/Slim.php';

require_once dirname(__FILE__) . '/lib/DbHandler.php';
require_once dirname(__FILE__) . '/lib/Common.php';

\Slim\Slim::registerAutoloader();

$db = new DbHandler('Testingq');
$common = new Common();

$app = new \Slim\Slim();

// GET route
$app->get('/',function () {
        $template = "Verses Application";
        echo $template;
    }
);

// POST route
$app->post('/post',function () {
        echo 'This is a POST route';
    }
);

// PUT route
$app->put('/put',function () {
        echo 'This is a PUT route';
    }
);

// PATCH route
$app->patch('/patch', function () {
    echo 'This is a PATCH route';
});

// DELETE route
$app->delete('/delete',
    function () {
        echo 'This is a DELETE route';
    }
);


// First example
$app->post('/first',function () use ($app) {
        global $db;
        global $common;

        //if some params are required
        // $common->verifyRequiredParams(array('task', 'status'));

        //get a param value
        // $task = $app->request->post('task');
        // echoRespnse(200, $task);
        
        // $common->echoRespnse(200, $db->test());
    }
);
//middleware example 1
$app->get('/second', 'test1','test2','test3','test4');
function test1() {echo 'test1';}function test2() {echo 'test2';}function test3() {echo 'test3';}function test4() {echo 'test4';}
//middleware example 2
$app->get('/third', 'authenticate', function() {
    echo ' third callback';
});
function authenticate() {echo 'authenticate function , ';}


/**
* If route is invalid / incorrect method type this will be the error
*/
$app->notFound(function () use ($app) {
    global $common;
    $response = array();
    $app = \Slim\Slim::getInstance();
    $response["error"] = true;
    $response["message"] = 'Resource Not Found / Incorrect Method Type.';
    $common->echoRespnse(400, $response);
    $app->stop();
});

$app->run();
