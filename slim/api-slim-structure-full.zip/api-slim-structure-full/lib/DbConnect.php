<?php

/**
 * Class handling database connection
 *
 * @author Siddarth Chowdhary
 */
class DbConnect {

    private $conn;

    function __construct($mode) {
        $filename = dirname(__FILE__) . '/../config/Config'.$mode.'.php';        
        if (file_exists($filename)) {
            include_once dirname(__FILE__) . '/../config/Config'.$mode.'.php';
        }
        else {
            throw new NotFoundException();
        }
    }

    /**
     * Establishing database connection
     * @return database connection handler
     */
    function connect() {

        try {
            $this->conn = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USERNAME, DB_PASSWORD);
        } catch(PDOException $e) {
            echo 'ERROR: ' . $e->getMessage();
        }

        return $this->conn;
    }

}

?>
