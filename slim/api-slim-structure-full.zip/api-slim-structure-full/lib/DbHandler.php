<?php

/**
 * Class to handle all db operations
 */
include "pdo/FluentPDO/FluentPDO.php";

class DbHandler {

    private $conn;
    private $dbObj;

    function __construct($mode) {
        require_once dirname(__FILE__) . '/DbConnect.php';
        $db = new DbConnect($mode);
        $this->conn = $db->connect($mode);
        $this->dbObj = new FluentPDO($this->conn);
    }
    /**
    * Example function
    */
    function test() {
        $query = $this->dbObj->from('user')->where('id > ?', 0)->orderBy('name');
        $query = $query->where('name = ?', 'siddarth');
        return $query->fetch();
    }

    
}
?>
