<?php
ini_set('display_errors', '1');
include "FluentPDO/FluentPDO.php";
/*connect to the database*/
$pdo = new PDO("mysql:dbname=test", "root", "tech");
$fpdo = new FluentPDO($pdo);


/*SELECT user.* FROM user WHERE id > ? AND name = ? ORDER BY name*/
$query = $fpdo->from('user')->where('id > ?', 0)->orderBy('name');
$query = $query->where('name = ?', 'siddarth');
echo $query->getQuery() . "\n";
p($query->getParameters());
p($query->fetch());


/*see all tests all the queries are defined there*/
function p($data) {
	echo "<pre>";
	print_r($data);
}
