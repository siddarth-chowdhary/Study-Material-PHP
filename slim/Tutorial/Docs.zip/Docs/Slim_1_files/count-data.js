var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"text":{"and":"and","comments":{"zero":"0 Comments","multiple":"<b>{num}<\/b> Comments","one":"<b>1<\/> Comment"}},"counts":[{"id":"http:\/\/www.androidhive.info\/2014\/01\/how-to-create-rest-api-for-android-app-using-php-slim-and-mysql-day-12-2\/","comments":47}]});
}