<?php
return array(
    'controllers'=>array(
         'invokables' => array(
             'Admin\Controller\Album' => 'Admin\Controller\AlbumController',
             'Admin\Controller\Index' => 'Admin\Controller\IndexController',
             'Admin\Controller\Login' => 'Admin\Controller\LoginController',
             'Admin\Controller\Country' => 'Admin\Controller\CountryController',
             'Admin\Controller\State' => 'Admin\Controller\StateController',
             //'Admin\Controller\LookupInterest' => 'Admin\Controller\LookupInterestController',
             'Admin\Controller\LookupStatus' => 'Admin\Controller\LookupStatusController',
             'Admin\Controller\User' => 'Admin\Controller\UserController',
             'Admin\Controller\UserContact' => 'Admin\Controller\UserContactController',
             'Admin\Controller\Project' => 'Admin\Controller\ProjectController',
             'Admin\Controller\ProjectImage' => 'Admin\Controller\ProjectImageController',
             'Admin\Controller\Chat' => 'Admin\Controller\ChatController',
             'Admin\Controller\ProfilePic' => 'Admin\Controller\ProfilePicController',
             'Admin\Controller\ContactPrivacySetting' => 'Admin\Controller\ContactPrivacySettingController',
         ),
    ),
    'router'=>array(
         'routes' => array(
             'home' => array(
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array(
                    'route'    => '/',
                    'defaults' => array(
                        'controller' => 'Admin\Controller\Login',
                        'action'     => 'index',
                    ),
                ),
            ),
            // The following is a route to simplify getting started creating
            // new controllers and actions without needing to create a new
            // module. Simply drop new controllers in, and you can access them
            // using the path /application/:controller/:action
            'admin'=>array(
                'type'    => 'Literal',
                'options' => array(
                    'route'    => '/admin',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Admin\Controller',
                        'controller'    => 'User',
                        'action'        => 'index',
                    ),
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'child' => array(
                        'type'    => 'Segment',
                        'options' => array(
                            'route'    => '[/][:controller][/][:action][/][:id]',
                            'constraints' => array(
                                'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'action'     => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'id'     => '[0-9]+',
                            ),
                            'defaults' => array(
                                /*'controller' => 'user',
                                'action'     => 'index',*/
                            ),
                        ),
                    ),
                ),
            ),
         ),
     ),
     'service_manager' => array(
        'abstract_factories' => array(
            'Zend\Cache\Service\StorageCacheAbstractServiceFactory',
            'Zend\Log\LoggerAbstractServiceFactory',
        ),
        'aliases' => array(
            'translator' => 'MvcTranslator',
        ),
        'factories' => array(
            'navigation' => 'Zend\Navigation\Service\DefaultNavigationFactory', // <-- add this to use zend navigation
        ),
    ),
    'translator' => array(
        'locale' => 'en_US',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
    // Placeholder for console routes
    'console' => array(
        'router' => array(
            'routes' => array(
            ),
        ),
    ),
    /*
    'view_manager'=>array(
         'template_path_stack' => array(
             'admin' => __DIR__ . '/../view',
         ),
     ),
     */
    'GMaps'=> array(
        'api_key' => 'AIzaSyAEE4aFeIHycLhVs0-M4ZUX9DPwjCo42qM',
    ),
    'smtp'=> array(
        'user_name'=>'pradeep.singh@clavax.com'
        ,'password'=>'cla12345'
        ,'port'=>'587'
        ,'host'=>'smtp.gmail.com'
        ,'ssl'=>'tls'
    ),
    'view_manager' => array(
        'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'layout/layout'           => __DIR__ . '/../view/layout/layout.phtml',
            'admin/index/index' => __DIR__ . '/../view/admin/index/index.phtml',
            'error/404'               => __DIR__ . '/../view/error/404.phtml',
            'error/index'             => __DIR__ . '/../view/error/index.phtml',
            'layout/admin' => __DIR__ . '/../view/layout/layout.phtml', // admin layout
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
        'module_layouts' => array(
           'Admin' => array(
                'default' => 'layout/layout',
                //'default' => 'layout/admin',
                //'index' =>'layout/outer'
             )

        ),
    ),
);
