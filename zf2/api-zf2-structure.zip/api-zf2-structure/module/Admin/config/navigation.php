<?php
return array(
    'navigation' => array(
        'default' => array(
            array(
                'label' => 'Home',
                'route' => 'home',
            ),
            /*array(
                'label' => 'Album',
                'route' => 'admin/child',
                'controller' => 'album',
                'action' => 'index',
                'pages' => array(
                    array(
                        'label' => 'Add',
                        'route' => 'admin/child',
                        'controller' => 'album',
                        'action' => 'add',
                    ),
                    array(
                        'label' => 'Edit',
                        'route' => 'admin/child',
                        'controller' => 'album',
                        'action' => 'edit',
                    ),
                    array(
                        'label' => 'Delete',
                        'route' => 'admin/child',
                        'controller' => 'album',
                        'action' => 'delete',
                    ),
                ),
            ),*/
             array(
                'label' => 'User',
                'route' => 'admin/child',
                'controller' => 'user',
                'action' => 'index',
                'pages' => array(
                    array(
                        'label' => 'Add',
                        'route' => 'admin/child',
                        'controller' => 'user',
                        'action' => 'add',
                    ),
                    array(
                        'label' => 'Add',
                        'route' => 'admin/child',
                        'controller' => 'user',
                        'action' => 'edit',
                        'visible' => 0, // set visibility 0 if don't want to show in navigation menu
                    ),
                    array(
                        'label' => 'Add',
                        'route' => 'admin/child',
                        'controller' => 'user',
                        'action' => 'contacts',
                        'visible' => 0, // set visibility 0 if don't want to show in navigation menu
                    ),
                    array(
                        'label' => 'Manage User',
                        'route' => 'admin/child',
                        'controller' => 'user',
                        'action' => 'index',
                    ),
                    array(
                        'label' => 'Manage Profile Pic',
                        'route' => 'admin/child',
                        'controller' => 'profilepic',
                        'action' => 'index',
                        'visible' => 0,
                    ),
                    array(
                        'label' => 'Add',
                        'route' => 'admin/child',
                        'controller' => 'chat',
                        'action' => 'add',
                        'visible' => 0, // set visibility 0 if don't want to show in navigation menu
                    ),
                    array(
                        'label' => 'Add',
                        'route' => 'admin/child',
                        'controller' => 'chat',
                        'action' => 'edit',
                        'visible' => 0, // set visibility 0 if don't want to show in navigation menu
                    ),
                    array(
                        'label' => 'Manage Chat',
                        'route' => 'admin/child',
                        'controller' => 'chat',
                        'action' => 'index',
                        'visible' => 0, // set visibility 0 if don't want to show in navigation menu
                    ),
                   
                ),
            ),
            array(
                'label' => 'Setting',
                'route' => 'admin/child',
                'controller' => 'country',
                'action' => 'index',
                'pages' => array(
                    array(
                        'label' => 'Manage Country',
                        'route' => 'admin/child',
                        'controller' => 'country',
                        'action' => 'index',
                    ),
                    array(
                        'label' => 'Add',
                        'route' => 'admin/child',
                        'controller' => 'country',
                        'action' => 'add',
                        'visible' => 0, // set visibility 0 if don't want to show in navigation menu
                    ),
                    array(
                        'label' => 'Edit',
                        'route' => 'admin/child',
                        'controller' => 'country',
                        'action' => 'edit',
                        'visible' => 0, // set visibility 0 if don't want to show in navigation menu
                    ),
                    array(
                        'label' => 'Manage State',
                        'route' => 'admin/child',
                        'controller' => 'state',
                        'action' => 'index',
                    ),
                    array(
                        'label' => 'Add State',
                        'route' => 'admin/child',
                        'controller' => 'state',
                        'action' => 'add',
                        'visible' => 0, // set visibility 0 if don't want to show in navigation menu
                    ),
                    array(
                        'label' => 'Edit State',
                        'route' => 'admin/child',
                        'controller' => 'state',
                        'action' => 'edit',
                        'visible' => 0, // set visibility 0 if don't want to show in navigation menu
                    ),
                    /*array(
                        'label' => 'Manage Lookup Interest',
                        'route' => 'admin/child',
                        'controller' => 'lookupInterest',
                        'action' => 'index',
                    ),*/
                    // Look up status navigation
                    array(
                        'label' => 'Manage Lookup Status',
                        'route' => 'admin/child',
                        'controller' => 'lookupstatus',
                        'action' => 'index',
                    ),
                    array(
                        'label' => 'Add Lookup Status',
                        'route' => 'admin/child',
                        'controller' => 'lookupstatus',
                        'action' => 'add',
                        'visible' => 0, // set visibility 0 if don't want to show in navigation menu
                    ),
                    array(
                        'label' => 'Edit Lookup Status',
                        'route' => 'admin/child',
                        'controller' => 'lookupstatus',
                        'action' => 'edit',
                        'visible' => 0, // set visibility 0 if don't want to show in navigation menu
                    ),
                ),
            ),
            array(
                'label' => 'Project',
                'route' => 'admin/child',
                'controller' => 'project',
                'action' => 'index',
                'pages' => array(
                    array(
                        'label' => 'Add',
                        'route' => 'admin/child',
                        'controller' => 'project',
                        'action' => 'add',
                    ),
                    array(
                        'label' => 'Manage Project',
                        'route' => 'admin/child',
                        'controller' => 'project',
                        'action' => 'index',
                    ),
                   
                ),
            ),
        ),
    ),
);
