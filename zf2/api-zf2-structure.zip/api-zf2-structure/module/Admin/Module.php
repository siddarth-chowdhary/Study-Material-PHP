<?php
namespace Admin;

// Add these import statements:
use Admin\Model\Album;
use Admin\Model\AlbumTable;

use Admin\Model\User;
use Admin\Model\UserTable;
use Admin\Model\Country;
use Admin\Model\CountryTable;
use Admin\Model\State;
use Admin\Model\StateTable;
use Admin\Model\LookupStatus;
use Admin\Model\LookupStatusTable;
use Admin\Model\Project;
use Admin\Model\ProjectTable;
use Admin\Model\ProjectImage;
use Admin\Model\ProjectImageTable;
use Admin\Model\projectViewRequest;
use Admin\Model\projectViewRequestTable;
use Admin\Model\ProjectViewCount;
use Admin\Model\ProjectViewCountTable;
use Admin\Model\UserAddress;
use Admin\Model\UserAddressTable;
use Admin\Model\UserInterest;
use Admin\Model\UserInterestTable;
use Admin\Model\UserContact;
use Admin\Model\UserContactTable;
use Admin\Model\UserContactDetail;
use Admin\Model\UserContactDetailTable;
use Admin\Model\Chat;
use Admin\Model\ChatTable;
use Admin\Model\ProfilePic;
use Admin\Model\ProfilePicTable;
use Admin\Model\ChatUser;
use Admin\Model\ChatUserTable;

use Admin\Model\GeoLocation;
use Admin\Model\GeoLocationTable;

use Admin\Model\Message;
use Admin\Model\MessageTable;

use Admin\Model\PrivacySetting;
use Admin\Model\PrivacySettingTable;
use Admin\Model\ContactPrivacySetting;
use Admin\Model\ContactPrivacySettingTable;

use Admin\Model\TempProjectPic;
use Admin\Model\TempProjectPicTable;

use Admin\Model\MessageReceiver;
use Admin\Model\MessageReceiverTable;
// Include from libary
use Zend\Mvc\ModuleRouteListener;
use Zend\Mvc\MvcEvent;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\ModuleManager\Feature\AutoloaderProviderInterface;
use Zend\ModuleManager\Feature\ConfigProviderInterface;
use Zend\Authentication\Storage;
#use Zend\Session\Container;
use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as DbTableAuthAdapter;



class Module implements AutoloaderProviderInterface, ConfigProviderInterface
{
    
    public function onBootstrap($e) {
        
        $e->getApplication()->getEventManager()->getSharedManager()->attach('Zend\Mvc\Controller\AbstractActionController', 'dispatch', function($e) {
            $controller = $e->getTarget();
            $controllerClass = get_class($controller);
            $moduleNamespace = substr($controllerClass, 0, strpos($controllerClass, '\\'));
            
            $config = $e->getApplication()->getServiceManager()->get('config');
            
            if (isset($config['module_layouts'][$moduleNamespace])) {
                $controller->layout($config['module_layouts'][$moduleNamespace]);
            }
            $dateObj = new \DateTime('NOW');
            $controller->layout()->setVariable('Year', $dateObj->format('Y'));
        }, 100);
    }
    
    /*
    public function loadConfiguration(MvcEvent $e) {
        $application = $e->getApplication();
        $sm = $application->getServiceManager();
        $sharedManager = $application->getEventManager()->getSharedManager();
        
        

        $router = $sm->get('router');
        $request = $sm->get('request');

        $matchedRoute = $router->match($request);
        if (null !== $matchedRoute) {
            $sharedManager->attach('Zend\Mvc\Controller\AbstractActionController', 'dispatch', function($e) use ($sm) {
                $sm->get('ControllerPluginManager')->get('Myplugin')
                        ->doAuthorization($e); //pass to the plugin...    
            }, 2
            );
        }
    }*/
    
    public function getServiceConfig()
    {
         return array(
             'factories' => array(
                'Admin\Model\AlbumTable' =>  function($sm) {
                    $tableGateway = $sm->get('AlbumTableGateway');
                    $table = new AlbumTable($tableGateway);
                    return $table;
                },
                'AlbumTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Album());
                    return new TableGateway('album', $dbAdapter, null, $resultSetPrototype);
                },
                'Admin\Model\UserTable' => function($sm) {
                    $tableGateway = $sm->get('UserTableGateway');
                    $table = new UserTable($tableGateway);
                    return $table;
                },
                'UserTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    //echo '<pre>';var_dump($dbAdapter);echo '</pre>';
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new User());
                    return new TableGateway('user', $dbAdapter, null, $resultSetPrototype);
                 },
                'Admin\Model\CountryTable' =>  function($sm) {
                     $tableGateway = $sm->get('CountryTableGateway');
                     $table = new CountryTable($tableGateway);
                     return $table;
                 },
                 'CountryTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new Country());
                     return new TableGateway('country', $dbAdapter, null, $resultSetPrototype);
                 },
                 'Admin\Model\StateTable' =>  function($sm) {
                     $tableGateway = $sm->get('StateTableGateway');
                     $table = new StateTable($tableGateway);
                     return $table;
                 },
                 'StateTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new State());
                     return new TableGateway('state', $dbAdapter, null, $resultSetPrototype);
                 },
                 'Admin\Model\UserAddressTable' =>  function($sm) {
                     $tableGateway = $sm->get('UserAddressTableGateway');
                     $table = new UserAddressTable($tableGateway);
                     return $table;
                 },
                 'UserAddressTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new UserAddress());
                     return new TableGateway('userAddress', $dbAdapter, null, $resultSetPrototype);
                 },
                 'Admin\Model\UserContactDetailTable' =>  function($sm) {
                     $tableGateway = $sm->get('UserContactDetailTableGateway');
                     $table = new UserContactDetailTable($tableGateway);
                     return $table;
                 },
                 'UserContactDetailTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new UserContactDetail());
                     return new TableGateway('userContactDetail', $dbAdapter, null, $resultSetPrototype);
                 },
                 'Admin\Model\UserContactTable' =>  function($sm) {
                     $tableGateway = $sm->get('UserContactTableGateway');
                     $table = new UserContactTable($tableGateway);
                     return $table;
                 },
                 'UserContactTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new UserContact());
                     return new TableGateway('userContact', $dbAdapter, null, $resultSetPrototype);
                 },
                 'Admin\Model\UserInterestTable' =>  function($sm) {
                     $tableGateway = $sm->get('UserInterestTableGateway');
                     $table = new UserInterestTable($tableGateway);
                     return $table;
                 },
                 'UserInterestTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new UserInterest());
                     return new TableGateway('userInterest', $dbAdapter, null, $resultSetPrototype);
                 },
                 'Admin\Model\LookupStatusTable' =>  function($sm) {
                     $tableGateway = $sm->get('LookupStatusTableGateway');
                     $table = new LookupStatusTable($tableGateway);
                     return $table;
                 },
                 'LookupStatusTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new LookupStatus());
                     return new TableGateway('lookup_status', $dbAdapter, null, $resultSetPrototype);
                 },
                 'Admin\Model\ProjectTable' =>  function($sm) {
                     $tableGateway = $sm->get('ProjectTableGateway');
                     $table = new ProjectTable($tableGateway);
                     return $table;
                 },
                 'ProjectTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new Project());
                     return new TableGateway('project', $dbAdapter, null, $resultSetPrototype);
                 },
                 'Admin\Model\ProjectImageTable' =>  function($sm) {
                     $tableGateway = $sm->get('ProjectImageTableGateway');
                     $table = new ProjectImageTable($tableGateway);
                     return $table;
                 },
                 'ProjectImageTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new ProjectImage());
                     return new TableGateway('projectImage', $dbAdapter, null, $resultSetPrototype);
                 },
                 'Admin\Model\ProjectViewCountTable' =>  function($sm) {
                     $tableGateway = $sm->get('ProjectViewCountTableGateway');
                     $table = new ProjectViewCountTable($tableGateway);
                     return $table;
                 },
                 'ProjectViewCountTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new ProjectViewCount());
                     return new TableGateway('projectViewCount', $dbAdapter, null, $resultSetPrototype);
                 },
                  'Admin\Model\ProfilePicTable' =>  function($sm) {
                     $tableGateway = $sm->get('ProfilePicTableGateway');
                     $table = new ProfilePicTable($tableGateway);
                     return $table;
                 },
                 'ProfilePicTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new ProfilePic());
                     return new TableGateway('profilePic', $dbAdapter, null, $resultSetPrototype);
                 },
                  'Admin\Model\ChatTable' =>  function($sm) {
                    $tableGateway = $sm->get('ChatTableGateway');
                    $table = new ChatTable($tableGateway);
                    return $table;
                },
                'ChatTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Chat());
                    return new TableGateway('chat', $dbAdapter, null, $resultSetPrototype);
                },
                'Admin\Model\GeoLocationTable' =>  function($sm) {
                    $tableGateway = $sm->get('GeoLocationTableGateway');
                    $table = new GeoLocationTable($tableGateway);
                    return $table;
                },
                'GeoLocationTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new GeoLocation());                    
                    return new TableGateway('user', $dbAdapter, null, $resultSetPrototype);
                },
                'Admin\Model\ChatUserTable' =>  function($sm) {
                    $tableGateway = $sm->get('ChatUserTableGateway');
                    $table = new ChatUserTable($tableGateway);
                    return $table;
                },
                'ChatUserTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new ChatUser());
                    return new TableGateway('chatUser', $dbAdapter, null, $resultSetPrototype);
                },      
                  'Admin\Model\MessageReceiverTable' =>  function($sm) {
                    $tableGateway = $sm->get('\MessageReceiverTableGateway');
                    $table = new MessageReceiverTable($tableGateway);
                    return $table;
                },
                'MessageReceiverTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new MessageReceiver());
                    return new TableGateway('messageReceiver', $dbAdapter, null, $resultSetPrototype);
                },
                 'Admin\Model\PrivacySettingTable' =>  function($sm) {
                    $tableGateway = $sm->get('PrivacySettingTableGateway');
                    $table = new PrivacySettingTable($tableGateway);
                    return $table;
                },
                 'PrivacySettingTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new PrivacySetting());
                    return new TableGateway('privacySetting', $dbAdapter, null, $resultSetPrototype);
                },
                 'Admin\Model\ContactPrivacySettingTable' =>  function($sm) {
                    $tableGateway = $sm->get('ContactPrivacySettingTableGateway');
                    $table = new ContactPrivacySettingTable($tableGateway);
                    return $table;
                },
                 'ContactPrivacySettingTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new ContactPrivacySetting());
                    return new TableGateway('contactPrivacySetting', $dbAdapter, null, $resultSetPrototype);
                },
                  'Admin\Model\TempProjectPicTable' =>  function($sm) {
                    $tableGateway = $sm->get('TempProjectPicTableGateway');
                    $table = new TempProjectPicTable($tableGateway);
                    return $table;
                },
                 'TempProjectPicTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new TempProjectPic());
                    return new TableGateway('tempProjectPic', $dbAdapter, null, $resultSetPrototype);
                },
                 'Admin\Model\MessageTable' =>  function($sm) {
                    $tableGateway = $sm->get('MessageTableGateway');
                    $table = new MessageTable($tableGateway);
                    return $table;
                },
                'MessageTableGateway' => function ($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $resultSetPrototype = new ResultSet();
                    $resultSetPrototype->setArrayObjectPrototype(new Message());
                    return new TableGateway('message', $dbAdapter, null, $resultSetPrototype);
                },
                 'Admin\Model\projectViewRequestTable' =>  function($sm) {
                     $tableGateway = $sm->get('projectViewRequestTableGateway');
                     $table = new projectViewRequestTable($tableGateway);
                     return $table;
                 },
                 'projectViewRequestTableGateway' => function ($sm) {
                     $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                     $resultSetPrototype = new ResultSet();
                     $resultSetPrototype->setArrayObjectPrototype(new projectViewRequest());
                     return new TableGateway('projectViewRequest', $dbAdapter, null, $resultSetPrototype);
                 },
                 'Admin\Model\MyAuthStorage' => function($sm) {
                    $return = new Model\MyAuthStorage('ventureAppAdmin');
                    return $return;
                },
                'AuthService' => function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $dbTableAuthAdapter = new DbTableAuthAdapter($dbAdapter, 'user', 'email', 'password', 'SHA1(?) and userType=1');
                    $authService = new AuthenticationService();

                    $authService->setAdapter($dbTableAuthAdapter);

                    $authService->setStorage($sm->get('Admin\Model\MyAuthStorage'));

                    return $authService;
                },
                'Admin\Service\GoogleMap' => function ($sm) {
                    $config = $sm->get('config');
                    return new \Admin\Service\GoogleMap($config['GMaps']['api_key']);
                },
                'Admin\Service\MyMailer' => function ($sm) {
                    $config = $sm->get('config');
                    return new \Admin\Service\MyMailer($config['smtp']['user_name'],$config['smtp']['password'],$config['smtp']['port'],$config['smtp']['host'],$config['smtp']['ssl']);
                },
                'Admin\Service\ActionHelper' => function ($sm) {
                    $config = $sm->get('config');
                    return new \Admin\Service\ActionHelper($config);
                },
            ),
        );
    }

    public function getViewHelperConfig()
    {
        return array(
            'invokables' => array(
                'formelementerrors' => 'Admin\Form\View\Helper\FormElementErrors'
            ),
        );
    }
    
    public function getAutoloaderConfig()
    {
     return array(
         'Zend\Loader\ClassMapAutoloader' => array(
             __DIR__ . '/autoload_classmap.php',
         ),
         'Zend\Loader\StandardAutoloader' => array(
             'namespaces' => array(
                 __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
             ),
         ),
     );
    }

    public function getConfig()
    {
        $moduleConfig = include __DIR__ . '/config/module.config.php';
        $navigation = include __DIR__ . '/config/navigation.php';
        
     return array_merge($moduleConfig,$navigation);
    }
}
