<?php
namespace Admin\Form;

use Zend\Form\Form;

class UserContactForm extends Form
{
    public function __construct($statusArr,$contactNumber=1,$name = null,$userContactArr)
    {
        // we want to ignore the name passedColumn	Type	Comment
        parent::__construct('country');
        $this->setAttribute('class', 'form-horizontal');
        $this->setAttribute('role', 'form');

        $this->add(array(
            'name' => 'contactId',
            'type' => 'Zend\Form\Element\Hidden',
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Contact Id',
                'id' => 'contactId',
                'class'=>'form-control',
            ),
            'options' => array(
                'label' => 'Contact Id',
            ),
        ));
        $this->add(array(
            'name' => 'senderId',
            'type' => 'Zend\Form\Element\Hidden',
            'options' => array(
                'label' => 'sender Id',
            ),
            'attributes' => array(
                'placeholder' => 'sender Id',
                'class'=>'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'receiverId',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'contact',
                'id' => 'receiverId',
                'class'=>'form-control',
                'multiple'=>'multiple',
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> Contact',
                'label_options' => array(
                    'disable_html_escape' => true,
                ),
                'empty_option' => 'Please select contact',
                'value_options' => $userContactArr
            ),
        ));        
        /*$this->add(array(
            'name' => 'statusId',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Status',
                'id' => 'statusId',
                'class'=>'form-control',
            ),
            'options' => array(
                'label' => 'Status',
                'empty_option' => 'Please select status',
                'value_options' => $statusArr
            ),
        ));
        
        for($count=1;$count<=$contactNumber;$count++) {
            
            $elem = array(
                'name' => 'contactNumber-'.$count,
                'type' => 'Text',
                'required' => false,
                'options' => array(
                    'label' => 'Contact Number-'.$count,
                ),
                'attributes' => array(
                    'placeholder' => 'Contact Number'
                    ,'class'=>'form-control'
                    ,'maxlength'=>14
                    ,'id' => 'contactNumber-'.$count,
                ),
            );
            $this->add($elem);
            //$count++;
        }
        
        $this->add(array(
            'name' => 'number_count',
            'type' => 'Zend\Form\Element\Hidden',
            'required' => false,
            'allowempty' => true,
            'options' => array(
                'label' => 'User Id',
            ),
            'attributes' => array(
                'placeholder' => 'User Id',
                'class'=>'form-control',
                'value'=>($count-1),
                'id'=>'number_count',
            ),
        ));
        */
        $this->add(array(
            'name' => 'submit',
            'type' => 'Submit',
            'attributes' => array(
                'value' => 'Save',
                'id' => 'submitbutton',
                'class'=>'btn btn-default',
            ),
        ));
    }
}
