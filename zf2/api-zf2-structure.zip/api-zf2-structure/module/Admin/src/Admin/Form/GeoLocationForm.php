<?php
namespace Admin\Form;

use Zend\Form\Form;

class GeoLocationForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('geolocation');
        $this->setAttribute('class', 'form-horizontal');
        $this->setAttribute('role', 'form');

        /*$this->add(array(
            'name' => 'id',
            'type' => 'Hidden',
        ));*/
        $this->add(array(
            'name' => 'searchItem',
            'type' => 'Text',
            'options' => array(
                'label' => 'Search By',
            ),
            'attributes' => array(
                'title' => 'FirstName,LastName,Address,Interest,Phone,Email,State,Country etc',
                'placeholder' => 'FirstName,LastName,Address,Interest,Phone,Email,State,Country etc',
                'id' => 'searchItem',
                'class' => 'form-control',                
            )
        ));
         $this->add(array(
            'name' => 'distance',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Distance In KM',
                'id' => 'distance',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => 'Distance',
                //'empty_option' => 'Please select distance in km',               
                'value_options' => array(5=>5,10=>10,25=>25,50=>50,100=>100,500=>500,1000=>1000)
            )
        ));
        
        $this->add(array(
            'name' => 'submit',
            'type' => 'Submit',
            'attributes' => array(
                'value' => 'Go',
                'id' => 'submitbutton',
            ),
        ));
    }
}
