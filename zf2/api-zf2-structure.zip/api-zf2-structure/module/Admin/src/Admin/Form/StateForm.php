<?php
namespace Admin\Form;

use Zend\Form\Form;

class StateForm extends Form
{
    public function __construct($countryArray,$statusArray,$name = null)
    {
        // we want to ignore the name passedColumn	Type	Comment
        parent::__construct('state');
        $this->setAttribute('class', 'form-horizontal');
        $this->setAttribute('role', 'form');

        $this->add(array(
            'name' => 'stateId',
            'type' => 'Zend\Form\Element\Hidden',
        ));
        $this->add(array(
            'name' => 'stateCode',
            'type' => 'Text',
            'options' => array(
                'label' => '<span class="required-error">*</span> State Code',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'State Code',
                'class'=>'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'countryId',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'User Type ',
                'id' => 'countryId',
                'class'=>'form-control',
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> Country',
                'label_options' => array(
                    'disable_html_escape' => true,
                ),
                'empty_option' => 'Please select Country',
                'value_options' => $countryArray
            ),
        ));
        $this->add(array(
            'name' => 'stateName',
            'type' => 'Text',
            'options' => array(
                'label' => '<span class="required-error">*</span> State Name',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'State Name',
                'class'=>'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'statusId',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Status',
                'id' => 'statusId',
                'class'=>'form-control',
            ),
            'options' => array(
                'label' => 'Status',
                //'empty_option' => 'Please select login type',
                'value_options' => $statusArray
            ),
        ));
        $this->add(array(
            'name' => 'submit',
            'type' => 'Submit',
            'attributes' => array(
                'value' => 'Go',
                'id' => 'submitbutton',
                'class'=>'btn btn-default',
            ),
        ));
    }
}
