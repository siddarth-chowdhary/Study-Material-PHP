<?php
namespace Admin\Form\View\Helper;

use Zend\Form\View\Helper\FormElementErrors as OriginalFormElementErrors;

class FormElementErrors extends OriginalFormElementErrors  
{
    /*
    protected $messageCloseString     = '</li></ul>';
    protected $messageOpenFormat      = '<ul%s><li class="some-class">';
    protected $messageSeparatorString = '</li><li class="some-class">';
    */
    
    protected $messageCloseString     = '</span>';
    protected $messageOpenFormat      = '<span class="help-block">';
    protected $messageSeparatorString = '<br />';
}
