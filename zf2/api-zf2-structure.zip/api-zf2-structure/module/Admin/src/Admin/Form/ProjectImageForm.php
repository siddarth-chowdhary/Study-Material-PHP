<?php
namespace Admin\Form;

use Zend\Form\Form;

class ProjectImageForm extends Form
{
    public function __construct($name = null)
    {
        parent::__construct('project_image');
        $this->setAttribute('method', 'post');
        $this->setAttribute('class', 'form-inline');
        $this->setAttribute('role', 'form');
        $this->setAttribute('enctype','multipart/form-data'); 
        
        $this->add(array(
            'name' => 'imageId',
            'type' => 'Zend\Form\Element\Hidden',
            'required' => false,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Image Id',
                'id' => 'imageId',
                'class'=>'form-control',
            ),
            'options' => array(
                'label' => 'Image Id',
            ),
        ));
        
        $this->add(array(
            'name' => 'projectId',
            'type' => 'Zend\Form\Element\Hidden',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Project Id',
                'id' => 'projectId',
                'class'=>'form-control',
            ),
            'options' => array(
                'label' => 'Project Id',
            ),
        ));
        
        $this->add(array(
            'name' => 'image',
            'type' => 'Zend\Form\Element\File',
            'required' => true,
            'options' => array(
                'label' => '<span class="required-error">*</span> Upload Project Image',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(                
                'id' => 'project_image',
                //'class'=>'form-control',                
            ),
            
        ));
        
        $this->add(array(
            'name' => 'submit',
            'attributes'=> array(
                'type'  => 'submit',
                'value' => 'Upload',
                'id'    => 'submit',
                'class' => "btn btn-primary"
            )
        ));
    }
}
