<?php
namespace Admin\Form;

use Zend\Form\Form;

class MailForm extends Form
{
    public function __construct(Array $countryArray)
    {
        // we want to ignore the name passedColumn	Type	Comment
        parent::__construct('mail');
        $this->setAttribute('class', 'form-horizontal');
        $this->setAttribute('role', 'form');

//        $this->add(array(
//            'name' => 'countryId',
//            'type' => 'Zend\Form\Element\Hidden',
//        ));
        
//        $this->add(array(
//            'name' => 'Country',
//            'type' => 'Text',
//            'options' => array(
//                'label' => 'Country',
//            ),
//            'attributes' => array(
//                'placeholder' => 'Country',
//                'class'=>'form-control'
//            ),
//            'validators'=>array(
//                array('name'=>'Alpha'),
//            ),
//        ));
        
        $this->add(array(
            'name' => 'countryId',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Country Id ',
                'id' => 'countryId',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => 'Country',
                'empty_option' => 'Please select Country',
                'value_options' => $countryArray
            ),
        ));
        
        $this->add(array(
            'name' => 'Name',
            'type' => 'Text',
            'options' => array(
                'label' => 'Name',
            ),
            'attributes' => array(
                'placeholder' => 'Name',
                'class'=>'form-control'
            ),
        ));
        $this->add(array(
            'name' => 'Email',
            'type' => 'Text',
            'options' => array(
                'label' => 'Email',
            ),
            'attributes' => array(
                'placeholder' => 'Email',
                'class'=>'form-control'
            ),
        ));
        $this->add(array(
            'name' => 'Phone Number',
            'type' => 'Text',
            'options' => array(
                'label' => 'Phone Number',
            ),
            'attributes' => array(
                'placeholder' => 'Phone Number',
                'class'=>'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'submit',
            'type' => 'Submit',
            'attributes' => array(
                'value' => 'Go',
                'id' => 'submitbutton',
                'class'=>'btn btn-default',
            ),
        ));
    }
}
