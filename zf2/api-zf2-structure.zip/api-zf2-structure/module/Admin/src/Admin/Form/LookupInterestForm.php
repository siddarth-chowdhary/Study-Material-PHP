<?php
namespace Admin\Form;
use Zend\Form\Form;

class LookupInterestForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passedColumn	Type	Comment
        parent::__construct('LookupInterest');
        $this->setAttribute('class', 'form-horizontal');
        $this->setAttribute('role', 'form');

        $this->add(array(
            'name' => 'interestId',
            'type' => 'Zend\Form\Element\Hidden',
        ));
        $this->add(array(
            'name' => 'interest',
            'type' => 'Text',
            'options' => array(
                'label' => 'Interest',
            ),
            'attributes' => array(
                'placeholder' => 'Interest',
                'class'=>'form-control',
            ),
        ));
       
        $this->add(array(
            'name' => 'submit',
            'type' => 'Submit',
            'attributes' => array(
                'value' => 'Go',
                'id' => 'submitbutton',
                'class'=>'btn btn-default',
            ),
        ));
    }
}
