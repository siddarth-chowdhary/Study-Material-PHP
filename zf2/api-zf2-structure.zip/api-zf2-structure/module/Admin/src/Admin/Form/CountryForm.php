<?php
namespace Admin\Form;

use Zend\Form\Form;

class CountryForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passedColumn	Type	Comment
        parent::__construct('country');
        $this->setAttribute('class', 'form-horizontal');
        $this->setAttribute('role', 'form');

        $this->add(array(
            'name' => 'countryId',
            'type' => 'Zend\Form\Element\Hidden',
        ));
        $this->add(array(
            'name' => 'countryIsoCode',
            'type' => 'Text',
            'options' => array(
                'label' => '<span class="required-error">*</span> Country ISO Code',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'Country ISO Code',
                'class'=>'form-control',
                'maxlength'=>2
            ),
            'validators'=>array(
                array('name'=>'Alpha'),
            ),
        ));
        $this->add(array(
            'name' => 'countryCode',
            'type' => 'Text',
            'options' => array(
                'label' => '<span class="required-error">*</span> Country Code',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'Country Code',
                'class'=>'form-control',
                'maxlength'=>3
            ),
        ));
        $this->add(array(
            'name' => 'countryPhoneCode',
            'type' => 'Text',
            'options' => array(
                'label' => '<span class="required-error">*</span> Country Phone Code',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'Country Phone Code',
                'class'=>'form-control',
                'maxlength'=>4
            ),
        ));
        $this->add(array(
            'name' => 'countryName',
            'type' => 'Text',
            'options' => array(
                'label' => '<span class="required-error">*</span> Country Name',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'Country Name',
                'class'=>'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'submit',
            'type' => 'Submit',
            'attributes' => array(
                'value' => 'Go',
                'id' => 'submitbutton',
                'class'=>'btn btn-default',
            ),
        ));
    }
}
