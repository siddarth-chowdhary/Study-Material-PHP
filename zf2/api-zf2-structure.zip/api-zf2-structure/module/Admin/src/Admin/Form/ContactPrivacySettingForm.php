<?php

namespace Admin\Form;

use Zend\Form\Form;

class ContactPrivacySettingForm extends Form {

    public function __construct() {
        $privacyArray = array('1' => 'On', '2' => 'Off');
        parent::__construct("ContactPrivacySetting_Form");
        $this->setAttribute('method', 'post');
        $this->setAttribute('class', 'form-horizontal');
        $this->setAttribute('role', 'form');
        //$this->setAttribute('onSubmit', "return validateFormInterest('form')");
        $this->setAttribute('enctype', 'multipart/form-data');

        $this->add(array(
            'name' => 'contactSettingId',
            'type' => 'Zend\Form\Element\Hidden',
            'required' => false,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Contact Setting Id',
                'id' => 'contactSettingId',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => 'Contact Setting Id',
            ),
        ));
        $this->add(array(
            'name' => 'userId',
            'type' => 'Zend\Form\Element\Hidden',
            'required' => false,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'User Id',
                'id' => 'userId',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => 'User Id',
            ),
        ));
        $this->add(array(
            'name' => 'contactUserId',
            'type' => 'Zend\Form\Element\Hidden',
            'required' => false,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Contact User Id',
                'id' => 'contactUserId',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => 'Contact User Id',
            ),
        ));
        $this->add(array(
            'name' => 'hideLinkedin',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'options' => array(
                'label' => 'Hide Linkedin',
                'value_options' => $privacyArray
            ),
            'attributes' => array(
                'placeholder' => 'Hide Linkedin',
                'id' => 'hideLinkedin',
                'class' => 'form-control',
            )
        ));
        $this->add(array(
            'name' => 'hideProject',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'options' => array(
                'label' => 'Hide Project',
                'value_options' => $privacyArray
            ),
            'attributes' => array(
                'placeholder' => 'HideProject',
                'id' => 'hideProject',
                'class' => 'form-control',
            )
        ));
        //added on 8 oct 2014 by siddarth
        $this->add(array(
            'name' => 'hideProfilePhoto',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'options' => array(
                'label' => 'Hide Profile Photos',
                'value_options' => $privacyArray
            ),
            'attributes' => array(
                'placeholder' => 'Hide Profile Photos',
                'id' => 'hideProfilePhotos',
                'class' => 'form-control',
            )
        ));
        $this->add(array(
            'name' => 'block',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'options' => array(
                'label' => 'Block',
                'value_options' => $privacyArray
            ),
            'attributes' => array(
                'placeholder' => 'Block',
                'id' => 'block',
                'class' => 'form-control',
            )
        ));
        $this->add(array(
            'name' => 'report',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'options' => array(
                'label' => 'Report',
                'value_options' => $privacyArray
            ),
            'attributes' => array(
                'placeholder' => 'Report',
                'id' => 'report',
                'class' => 'form-control',
            )
        ));
        $this->add(array(
            'name' => 'submit',
            'attributes' => array(
                'type' => 'submit',
                'value' => 'Save',
                'id' => 'submitbutton',
                'class' => 'btn btn-default',
            ),
            'options' => array(
                'label' => '',
            ),
        ));
    }

    //IF YOU WILL WORK WITH DATABASE
    //AND NEED bind() FORM FOR EDIT DATA, YOU NEED OVERRIDE
    //populateValues() FUNC LIKE THIS
    public function populateValues($data) {
        foreach ($data as $key => $row) {
            if (is_array(@json_decode($row))) {
                $data[$key] = new \ArrayObject(\Zend\Json\Json::decode($row), \ArrayObject::ARRAY_AS_PROPS);
            }
        }

        parent::populateValues($data);
    }

}
