<?php
namespace Admin\Form;

use Zend\Form\Form;

class ProfilePicForm extends Form
{
    public function __construct($name = null)
    {
        parent::__construct('profile_pic');
        $this->setAttribute('method', 'post');
        $this->setAttribute('class', 'form-inline');
        $this->setAttribute('role', 'form');
        $this->setAttribute('enctype','multipart/form-data'); 
        
        $this->add(array(
            'name' => 'profilePicId',
            'type' => 'Zend\Form\Element\Hidden',
            'required' => false,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Profile Pic Id',
                'id' => 'profilePicId',
                'class'=>'form-control',
            ),
            'options' => array(
                'label' => 'Profile Pic Id',
            ),
        ));
        
        $this->add(array(
            'name' => 'userId',
            'type' => 'Zend\Form\Element\Hidden',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'User Id',
                'id' => 'userId',
                'class'=>'form-control',
            ),
            'options' => array(
                'label' => 'User Id',
            ),
        ));
        
        $this->add(array(
            'name' => 'profilePic',
            'type' => 'Zend\Form\Element\File',
            'required' => false,
            'options' => array(
                'label' => 'Upload Profile Image',
            ),
            'attributes' => array(                
                'id' => 'profilePic',
                //'class'=>'form-control',                
            ),
            
        ));
        
        $this->add(array(
            'name' => 'submit',
            'attributes'=> array(
                'type'  => 'submit',
                'value' => 'Upload',
                'id'    => 'submit',
                'class' => "btn btn-primary"
            )
        ));
    }
}
