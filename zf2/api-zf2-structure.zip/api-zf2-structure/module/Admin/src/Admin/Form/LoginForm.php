<?php
namespace Admin\Form;

use Zend\Form\Form;

class LoginForm extends Form
{
    public function __construct($name = null)
    {
        parent::__construct('admin_login');
        $this->setAttribute('method', 'post');
        $this->setAttribute('class', 'form-signin');
        $this->setAttribute('role', 'form');
        $this->setAttribute('enctype','multipart/form-data'); 
        
        $this->add(array(
            'name' => 'email',
            'attributes'=> array(
                'id'    => 'email',
                'type'  => 'text',
                'placeholder' => "User Name",
                'autocomplete'=> "off"
                ,'class'=>'form-control'
                ,'required'=>'true'
            )
        ));
        $this->add(array(
            'name' => 'password',
            'attributes'=> array(
                'type'  => 'password',
                'placeholder' => "Password",
                'autocomplete'=> "off"
                ,'class'=>'form-control'
                ,'required'=>'true'
            )            
        ));
        $this->add(array(
            'type' => 'Zend\Form\Element\Checkbox',
            'name' => 'remember_me',
            'attributes' => array(
                'id' => 'remember_me'
            ),
            'options' => array(
                'label' => 'Remember Me',
                'use_hidden_element'=> false,
                'checked_value'     => true,
                'unchecked_value'   => false
            )                       
        ));
        $this->add(array(
            'name' => 'submit',
            'attributes'=> array(
                'type'  => 'submit',
                'value' => 'Sign in',
                'id'    => 'submit',
                'class' => "btn btn-lg btn-primary btn-block"
            )
        ));
    }
}
