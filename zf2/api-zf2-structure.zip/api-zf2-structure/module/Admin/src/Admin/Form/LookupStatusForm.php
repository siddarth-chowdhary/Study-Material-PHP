<?php
namespace Admin\Form;
use Zend\Form\Form;

class LookupStatusForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passedColumn	Type	Comment
        parent::__construct('LookupStatus');
        $this->setAttribute('class', 'form-horizontal');
        $this->setAttribute('role', 'form');

        $this->add(array(
            'name' => 'statusId',
            'type' => 'Hidden',
        ));
        $this->add(array(
            'name' => 'statusCode',
            'type' => 'Text',
            'options' => array(
                'label' => '<span class="required-error">*</span> Status',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'Status',
                'class'=>'form-control',
            ),
        ));
       
        $this->add(array(
            'name' => 'submit',
            'type' => 'Submit',
            'attributes' => array(
                'value' => 'Go',
                'id' => 'submitbutton',
                'class'=>'btn btn-default',
            ),
        ));
    }
}
