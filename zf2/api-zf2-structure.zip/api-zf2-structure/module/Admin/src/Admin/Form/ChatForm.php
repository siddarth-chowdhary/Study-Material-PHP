<?php
namespace Admin\Form;

use Zend\Form\Form;

class ChatForm extends Form
{
    public function __construct($VisibilityArray,$chatReceivedUserArray,$name = null)
    {
        
        //print_r($chatCreateUserArray);exit;
        // we want to ignore the name passedColumn	Type	Comment
        parent::__construct('chat');
        $this->setAttribute('class', 'form-horizontal');
        $this->setAttribute('role', 'form');

        $this->add(array(
            'name' => 'chatId',
            'type' => 'Zend\Form\Element\Hidden',
            'required' => false,
        ));
        
        $this->add(array(
            'name' => 'userId',
            'type' => 'Zend\Form\Element\Hidden',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Chat Create User',
                'id' => 'userId',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => 'Chat Create User',
            ),
        ));
        
         $this->add(array(
            'name' => 'statusId',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Visibility',
                'id' => 'statusId',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> Visibility',
                'label_options' => array(
                    'disable_html_escape' => true,
                ),
                'empty_option' => 'Please select Visibility',                
                'value_options' => $VisibilityArray
            )
        ));
        
          $this->add(array(
            'name' => 'password',
            'type' => 'Zend\Form\Element\Password',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> Password',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'Password',
                'id' => 'password',
                'autocomplete' => 'off',
                'value' => "",
                'class' => 'form-control',
            ),
            'validators' => array(
                array(
                    'name' => 'StringLength',
                    'options' => array(
                        'encoding' => 'UTF-8',
                        'min' => 5,
                        'max' => 64,
                    ),
                ),
            ),
              'visibility'=>0,
        ));
          
          
          $this->add(array(
            'name' => 'user_Id',
            'type' => 'Zend\Form\Element\Select',
            'required' => false,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Chat Received User',
                'id' => 'userId',
                'multiple' => 'multiple',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> Chat Received User',
                'label_options' => array(
                    'disable_html_escape' => true,
                ),
                'empty_option' => 'Please select Chat Received User',
                'value_options' => $chatReceivedUserArray
            ),
        ));
          
          $this->add(array(
            'name' => 'message',
            'type' => 'Zend\Form\Element\Textarea',
            'required' => true,
            'options' => array(
                'label' => '<span class="required-error">*</span> Message',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'Message',
                'class' => 'form-control',
                'id' => 'message',
            ),
        ));
         
        $this->add(array(
            'name' => 'submit',
            'type' => 'Submit',
            'attributes' => array(
                'value' => 'Go',
                'id' => 'submitbutton',
                'class'=>'btn btn-default',
            ),
        ));
    }
}
