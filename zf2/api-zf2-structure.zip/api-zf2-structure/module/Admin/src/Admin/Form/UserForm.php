<?php

namespace Admin\Form;

use Zend\Form\Form;

class UserForm extends Form {

    public function __construct($userTypeArray, $userStatusArray, $genderArray, Array $countryArray, Array $stateArray, Array $countryPhoneCodeArray) {

        parent::__construct("User_Form");
        $this->setAttribute('method', 'post');
        $this->setAttribute('class', 'form-horizontal');
        $this->setAttribute('role', 'form');
        $this->setAttribute('onSubmit', "return validateFormInterest('form')");
        $this->setAttribute('enctype', 'multipart/form-data');

        $this->add(array(
            'name' => 'userId',
            'type' => 'Zend\Form\Element\Hidden',
            'required' => false,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'User Id',
                'id' => 'userId',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => 'User Id',
            ),
        ));
        $this->add(array(
            'name' => 'loginFrom',
            'type' => 'Zend\Form\Element\Hidden',
            'required' => false,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Login From',
                'id' => 'loginFrom',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => 'Login From',
            ),
        ));

        $this->add(array(
            'name' => 'userType',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'User Type ',
                'id' => 'userType',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> User Type',
                'label_options' => array(
                    'disable_html_escape' => true,
                ),
                'empty_option' => 'Please select user type',
                'value_options' => $userTypeArray
            ),
        ));

        $this->add(array(
            'name' => 'userName',
            'type' => 'Zend\Form\Element\Text',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
                array('name' => 'alpha')
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> User Name',
                'label_options' => array(
                    'disable_html_escape' => true,
                ),
            ),
            'attributes' => array(
                'placeholder' => 'User Name',
                'id' => 'userName',
                'class' => 'form-control',
            )
        ));

        $this->add(array(
            'name' => 'firstName',
            'type' => 'Zend\Form\Element\Text',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
                array('name' => 'alpha')
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> First Name',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'First Name',
                'id' => 'firstName',
                'class' => 'form-control',
            ),
            /* 'validators' => array(
              /*array(
              'name' => 'StringLength',
              'options' => array(
              'encoding' => 'UTF-8',
              'min' => 2,
              'max' => 30,
              ),
              ),
              array('Regex', FALSE, array('pattern' => '/[a-z][A-Z]/'))
              ), */
            'validators' => array(array('name' => 'regex',
                    'options' => array('pattern' => '/^[[:alpha:]]*$/', 'message' => array(
                            'Only Alpha keyword are allowed'
                        ),),),)
        ));
        $this->add(array(
            'name' => 'lastName',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> Last Name',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'Last Name',
                'id' => 'lastName',
                'class' => 'form-control',
            ),
            /* 'validators' => array(
              array(
              'name' => 'StringLength',
              'options' => array(
              'encoding' => 'UTF-8',
              'min' => 2,
              'max' => 30,
              ),
              ),
              ), */
            'validators' => array(array('name' => 'regex',
                    'options' => array('pattern' => '/^[[:alpha:]]*$/', 'message' => array(
                            'Only Alpha keyword are allowed'
                        ),),),)
        ));
        /* $this->add(array(
          'name' => 'profilePicId',
          'type' => 'Zend\Form\Element\Text',
          'required' => false,
          'options' => array(
          'label' => 'Profile Picture',
          ),
          'attributes' => array(
          'id' => 'profilePicId',
          ),
          )); */
        $this->add(array(
            'name' => 'email',
            'required' => true,
            'type' => 'Zend\Form\Element\Email',
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> Email',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'Email',
                'id' => 'email',
                'class' => 'form-control',
                'maxlength' => '100',
            ),
            'validators' => array(
                array(
                    'name' => 'StringLength',
                    'options' => array(
                        'encoding' => 'UTF-8',
                        'min' => 5,
                        'max' => 64,
                    ),
                ),
            ),
        ));
        $this->add(array(
            'name' => 'countryPhoneCode',
            'type' => 'Zend\Form\Element\Text',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Isd Code',
                'id' => 'countryPhoneCode',
                'class' => 'form-control',
                'style' => 'width:30%;float:left;',
                'maxlength' => 5,
            ),
            'options' => array(
                'label' => '',
                'empty_option' => 'phone code',
            //'value_options' => $countryPhoneCodeArray
            ),
        ));

        $this->add(array(
            'name' => 'phone',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> Phone',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'Phone',
                'id' => 'phone',
                'maxlength' => '14',
                'class' => 'form-control',
                'style' => 'width:70%;float:left;',
            ),
            'validators' => array(
                array(
                    'name' => 'StringLength',
                    'options' => array(
                        'encoding' => 'UTF-8',
                        'min' => 14,
                        'max' => 14,
                        'message' => array(
                            'The input is less than 10 characters long'
                        ),
                    ),
                ),
            ),
        ));

        $this->add(array(
            'name' => 'password',
            'type' => 'Zend\Form\Element\Password',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> Password',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'Password',
                'id' => 'password',
                'autocomplete' => 'off',
                'value' => "",
                'class' => 'form-control',
            ),
            'validators' => array(
                array(
                    'name' => 'StringLength',
                    'options' => array(
                        'encoding' => 'UTF-8',
                        'min' => 5,
                        'max' => 64,
                    ),
                ),
            ),
        ));

        $this->add(array(
            'name' => 'statusId',
            'type' => 'Zend\Form\Element\Select',
            'required' => false,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Status',
                'id' => 'statusId',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => 'Status',
                //'empty_option' => 'Please select login type',
                'value_options' => $userStatusArray
            ),
        ));

        $this->add(array(
            'name' => 'gender',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Gender',
                'id' => 'gender',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => 'Gender',
                'empty_option' => 'Please select gender',
                'value_options' => $genderArray
            ),
        ));
        $this->add(array(
            'name' => 'occupation',
            'type' => 'Zend\Form\Element\Text',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Occupation',
                'id' => 'occupation',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => 'Occupation',
            //'empty_option' => 'Please select login type',
            //'value_options' => $occupationArray
            ),
        ));
        $this->add(array(
            'name' => 'skill',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Skill',
            ),
            'attributes' => array(
                'placeholder' => 'Skill',
                'id' => 'skill',
                'class' => 'form-control',
            ),
            'validators' => array(
                array(
                    'name' => 'StringLength',
                    'options' => array(
                        'encoding' => 'UTF-8',
                        'min' => 1,
                        'max' => 255,
                    ),
                ),
            ),
        ));

        $this->add(array(
            'name' => 'interest1',
            'required' => false,
            'type' => 'Zend\Form\Element\Text',
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Interest1',
            ),
            'attributes' => array(
                'placeholder' => 'Interest1',
                'id' => 'interest1',
                'class' => 'form-control',
                'title' => 'Interest1'
            ),
            'validators' => array(
                array(
                ),
            ),
        ));
        $this->add(array(
            'name' => 'interest2',
            'required' => false,
            'type' => 'Zend\Form\Element\Text',
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Interest2',
            ),
            'attributes' => array(
                'placeholder' => 'Interest2',
                'id' => 'interest2',
                'class' => 'form-control',
                'title' => 'Interest2'
            ),
            'validators' => array(
                array(
                ),
            ),
        ));
        $this->add(array(
            'name' => 'interest3',
            'required' => false,
            'type' => 'Zend\Form\Element\Text',
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Interest3',
            ),
            'attributes' => array(
                'placeholder' => 'Interest3',
                'id' => 'interest3',
                'class' => 'form-control',
                'title' => 'Interest3'
            ),
            'validators' => array(
                array(
                ),
            ),
        ));

        $this->add(array(
            'name' => 'countryId',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Country Id ',
                'id' => 'countryId',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> Country',
                'label_options' => array(
                    'disable_html_escape' => true,
                ),
                'empty_option' => 'Please select Country',
                'value_options' => $countryArray
            ),
        ));
        $this->add(array(
            'name' => 'stateId',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'State Name',
                'id' => 'stateId',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => 'State',
                'empty_option' => 'Please select State',
                'value_options' => $stateArray
            ),
        ));

        $this->add(array(
            'name' => 'address',
            'type' => 'Zend\Form\Element\Textarea',
            'required' => true,
            'options' => array(
                'label' => '<span class="required-error">*</span> Address',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'Address',
                'class' => 'form-control',
                'id' => 'address',
            ),
        ));

        $this->add(array(
            'name' => 'submit',
            'attributes' => array(
                'type' => 'submit',
                'value' => 'Save',
                'id' => 'submitbutton',
                'class' => 'btn btn-default',
            ),
            'options' => array(
                'label' => '',
            ),
        ));
    }

    //IF YOU WILL WORK WITH DATABASE
    //AND NEED bind() FORM FOR EDIT DATA, YOU NEED OVERRIDE
    //populateValues() FUNC LIKE THIS
    public function populateValues($data) {
        foreach ($data as $key => $row) {
            if (is_array(@json_decode($row))) {
                $data[$key] = new \ArrayObject(\Zend\Json\Json::decode($row), \ArrayObject::ARRAY_AS_PROPS);
            }
        }

        parent::populateValues($data);
    }

}
