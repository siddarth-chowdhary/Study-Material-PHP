<?php
namespace Admin\Form;

use Zend\Form\Form;

class ProjectForm extends Form
{
    public function __construct($userArray,$statusArray,$name = null)
    {
        // we want to ignore the name passedColumn	Type	Comment
        parent::__construct('project');
        $this->setAttribute('class', 'form-horizontal');
        $this->setAttribute('role', 'form');

        $this->add(array(
            'name' => 'projectId',
            'type' => 'Zend\Form\Element\Hidden',
        ));
        $this->add(array(
            'name' => 'projectName',
            'type' => 'Text',
            'options' => array(
                'label' => '<span class="required-error">*</span> Project Name',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'Project Name',
                'class'=>'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'userId',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'User ',
                'id' => 'userId',
                'class'=>'form-control',
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> User',
                'label_options' => array(
                    'disable_html_escape' => true,
                ),
                'empty_option' => 'Please select user',
                'value_options' => $userArray
            ),
        ));
        $this->add(array(
            'name' => 'projectDetail',  
            'type'=>'Zend\Form\Element\Textarea',
            'options' => array(
                'label' => '<span class="required-error">*</span> Project Detail',
                'label_options' => array(
                    'disable_html_escape' => true,
                )
            ),
            'attributes' => array(
                'placeholder' => 'Project Detail',
                'class'=>'form-control',
                'id' => 'projectDetail',
                
            ),
        ));
        $this->add(array(
            'name' => 'visibility',
            'type' => 'Zend\Form\Element\Select',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Visibility',
                'id' => 'visibility',
                'class'=>'form-control',
            ),
            'options' => array(
                'label' => '<span class="required-error">*</span> Visibility',
                'label_options' => array(
                    'disable_html_escape' => true,
                ),
                'empty_option' => 'Please select status',
                'value_options' => $statusArray
            ),
        ));
        $this->add(array(
            'name' => 'submit',
            'type' => 'Submit',
            'attributes' => array(
                'value' => 'Go',
                'id' => 'submitbutton',
                'class'=>'btn btn-default',
            ),
        ));
    }
}
