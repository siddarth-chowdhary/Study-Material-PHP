<?php
namespace Admin\Service;


use Zend\Mail\Message;
use Zend\Mail\Transport\Smtp as SmtpTransport;
use Zend\Mime\Message as MimeMessage;
use Zend\Mime\Part as MimePart;
use Zend\Mail\Transport\SmtpOptions;
use \Exception;

/*

create object
$my_mailer = $this->getServiceLocator()->get('Admin\Service\MyMailer'); //getting the my mailer object using service manager

*/
class MyMailer
{
    private $subject = 'Venture chat App';
    private $message = 'Message Boddy';
    private $fromName = 'Venture App';
    private $fromEmail = 'info@ventureapp.com';
    private $bcc,$cc;
    private $toMails = '';
    public $userName = ''; // existing verified smtp mail account
    public $password = ''; // verified smtp mail accounts password
    public $port = ''; // smtp port
    public $host = 'http://venture.local'; // smtp host
    public $ssl = 'tls'; // smtp ssl default tls
    
    
    public function __construct($user_name=NULL,$password=NULL,$port=NULL,$host=NULL,$ssl='tls') {
        if(!empty($user_name))
            $this->setUserName($user_name);
        if(!empty($password))
            $this->setPassword($password);
        if(!empty($port))
            $this->setPort($port);
        if(!empty($host))
            $this->setHost($host);
        if($ssl != 'tls')
            $this->setSsl($ssl);
    }
    
    public function setUserName($value)
    {
        $this->userName = $value;
        return $this;
    }
    public function setPassword($value)
    {
        $this->password = $value;
        return $this;
    }
    public function setPort($value)
    {
        $this->port = $value;
        return $this;
    }
    public function setHost($value)
    {
        $this->host = $value;
        return $this;
    }
    public function setSsl($value)
    {
        $this->ssl = $value;
        return $this;
    }
    
    public function setSubject($value)
    {
        $this->subject = $value;
        return $this;
    }
    public function setMessage($value)
    {
        $this->message = $value;
        return $this;
    }
    public function setFromName($value)
    {
        $this->fromName = $value;
        return $this;
    }
    public function setFromEmail($value)
    {
        $this->fromEmail = $value;
        return $this;
    }
   
    public function setToMails($value)
    {
        $this->toMails = $value;
        return $this;
    }
    
    public function setBcc($value) {
        $this->bcc = $value;
        return $this;
    }
    
    public function setCc($value)
    {
        $this->cc = $value;
        return $this;
    }
    
    public function sendMail()
    {
        try {
            $message = new Message();
            if(!empty($this->toMails)) {
                if(is_array($this->toMails)) {
                    foreach($this->toMails as $key=>$emailTo) {
                        $message->addTo($emailTo);
                    }
                }
                else {
                    $message->addTo($this->toMails);
                }
            }
            else {
                throw new \Exception('To Email address shouldn\'t be blank');
            }
            if(!empty($this->cc)) {
                if(is_array($this->cc)) {
                    foreach($this->cc as $key=>$emailCc) {
                        $message->addCc($emailCc);
                    }
                }
                else {
                    $message->addCc($this->cc);
                }
            }
            if(!empty($this->bcc)) {
                if(is_array($this->bcc)) {
                    foreach($this->bcc as $key=>$emailBcc) {
                        $message->addBcc($emailBcc);
                    }
                }
                else {
                    $message->addBcc($this->bcc);
                }
            }
            
            $message->addFrom($this->fromEmail,$this->fromName)
                    ->setSubject($this->subject);
            // Setup SMTP transport using LOGIN authentication
            $transport = new SmtpTransport();
            $options = new SmtpOptions(array(
                            'host' => $this->host,
                            'connection_class' => 'login',
                            'connection_config' => array(
                                'ssl' => $this->ssl,
                                'username' => $this->userName,
                                'password' => $this->password
                            ),
                            'port' => $this->port,
                        )
                    );
             
            $html = new MimePart($this->message);
            $html->type = "text/html";
             
            $body = new MimeMessage();
            $body->addPart($html);
             
            $message->setBody($body);
             
            $transport->setOptions($options);
            $transport->send($message);
        }
        catch(Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }
}
