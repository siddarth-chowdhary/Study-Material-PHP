<?php
namespace Admin\Service;

/*
 * Author : Pradeep Kumar Baranwal
 * Email : pradeep.singh@clavax.com
 * Made all common methods needed by you
 * In this class config will be available
 * 
 * 
 * */
class ActionHelper
{
    private $configVars;
    
    public function __construct($config = array())
    {
        $this->configVars = $config;
    }
    
    public function greatCircleDistance($lat1,$lon1,$lat2,$lon2)
    {
        /* Convert all the degrees to radians */
        $lat1 = $this->degToRadian($lat1);
        $lon1 = $this->degToRadian($lon1);
        $lat2 = $this->degToRadian($lat2);
        $lon2 = $this->degToRadian($lon2);

        /* Find the deltas (both radius of eclipse)*/
        $delta_lat = $lat2 - $lat1;
        $delta_lon = $lon2 - $lon1;

        /* Find the Great Circle distance */
        $temp = pow(sin($delta_lat/2.0),2) + cos($lat1) * cos($lat2) * pow(sin($delta_lon/2.0),2);
        $EARTH_RADIUS = $this->configVars['earth_radius_miles'];
        $distance = $EARTH_RADIUS * 2 * atan2(sqrt($temp),sqrt(1-$temp)); // distance in miles

        return $distance;
    }


    private function degToRadian($deg)
    {
        $radians = 0.0;
        $radians = $deg * M_PI/180.0;
        return($radians);
    }
}
