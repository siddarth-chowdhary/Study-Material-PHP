<?php
namespace Admin\Service;

class MyException extends \Exception
{
    private $getClass;
    public function __construct($message,$code=0,Exception $previous=null)
    {
        if(strpos($message,'phone') !== false && strpos($message,'Duplicate entry') !== false) {
            
            $message = 'Phone number already taken, please choose another one.';
        }
        if(strpos($message,'email') !== false && strpos($message,'Duplicate entry') !== false) {
            
            $message = 'Email Id already taken, please choose another one.';
        }
        if(strpos($message,'userName') !== false && strpos($message,'Duplicate entry') !== false) {
            
            $message = 'User Name already taken, please choose another one.';
        }
        parent::__construct($message,$code,$previous);
    }
    
    // custom string representation of object
    public function __toString() {
        return __CLASS__ . ": [{$this->getClass}] : [{$this->code}]: {$this->message}\n";
    }
    
}
