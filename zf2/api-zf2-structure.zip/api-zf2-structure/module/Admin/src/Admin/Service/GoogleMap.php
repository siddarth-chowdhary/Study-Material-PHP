<?php

namespace Admin\Service;

/**
 * Admin\Service\GoogleMap
 *
 * Zend Framework2 Google Map Class  (Google Maps API v3)
 *
 * An open source application development framework for PHP 5.3.0 or newer
 * 
 * This class enables the creation of google maps
 *
 * @package		Zend Framework 2
 * @author		PRadeep Kumar Baranwal 
 */
class GoogleMap {

    private $api_key = '';
    private $sensor = 'false';
    private $disableDefaultUI = 'false';
    private $panControl = 'true';
    private $scaleControl = 'true';
    private $zoomControl = 'true';
    private $streetViewControl = 'true';
    private $mapTypeControl = 'true';
    private $centereMarkerImage = '';
    private $div_id = '';
    private $div_class = '';
    private $zoom = 10;
    private $lat = -300;
    private $lon = 300;
    private $user_name = 'Venture User';
    private $markers = array();
    private $infowindowVal = array();
    private $height = "100px";
    private $width = "100px";
    private $animation = '';
    private $center_changed = 'false';
    private $icon = '';
    private $icons = array();
    private $mapTypeControlOptions = array(); // see reference from "https://developers.google.com/maps/documentation/javascript/controls"
    private $panControlOptions = array();
    private $zoomControlOptions = array();
    private $streetViewControlOptions = array();
    private $infoWindow = 'true';

    /**
     * Constructor
     */
    function __construct($api_key) {
        $this->api_key = $api_key;
    }

    // --------------------------------------------------------------------

    /**
     * Initialize the user preferences
     *
     * Accepts an associative array as input, containing display preferences
     *
     * @access	public
     * @param	array	config preferences
     * @return	void
     */
    function initialize($config = array()) {
        foreach ($config as $key => $val) {
            if (isset($this->$key)) {
                $this->$key = $val;
            }
        }
    }

    // --------------------------------------------------------------------

    /**
     * Generate the google map
     *
     * @access	public
     * @return	string
     */
    public function generate() {

        $out = '';

        $out .= '	<div id="' . $this->div_id . '" class="' . $this->div_class . '" style="height:' . $this->height . ';width:' . $this->width . ';"></div>';

        $out .= '	<script type="text/javascript" src="//maps.googleapis.com/maps/api/js?key=' . $this->api_key . '&sensor=' . $this->sensor . '"></script>';

        $out .= '	<script type="text/javascript"> 
    	
						function doAnimation() 
						{
							if (marker.getAnimation() != null) 
							{
								marker.setAnimation(null); 
							} 
							else 
							{
								marker.setAnimation(google.maps.Animation.' . $this->animation . ');
							}
						}
                        var marker;
    					function initialize() 
    					{
    						
    						var myOptions = {
    							center: new google.maps.LatLng(' . $this->lat . ',' . $this->lon . '), 
    							Zoom:' . $this->zoom . ', 
    							mapTypeId: google.maps.MapTypeId.ROADMAP,
    							streetViewControl: ' . $this->streetViewControl . ',
                                disableDefaultUI: ' . $this->disableDefaultUI;

        $out .= ',panControl: ' . $this->panControl;
        if (!empty($this->panControlOptions) && $this->panControl == 'true') {
            $out .= ',panControlOptions : {';
            foreach ($this->panControlOptions as $key => $options) {
                $out .= $key . ':' . $options;
            }
            $out .= '}';
        }
        $out .= ',zoomControl: ' . $this->zoomControl;

        if (!empty($this->zoomControlOptions) && $this->zoomControl == 'true') {
            $out .= ',zoomControlOptions : {';
            foreach ($this->zoomControlOptions as $key => $options) {
                $out .= $key . ':' . $options;
            }
            $out .= '}';
        }
        $out .= ',scaleControl: ' . $this->scaleControl;

        $out .= ',mapTypeControl: ' . $this->mapTypeControl;
        if (!empty($this->mapTypeControlOptions) && $this->mapTypeControl == 'true') {
            $out .= ',mapTypeControlOptions : {';
            foreach ($this->mapTypeControlOptions as $key => $options) {
                $out .= $key . ':' . $options . ',';
            }
            $out .= '}';
        }

        $out .= '};';

        $out .= 'var map = new google.maps.Map(document.getElementById("' . $this->div_id . '"), myOptions);';
        $out .= 'var image = "' . $this->centereMarkerImage . '";

            marker = new google.maps.Marker({
            position: map.getCenter(),            
            map: map,
            icon: image,
            title: "' . $this->user_name . '"
          });';
        if ($this->center_changed == 'true') {
            $out .= 'google.maps.event.addListener(map, "center_changed", function() {
                                // 3 seconds after the center of the map has changed, pan back to the
                                // marker.
                                window.setTimeout(function() {
                                  map.panTo(marker.getPosition());
                                }, 3000);
                              });';
        }

        $i = 0;

        foreach ($this->markers as $key => $value) {
            $out .="var marker" . $i . " = new google.maps.Marker({
                                                position: new google.maps.LatLng(" . $value . "), 
                                                map: map,";
            if ($this->animation != '') {
                $out .="animation: google.maps.Animation." . $this->animation . ",";
            }

            if (!empty($value['icon'])) {
                $out .="icon:'" . $value['icon'] . "',";
            } else {
                if ($this->icon != '') {
                    $out .="icon:'" . $this->icon . "',";
                } elseif (count($this->icons) > 0) {
                    $out .="icon:'" . $this->icons[$i] . "',";
                }
            }
            $out .="title:'" . $key . "'});";

            /* if ($this->animation != '') {
              $out .="google.maps.event.addListener(marker" . $i . ", 'click', doAnimation);";
              } */

            if ($this->infoWindow == 'true') {
                $out.="google.maps.event.addListener(marker" . $i . ", 'click', function() {";
                $mrkerCnt = count($this->markers);
                if ($mrkerCnt > 0) {
                    for ($j = 0; $j < $mrkerCnt; $j++) {

                        $out.="infowindow" . $j . ".close();";
                    }
                }
                $out.="        infowindow" . $i . ".open(map,marker" . $i . ");
                        });";
            }
            if (isset($this->infowindowVal) && $this->infowindowVal != '') {
                $out.='var infowindow' . $i . ' = new google.maps.InfoWindow({
                content:"' . $this->infowindowVal[$i]['firstName'] . ''
                        . ' ' . $this->infowindowVal[$i]['lastName'] . '<br>' . $this->infowindowVal[$i]['address'] . '"
                });';
            }

            $i++;
        }
        $out .= '} 
            initialize();
	</script>';


        return $out;
    }

    public function getLatLongByIp() {
        
    }

    public function getLatLongByAddress($address, $type = 'json') {
        $lat = $long = '';
        if (!empty($address) && !empty($type)) {
            $queryArr = array(
                'address' => $address
                , 'sensor' => 'false'
            );
            $url = 'http://maps.googleapis.com/maps/api/geocode/' . $type . '?' . http_build_query($queryArr);
            $var = file_get_contents($url);
            $var = json_decode($var);
            if (!empty($var->status) && strtolower($var->status) == 'ok') {
                if (!empty($var->results) && !empty($var->results[0])) {
                    $lat = $var->results[0]->geometry->location->lat;
                    $long = $var->results[0]->geometry->location->lng;
                }
            }
        }
        return compact('lat', 'long');
    }

}
