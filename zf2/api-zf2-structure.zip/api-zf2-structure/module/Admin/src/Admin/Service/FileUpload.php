<?php
namespace Admin\Service;

use \Exception;

class FileUpload
{
    private $rename, $newName,$thumbImageName;
    
    public $allowedExtensions = array('jpg','jpeg','gif','png');
    public $resize = false;
    public $resizeOption = '160x280 ';
    public $createThumb = false;
    public $thumbResize = '80x142 ';
    public $document_root = '/';
    public $convert_path = 'convert';
    
    public function __construct($rename=false,$newName='') {
        $this->rename = $rename;        
        if(empty($newName))
            $this->newName = time();
        else
            $this->newName = $newName;
    }
    
    public function addMoreAllowedExtension(array $extension)
    {
        $this->allowedExtensions = array_merge($extension,$this->allowedExtensions);
    }
    
    protected function createDirectory($dirPath)
    {
        mkdir($dirPath);
    }
    
    public function upload(array $uploadFileAttribute, $uploadedPath)
    { 
        if(!empty($uploadFileAttribute['name'])) {
            $extension = $this->getExtension($uploadFileAttribute['name']);
            if (in_array($extension,$this->allowedExtensions)) {
                $tmp_path = $uploadFileAttribute['tmp_name'];
                
                if($this->rename) {
                    $fileName = $this->newName.'.'.$extension;
                }
                else {
                    $fileName = $uploadFileAttribute['name'];
                }
                
        
                if($this->createThumb == true) {
                   $this->thumbImageName = 'thumb_'.$fileName;
                }                
                if(is_array($uploadedPath)) {
                    $dest_path = $this->document_root;                    
                    foreach($uploadedPath as $key=>$dir) {
                        $dest_path .= '/'.$dir;
                        
                        if(!file_exists($dest_path)) {
                            $this->createDirectory($dest_path);
                        }
                    }
                }
                else {
                    $dest_path = $this->document_root .'/'.$uploadedPath;
                    
                    if(!file_exists($dest_path)) {
                        $this->createDirectory($dest_path);
                    }
                }
                //echo $this->thumbImageName;exit;
                $dirPath  = $dest_path.'/'.$this->thumbImageName;
                
                $dest_path .= '/'.$fileName;
                
                $command_convertThumb = $command_convert = "{$this->convert_path} {$tmp_path} ";
                if($this->resize) {
                    $command_convert .= '-resize '.$this->resizeOption;
                    $command_convertThumb .= '-resize '.$this->thumbResize;
                }
                 $command_convert .= $dest_path;
                 
                try {
                    if($this->createThumb == true) {
                        $command_convertThumb .= $dirPath;
                        exec($command_convertThumb);
                    }
                    $exec_command = exec($command_convert);
                    return $fileName;
                }
                catch(Exception $e) {
                    throw new Exception($e->getMessage());
                }
            }
            else {
                throw new Exception("{$extension} is not allwoed to upload. please upload only ".implode(',',$this->allowedExtensions));
            }
        }
        else {
            throw new Exception('Please Select file.');
        }
    }
    
    protected function getExtension($str) {
		$i = strrpos($str,".");
		if (!$i) { return ""; } 
		$l = strlen($str) - $i;
		$ext = substr($str,$i+1,$l);
		return strtolower($ext);
	}
}
