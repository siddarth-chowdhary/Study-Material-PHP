<?php

namespace Admin\Model;

use Zend\InputFilter\InputFilter;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class ProjectViewCount implements InputFilterAwareInterface
{
    public $projectId;
    public $userId;
    public $createdDate;
    
    protected $inputFilter;
    
    public function exchangeArray($data)
    {
         $this->projectId     = (!empty($data['projectId'])) ? $data['projectId'] : null;
         $this->userId     = (!empty($data['userId'])) ? $data['userId'] : null;
         $this->createdDate = (!empty($data['createdDate'])) ? $data['createdDate'] : '';
    }
    
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }
    
    // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
     
     public function getInputFilter() {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();

            $factory = new InputFactory();
			
            $inputFilter->add($factory->createInput(array(
                        'name' => 'projectId',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Int'),
                        ),
                        'options' => array(
                            'label' => 'Project Id',
                        ),
            )));
            $inputFilter->add($factory->createInput(array(
                        'name' => 'userId',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'Int'),
                        ),
                        'options' => array(
                            'label' => 'User Id',
                        ),
            )));
            $inputFilter->add($factory->createInput(array(
                        'name' => 'createdDate',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
                        'options' => array(
                            'label' => 'Created Date',
                        ),
            )));
            $this->inputFilter = $inputFilter;
        }
        return $this->inputFilter;
    }
}
