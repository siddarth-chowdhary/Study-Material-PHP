<?php
namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

class StateTable extends ModelTable
{
     protected $tableGateway;

     public function __construct(TableGateway $tableGateway)
     {
         $this->tableGateway = $tableGateway;
     }

     public function fetchAll($paginated=false,$countryId=NULL)
     {
         if ($paginated) {
             // create a new Select object for the table album
             $select = new Select();
             
             $select->from('state')
                    ->columns(array('stateId','stateCode','stateName','statusId'))
                    ->join('country', 'country.countryId=state.countryId', array('countryName'), Select::JOIN_LEFT);
                    
             // create a new result set based on the Album entity]
             #echo $select->getSqlString();die;
             //$resultSetPrototype = new ResultSet();
             //$resultSetPrototype->setArrayObjectPrototype(new state());
             // create a new pagination adapter object
             $paginatorAdapter = new DbSelect(
                 // our configured select object
                 $select,
                 // the adapter to run it against
                 $this->tableGateway->getAdapter()
                 // the result set to hydrate
                 //$resultSetPrototype
             );
             
            $paginator = new Paginator($paginatorAdapter);
            return $paginator;
        }
        if(!empty($countryId) || $countryId==0) {
            $resultSet = $this->tableGateway->select(array('countryId'=>$countryId));
        }
        else {
            $resultSet = $this->tableGateway->select();
        }
         return $resultSet;
     }

     public function getState($stateId)
     {
         return $this->getDetailById('stateId',$stateId);
     }

     public function saveState(State $state)
     {
         $data = array(
             'stateCode' => $state->stateCode,
             'stateName'  => $state->stateName,
             'stateCode'  => $state->stateCode,
             'countryId'  => $state->countryId,
             'statusId'  => $state->statusId,
         );

         $stateId = (int) $state->stateId;
         if ($stateId == 0) {
             $this->tableGateway->insert($data);
         } else {
             if ($this->getState($stateId)) {
                 $this->tableGateway->update($data, array('stateId' => $stateId));
             } else {
                 throw new \Exception('Country id does not exist');
             }
         }
     }

     public function deleteState($stateId)
     {
         $this->tableGateway->delete(array('stateId' => (int) $stateId));
     }
     public function getStateBycode($stateCode,$id="") { 
		
        if(empty($id)){
            $rowset = $this->tableGateway->select(array('stateCode' => $stateCode));
		} else {			
			$rowset = $this->tableGateway->select(function (select $select)use($stateCode,$id) {
				$select->where->equalto('stateCode', $stateCode)->notequalto('stateId',$id);
			});   
		}        
        $row = $rowset->current();
        if (!$row) {
            return false;
        }
        return $row;
    } 
    public function statusArray() {
        return array('0' => 'Inactive', '1' => 'Active');
    }
 }
