<?php
namespace Admin\Model;

// Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;


class TempProjectPic implements InputFilterAwareInterface
{
    public $tempId;
    public $tempProjectId;
    public $imageName;
    protected $inputFilter;

    public function exchangeArray($data)
    {
         $this->tempId     = (!empty($data['tempId'])) ? $data['tempId'] : null;
         $this->tempProjectId     = (!empty($data['tempProjectId'])) ? $data['tempProjectId'] : null;
         $this->imageName     = (!empty($data['imageName'])) ? $data['imageName'] : null;
    }
    
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }

     // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
    
    
    /*
     $validator = new Zend\Validator\Db\RecordExists(
       array(
          'table'   => 'users',
          'field'   => 'emailaddress',
          'adapter' => \Zend\Db\TableGateway\Feature\GlobalAdapterFeature::getStaticAdapter()
       )
    );
    */
    
     public function getInputFilter($passreq = false)
     {
         if (!$this->inputFilter) {
             $inputFilter = new InputFilter();

             $inputFilter->add(array(
                 'name'     => 'tempId',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
             ));

             $inputFilter->add(array(
                 'name'     => 'tempProjectId',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
                 
             ));$inputFilter->add(array(
                 'name'     => 'imageName',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'options' => array(
                    'label' => 'Image Name',
                ),
             ));

             $this->inputFilter = $inputFilter;
         }

         return $this->inputFilter;
     }

}
