<?php

namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Expression;

class ContactPrivacySettingTable extends ModelTable {

    public function fetchAll($paginated = false, $searchParam = array()) {
        if ($paginated) {
            // create a new Select object for the table chat

            $select = new Select();
            $select->from('contactPrivacySetting')
                    ->columns(array(Select::SQL_STAR))
                    ->group('contactPrivacySetting.contactSettingId');
            if (!empty($searchParam['userId'])) {
                $select->where->equalto('contactPrivacySetting.userId', $searchParam['userId']);
            }

            #echo $select->getSqlString();die;
            // create a new result set based on the chat entity
            //$resultSetPrototype = new ResultSet();
            //$resultSetPrototype->setArrayObjectPrototype(new chat());
            // create a new pagination adapter object
            $paginatorAdapter = new DbSelect(
                    // our configured select object
                    $select,
                    // the adapter to run it against
                    $this->tableGateway->getAdapter()
                    //,
                    // the result set to hydrate
                    //$resultSetPrototype
            );
            $paginator = new Paginator($paginatorAdapter);
            return $paginator;
        }
        $resultSet = $this->tableGateway->select();
        return $resultSet;
    }

    public function getContactPrivacySetting($contactSettingId) {
        $contactSettingId = (int) $contactSettingId;
        $rowset = $this->tableGateway->select(array('contactSettingId' => $contactSettingId));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $contactSettingId");
        }
        return $row;
    }
    public function getContactPrivacySettingByUidCntId($userId,$countactUserId) {
        $countactUserId = (int) $countactUserId;
        $userId = (int) $userId;
        $rowset = $this->tableGateway->select(array('userId'=>$userId,'contactUserId' => $countactUserId));
        $row = $rowset->current();
        //print_r($row);exit;
        if (!$row) {
            throw new \Exception("Could not find row");
        }
        return $row;
    }

    public function saveContactPrivacySetting(ContactPrivacySetting $contactprivacysetting) {
        $contactSettingId = (int) $contactprivacysetting->contactSettingId;
        $data=array(
            'userId'=>$contactprivacysetting->userId,
            'contactUserId'=>$contactprivacysetting->contactUserId,            
            'hideLinkedin'=>$contactprivacysetting->hideLinkedin,
            'hideProject'=>$contactprivacysetting->hideProject,
            'hideProfilePhoto'=>$contactprivacysetting->hideProfilePhoto,
            'block'=>$contactprivacysetting->block,
            'report'=>$contactprivacysetting->report,
        );
        if ($contactSettingId == 0) {//echo "<pre>";print_r($contactprivacysetting);exit;
            $this->tableGateway->insert($data);
        } else {
            if ($this->getContactPrivacySetting($contactSettingId)) {//print_r($data);exit;
                $this->tableGateway->update($data, array('contactSettingId' => $contactSettingId));
            } else {
                throw new \Exception('Setting id does not exist');
            }
        }
    }

    public function deletePrivacySetting($settingId) {
        $this->tableGateway->delete(array('settingId' => (int) $settingId));
    }
    public function deletePrivacySettingByUserId($userId) {
        $this->tableGateway->delete(array('userId' => (int) $userId));
    }
    
    public function updateContactPrivacySetting($data) {
        if ($data['colName'] == "hideLinkedin" ||
                $data['colName'] == "hideProject" ||
                $data['colName'] == "hideProfilePhoto" ||
                $data['colName'] == "block" ||
                $data['colName'] == "report"
        ) {
            $updateData = '';
            $updateData[$data['colName']] = $data['colValue'];
            try {
                $this->tableGateway->update($updateData, array('contactSettingId' => $data['contactSettingId']));
                return true;
            } catch (\Exception $e) {
                $message = $e->getMessage();
                throw new \Admin\Service\MyException($message);
            }
        } else {
            return "Error - Invalid Column Name";
        }
    }

    public function getPrivacySettingsForUser($userId) {
        $rowset = $this->tableGateway->select(array('userId' => $userId));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $userId");
        }
        return $row;
    }

}
