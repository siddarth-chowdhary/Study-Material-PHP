<?php

namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Db\Sql\Sql;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Expression;
use Zend\Db\Sql\Predicate\Expression as PredicateExpression;

class UserContactTable extends ModelTable {

    protected $tableGateway;

    public function __construct(TableGateway $tableGateway) {
        $this->tableGateway = $tableGateway;
    }

    public function fetchAll($paginated = false, $searchParams = array()) {
        if ($paginated) {
            // create a new Select object for the table album
            $select = new Select();
            $select->from('userContact')
                    ->columns(array(Select::SQL_STAR))
                    ->join(array('ls' => 'lookup_status'), 'userContact.statusId=ls.statusId',array('statusCode'), Select::JOIN_LEFT)
                    ->join(array('usr' => 'user'), 'usr.userId=userContact.receiverId',array('firstName','lastName','email','userName','phone'), Select::JOIN_INNER)
                    ->group('userContact.contactId');
            if (!empty($searchParams['userId'])) {
                $select->where->equalto('userContact.senderId', $searchParams['userId']);
            }
            
            if(!empty($searchParams['search_text'])) {
                 $select->where->addPredicate(new PredicateExpression("concat_ws('#',usr.firstName,usr.lastName,usr.userName,usr.email,usr.phone,usr.occupation,usr.skill) like '%{$searchParams['search_text']}%'"),array());
            }
            
            #echo $select->getSqlString();die;
            // create a new pagination adapter object
            $paginatorAdapter = new DbSelect(
                    // our configured select object
                    $select,
                    // the adapter to run it against
                    $this->tableGateway->getAdapter()
            );
            $paginator = new Paginator($paginatorAdapter);
            return $paginator;
        }
        $resultSet = $this->tableGateway->select();
        return $resultSet;
    }
    
    public function fetchAllUserContact($searchParams = array()) {
        $select = new Select();
        $select->from('userContact')
                ->columns(array(Select::SQL_STAR))
                ->join(array('ls' => 'lookup_status'), 'userContact.statusId=ls.statusId',array('statusCode'), Select::JOIN_LEFT)
                ->join(array('usr' => 'user'), 'usr.userId=userContact.receiverId',array('firstName','lastName','email','userName','phone','occupation'), Select::JOIN_INNER)
                ->join(array('uad' => 'userAddress'), 'uad.userId=usr.userId',array('address'), Select::JOIN_LEFT)
                ->join(array('prp'=>'profilePic'), 'prp.profilePicId=usr.profilePicId', array('profilePic','defaultPic'), Select::JOIN_LEFT)
                ->join(array('st'=>'state'), 'st.stateId=uad.stateId', array('stateName'), Select::JOIN_LEFT)
                ->join(array('cnt'=>'country'), 'cnt.countryId=uad.countryId', array('countryName'), Select::JOIN_LEFT)
                ->group('userContact.contactId');
        if (!empty($searchParams['userId'])) {
            $select->where->equalto('userContact.senderId', $searchParams['userId']);
        }
        
        if(!empty($searchParams['search_text'])) {
             $select->where->addPredicate(new PredicateExpression("concat_ws('#',usr.firstName,usr.lastName,usr.userName,usr.email,usr.phone,usr.occupation,usr.skill) like '%{$searchParams['search_text']}%'"),array());
        }
        $select->where->nest->nest->isNotNull('usr.firstName')
                ->notEqualTo('usr.firstName','')
                ->unnest()
                //->or->nest->isNotNull('usr.lastName')
                //->notEqualTo('usr.lastName','')
                //->unnest()
                ->unnest();
        
       
        $adapter = $this->tableGateway->getAdapter();
        $sql = new Sql($adapter);
        $selectString = $sql->getSqlStringForSqlObject($select);
        $results = $adapter->query($selectString, $adapter::QUERY_MODE_EXECUTE);
        if(!$results) {
            return array();
        }
        else {
            return $results;
        }
    }
    

    public function getUserContact($contactId) {
        return $this->getDetailByColumns(array('contactId' => $contactId));
    }

    public function saveUserContact(UserContact $userContact) {
        $data = array(
            'contactId' => $userContact->contactId,
            'senderId' => $userContact->senderId,
            'receiverId' => $userContact->receiverId,
            'statusId' => $userContact->statusId,
            'createdDate' => $userContact->createdDate,
            'updatedDate' => $userContact->updatedDate,
        );

        $id = (int) $userContact->contactId;
        if ($id == 0) {
            try {
                $this->tableGateway->insert($data);
            } catch (\Zend\Db\Adapter\ExceptionInterface $e) {
                $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
                throw new \Admin\Service\MyException($message);
            } catch (\Exception $e) {
                $message = $e->getMessage();
                throw new \Admin\Service\MyException($message);
            }
        } else {
            if ($this->getUserContact($id)) {
                try {
                    $this->tableGateway->update($data, array('contactId' => $id));
                } catch (\Zend\Db\Adapter\ExceptionInterface $e) {
                    $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
                    throw new \Admin\Service\MyException($message);
                } catch (\Exception $e) {
                    $message = $e->getMessage();
                    throw new \Admin\Service\MyException($message);
                }
            } else {
                throw new \Exception('User Contact id does not exist');
            }
        }
    }

    public function delete($contactId) {
        $this->tableGateway->delete(array('contactId' => (int) $contactId));
    }
    
    public function saveMultipleContact($tblName,array $data)
     {
        $this->multiInsert($tblName,$data);
     }
     
     public function getChatRequestsForContact($userId) {
        $sql = new Sql($this->tableGateway->getAdapter()); 
        $select = new Select();
        $select->from('userContact')
                ->columns(array('senderId'))
                ->join(array('usr' => 'user'), 'usr.userId=userContact.senderId', array('email', 'userName'), Select::JOIN_INNER)
        //->join(array('prp'=>'profilePic'), 'prp.profilePicId=usr.profilePicId', array('profilePic','defaultPic'), Select::JOIN_LEFT)
        ;
        if (!empty($userId)) {
            $select->where->equalto('userContact.receiverId', $userId);
            $select->where->equalto('userContact.statusId', 8);
        }
        $statement = $sql->prepareStatementForSqlObject($select);
        $results = $statement->execute();
        $resultSet = new ResultSet;
        $resultSet->initialize($results);
        $response = array();
        foreach ($resultSet as $row) {
            $response[] = $this->object_to_array($row);
        }
        return $response;
    }
    private function object_to_array($object) {
        return (array) $object;
    }

}
