<?php
namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Expression;
use Zend\Db\Sql\Predicate\Expression as PredicateExpression;


use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;

class UserTable extends ModelTable
{
    /*
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway) {
        $this->tableGateway = $tableGateway;
    }
    */
    
    public function fetchAll($paginated = false, $searchParam = array(),$loggedUserId="")
     {
         if ($paginated) {
             // create a new Select object for the table album
            $select = new Select('user');
            $select->join('lookup_status','lookup_status.statusId = user.statusId',array('statusCode'), Select::JOIN_LEFT)
                    ->join(array('uadd'=>'userAddress'), 'uadd.userId=user.userId', array('address','stateId','countryId','longitude','latitude'), Select::JOIN_LEFT)
                    ->join(array('ps'=>'privacySetting'), 'ps.userId=user.userId', array('settingId'), Select::JOIN_LEFT)
                    //->join(array('uInt'=>'userInterest'), 'uInt.userId=user.userId', array('interest1','interest2','interest3','interest'=>new Expression("concat_ws(',',interest1,interest2,interest3)")), Select::JOIN_LEFT);
                    ->join(array('uInt'=>'userInterest'), 'uInt.userId=user.userId', array('interest1','interest2','interest3'), Select::JOIN_LEFT)
                    ->join(array('c'=>'country'), 'c.countryId=uadd.countryId', array('countryName'), Select::JOIN_LEFT);
            
             
             if (isset($searchParam['loginFrom']) && ($searchParam['loginFrom'] != ""))
                $select->where->like('user.loginFrom', $searchParam['loginFrom'] . "%");
             
             if (isset($searchParam['userName']) && ($searchParam['userName'] != ""))
                $select->where->like('user.userName', $searchParam['userName'] . "%");
            
            if (isset($searchParam['firstName']) && ($searchParam['firstName'] != ""))
                $select->where->like('user.firstName', $searchParam['firstName'] . "%");

            if (isset($searchParam['lastName']) && ($searchParam['lastName'] != ""))
                $select->where->like('user.lastName', $searchParam['lastName'] . "%");

            if (isset($searchParam['email']) && ($searchParam['email'] != ""))
                $select->where->like('user.email', $searchParam['email'] . "%");

            if (isset($searchParam['phone']) && ($searchParam['phone'] != ""))
                $select->where->like('user.phone', '%'.$searchParam['phone'] . "%");

            if (isset($searchParam['createdDate']) && ($searchParam['createdDate'] != ""))
                $select->where->like('user.createdDate', $searchParam['createdDate'] . "%");

            if (isset($searchParam['updatedDate']) && ($searchParam['updatedDate'] != ""))
                $select->where->like('user.updatedDate', $searchParam['updatedDate'] . "%");
            
            if (isset($searchParam['statusId']) && ($searchParam['statusId'] != ""))
                $select->where->equalto('user.statusId', $searchParam['statusId']);
            
            if(!empty($searchParam['userType'])) {
                $select->where->equalto('user.userType', $searchParam['userType']);
            }
            if(!empty($searchParam['interest1'])) {
                $select->where->like('uInt.interest1', '%'.$searchParam['interest1'] . "%");
            }
            if(!empty($searchParam['interest2'])) {
                $select->where->like('uInt.interest2', '%'.$searchParam['interest2'] . "%");
            }
            if(!empty($searchParam['interest3'])) {
                $select->where->like('uInt.interest3', '%'.$searchParam['interest3'] . "%");
            }
            if(!empty($searchParam['country'])) {
                $select->where->like('c.countryName', '%'.$searchParam['country'] . "%");
            }
            
            
            $select->group('user.userId');
            #$select->where->notequalto('user.userTypeId',2);
           
            $select->where->notequalto('user.userId', $loggedUserId);
            #$select->where->equalto('braintreeSecureVaultIds.defaultStatus', '1');
            if(!empty($searchParam['Interest1Sort'])) {
              $select->order("uInt.interest1 ".$searchParam['Interest1Sort']."");  
            }
            else if(!empty($searchParam['Interest2Sort'])) {
              $select->order("uInt.interest2 ".$searchParam['Interest2Sort']."");  
            }
            else if(!empty($searchParam['Interest3Sort'])) {
              $select->order("uInt.interest3 ".$searchParam['Interest3Sort']."");  
            }
            else if(!empty($searchParam['countrySort'])) {
              $select->order("c.countryName ".$searchParam['countrySort'].""); 
            }else{
               $select->order('user.createdDate DESC'); 
            }
            
            #echo $select->getSqlString();die;
             
             
             // create a new result set based on the User entity
             //$resultSetPrototype = new ResultSet();
             //$resultSetPrototype->setArrayObjectPrototype(new User());
             // create a new pagination adapter object
             $paginatorAdapter = new DbSelect(
                 // our configured select object
                 $select,
                 // the adapter to run it against
                 $this->tableGateway->getAdapter()
                 // the result set to hydrate
                 //$resultSetPrototype
             );
             $paginator = new Paginator($paginatorAdapter);
             return $paginator;
        }
        
        /*
         * if(!empty($searchParam['notequalto']) && is_array($searchParam['notequalto'])) {
                foreach($searchParam['notequalto'] as $key=>$val) {
                    $select->where->notequalto($key,$val);
                }
            }
         */
        $resultSet = $this->tableGateway->select($searchParam);
        return $resultSet;
     }
     
     public function getUserByColumn($column,$val)
     {
         return $this->getDetailByColumns(array($column=>$val));
     }
     
    
	public function getUser($id) {
        $id  = (int) $id;
        $select = new Select();
        $select->from('user')
                ->columns(array(select::SQL_STAR))
                ->join(array('uadd'=>'userAddress'), 'uadd.userId=user.userId', array('address','stateId','countryId','longitude','latitude'), Select::JOIN_LEFT)
                //->join(array('uInt'=>'userInterest'), 'uInt.userId=user.userId', array('interest'=>new Expression("concat_ws(',',interest1,interest2,interest3)")), Select::JOIN_LEFT)                
                ->join(array('uInt'=>'userInterest'), 'uInt.userId=user.userId', array('interest1','interest2','interest3'), Select::JOIN_LEFT)
                ->where->equalto('user.userId',$id);
        $adapter = $this->tableGateway->getAdapter();
        $sql = new Sql($adapter);
        $selectString = $sql->getSqlStringForSqlObject($select);
        $results = $adapter->query($selectString, $adapter::QUERY_MODE_EXECUTE);
        $row = $results->current();
        if (empty($row->userId)) {
            throw new \Exception("Could not find row $id");
        }
        
        return $row;
    }
     public function saveUser(User $user)
     {            
         $dateObj = new \DateTime('NOW');
         $data = array(
            'userId' => $user->userId,
            'loginFrom' => $user->loginFrom,
            'userType' => $user->userType,
            'userName' => $user->userName,
            'firstName' => $user->firstName,
            'lastName' => $user->lastName,
            'profilePicId' => $user->profilePicId,
            'email' => $user->email,
            'phone' => $user->phone,
            'accessToken' => $user->accessToken,
            'password' => $user->password,
            'statusId' => $user->statusId,
            'occupation' => $user->occupation,
            'gender' => $user->gender,
            'skill' => $user->skill,
            'updatedDate' => !empty($user->updatedDate) ? $user->updatedDate : $dateObj->format('Y-m-d:H:i:s'),
        );

         $id = (int) $user->userId;
         if ($id == 0) {
            try {
                $data['createdDate'] = !empty($user->createdDate) ? $user->createdDate : $dateObj->format('Y-m-d:H:i:s');
                $this->tableGateway->insert($data);
            }
            catch(\Zend\Db\Adapter\ExceptionInterface $e) {
                 $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
                throw new \Admin\Service\MyException($message);
            }
            catch (\Exception $e) {
                $message = $e->getMessage();
                throw new \Admin\Service\MyException($message);
            }
         } else {
             if ($this->getUser($id)) {
                try {
                    $this->tableGateway->update($data, array('userId' => $id));
                }
                catch(\Zend\Db\Adapter\ExceptionInterface $e) {
                     $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
                    throw new \Admin\Service\MyException($message);
                }
                catch (\Exception $e) {
                    $message = $e->getMessage();
                    throw new \Admin\Service\MyException($message);
                }
            }
            else {
                throw new \Exception('User id does not exist');
            }
         }
     }

    public function deleteUser($id)
    {
         $this->tableGateway->delete(array('userId' => (int) $id));
    }
    
	public function genderArray() {		
		return array('0' => 'Unspecified', '1' => 'Male','2'=>'Female');
	}

	public function userTypeArray() {
		return array('1' => 'Admin', '2' => 'Website User');
	}

	public function statusArray() 
	{
		return array('0' => 'Inactive', '1' => 'Active');
	}
	public function loginFromArray() {
        return array('0' => 'user_id', '1' => 'email', '2'=>'phone');
    }
    
    public function getUserList($searchParam=array()) {
       
        $select = new Select();
        $select->from('user')
                ->columns(array(select::SQL_STAR,'gender'=>new Expression('CASE WHEN gender = 0 THEN "Unspecified" WHEN gender = 1 THEN "Male" else "Female" END')))
                ->join(array('prp'=>'profilePic'), 'prp.profilePicId=user.profilePicId', array('profilePic','defaultPic'), Select::JOIN_LEFT)
                ->join(array('uadd'=>'userAddress'), 'uadd.userId=user.userId', array('address','stateId','countryId','longitude','latitude'), Select::JOIN_LEFT)
                ->join(array('st'=>'state'), 'st.stateId=uadd.stateId', array('stateName'), Select::JOIN_LEFT)
                ->join(array('cnt'=>'country'), 'cnt.countryId=uadd.countryId', array('countryName'), Select::JOIN_LEFT);
        
        if(!empty($searchParam['userType'])) {
        $select->where->equalto('user.userType', $searchParam['userType']);
        }
        if(!empty($searchParam['statusId'])) {
        $select->where->equalto('user.statusId', $searchParam['statusId']);
        }
        if(!empty($searchParam['search_text'])) {
        $select->where->addPredicate(new predicateExpression("concat_ws('#',user.email,user.phone,user.userName) like '%{$searchParam['search_text']}%'"));
        }
        if(!empty($searchParam['privacySetting'])) {
            $select->join(array('p_set'=>'privacySetting'),'p_set.userId = user.userId',array());
            $hideMeBy = $searchParam['privacySetting'];
            if(!empty($hideMeBy['search'])) {
                $select->where->equalTo('p_set.findMeBySearch',1);
            }
            
            if(!empty($hideMeBy['phone'])) {
                $select->where->equalTo('p_set.findMeByPhone',1);
            }
            
            if(!empty($hideMeBy['email'])) {
                $select->where->equalTo('p_set.findMeByEmail',1);
            }
        }
        
        if(!empty($searchParam['notequalto'])) {
            foreach($searchParam['notequalto'] as $key=>$val){
            $select->where->notEqualTo('user.'.$key, $val);
            }
        }
        if(!empty($searchParam['excludeUser']) && $searchParam['excludeUser']===true){
            $subSelect= new Select('userContact');
                    $subSelect->columns(array('receiverId'))
                    ->where->equalto('userContact.senderId', $searchParam['notequalto']['userId']);
            
            $select->where->notIn('user.userId',$subSelect);           
 
        }
        $select->order('user.firstName ASC');
        $adapter = $this->tableGateway->getAdapter();
        $sql = new Sql($adapter);
        $selectString = $sql->getSqlStringForSqlObject($select);
        $results = $adapter->query($selectString, $adapter::QUERY_MODE_EXECUTE);        
        return $results;
    }
    
    public function getDetailByPhone($param) {
       
        $select = new Select();
        $select->from('user')
                ->columns(array(select::SQL_STAR));
        if(!empty($param['userType'])) {
            $select->where->equalto('userType',$param['userType']);
        }
        if(!empty($param['phone'])) {
            $select->where->addPredicate(new predicateExpression("if(LOCATE('-',phone) <> 0,SUBSTRING(phone,(LOCATE('-',phone)+1)),phone) = '".$param['phone']."'"));
        }
        if(!empty($param['accessToken'])) {
            $select->where->equalto('accessToken',$param['accessToken']);
        }
        if(!empty($param['statusId'])) {
            $select->where->equalto('statusId',$param['statusId']);
        }
        
                
        #echo $select->getSqlString();exit;        
        $adapter = $this->tableGateway->getAdapter();
        $sql = new Sql($adapter);
        $selectString = $sql->getSqlStringForSqlObject($select);
        $results = $adapter->query($selectString, $adapter::QUERY_MODE_EXECUTE);        
        $row = $results->current();
        if(!$row) {
            throw new \Exception('RECORD_NOT_FOUND');
        }
        return $row;
    }
    
    public function exchangeStatus($data,$userId){
        
        $id  = (int) $userId;        
        $this->tableGateway->update($data, array('userId' => $id));        
    }

    public function verifyUserAccount(array $params)
    {
        try {
            $strpos = strpos($params['phone'], '-');
            
             if (empty($strpos)) {
                //$phone=substr($params['phone'], strpos($params['phone'], "-") + 1);
                $userDetail = $this->getDetailByPhone(array('phone'=>$params['phone'],'accessToken'=>$params['securityCode']));                
            } else {
                $userDetail = $this->getDetailByColumns(array('phone'=>$params['phone'],'accessToken'=>$params['securityCode']));
            }
            //echo $userDetail->statusId;exit;
            $userStatus = (int) $userDetail->statusId;
            if($userStatus !== 1) { // check whether user's status is active or not if active throw exception
                $dateObj = new \DateTime('NOW');
                $data = array(
                        'accessToken'=>NULL
                        ,'statusId'=>1
                        ,'updatedDate'=>$dateObj->format('Y-m-d H:i:s')
                    );
                $this->tableGateway->update($data, array('userId' => $userDetail->userId));
                $userDetail_new = $this->verifyPasswordToken(array('user_name'=>$userDetail->userName,'password_token'=>$userDetail->password));
                return $userDetail_new;
            }
            else {
                throw new \Exception('ACCOUNT_ACTIVATED');
            }
        }
        catch(\Exception $e) {
            
            if($e->getMessage() == 'ACCOUNT_ACTIVATED') {
                throw new \Exception('Account already verified');
            }           
            throw new \Exception('Either phone number or access token is not valid');
        }
    }
    
    protected function getUserDetailSelect()
    {
        $select = new Select();
        $select->from('user')
                ->columns(
                    array(
                        'userId'
                        ,'firstName'
                        ,'lastName'
                        ,'gender'=>new Expression('CASE WHEN gender = 0 THEN "Unspecified" WHEN gender = 1 THEN "Male" else "Female" END')
                        ,'genderId'=>'gender'
                        ,'userName'
                        ,'password_token'=>'password'
                        ,'email'
                        ,'phone'
                        ,'occupation'
                        ,'skill'
                        ,'userName'
                    )
                )
                ->join(array('uadd'=>'userAddress'), 'uadd.userId=user.userId', array('address','stateId','countryId','longitude','latitude'), Select::JOIN_LEFT)
                ->join(array('uInt'=>'userInterest'), 'uInt.userId=user.userId', array('interest1','interest2','interest3'), Select::JOIN_LEFT)
                ->join(array('cnt'=>'country'), 'cnt.countryId=uadd.countryId', array('countryName'), Select::JOIN_LEFT)
                ->join(array('pic'=>'profilePic'),'pic.profilePicId = user.profilePicId',array('profilePic'), Select::JOIN_LEFT)
                ->join(array('st'=>'state'), 'st.stateId=uadd.stateId', array('stateName'), Select::JOIN_LEFT)
                ->where->equalto('user.statusId',1)
                ->where->equalto('userType',2);
        
            return $select;
    }
    
    public function verifyPasswordToken(array $params) {
        $select = $this->getUserDetailSelect();
        $select->where->equalto('password',$params['password_token'])
            ->where->equalto('userName',$params['user_name']);
        #echo $select->getSqlString();exit;
        $adapter = $this->tableGateway->getAdapter();
        $sql = new Sql($adapter);
        $selectString = $sql->getSqlStringForSqlObject($select);
        
        $results = $adapter->query($selectString, $adapter::QUERY_MODE_EXECUTE);
        $row = $results->current();
        if(!$row) {
            throw new \Exception('user name or password token mismatch');
        }
        
        return $row;
    }
    
    public function updateUserSettings(array $params,$userId)
    {
        if(!empty($userId)) {
            try {
                $this->tableGateway->update($params, array('userId' => $userId));
            }
            catch(\Exception $e) {
                throw new \Exception($e->getMessage());
            }
        }
        else {
            throw new \Exception('User Id should not be blank');
        }
    }
    
    public function apiUserLogin(array $params) {
        $select = $this->getUserDetailSelect();
        $strpos = strpos($params['user_name'], '-');
        if(empty($strpos)){
            $select->where->equalto('password',$params['password'])
            ->where->nest->equalto('userName',$params['user_name'])
            ->or->equalto('email',$params['user_name'])
            ->orPredicate(new predicateExpression("if(LOCATE('-',phone) <> 0,SUBSTRING(phone,(LOCATE('-',phone)+1)),phone) = '".$params['user_name']."'"))
            ->unnest();         
        }else{
        $select->where->equalto('password',$params['password'])
            ->where->nest->equalto('userName',$params['user_name'])
            ->or->equalto('email',$params['user_name'])
            ->or->equalto('phone',$params['user_name'])
            ->unnest();
        }        
        $adapter = $this->tableGateway->getAdapter();
        $sql = new Sql($adapter);
        $selectString = $sql->getSqlStringForSqlObject($select);
        
        $results = $adapter->query($selectString, $adapter::QUERY_MODE_EXECUTE);
        $row = $results->current();
        if(!$row) {
            throw new \Exception('User Does not exist');
        }
        
        return $row;
    }
    
    public function getValidUserIdsFromStringList($listStr,$aliasName,$userId,$delimeter = ',')
    {
        if($delimeter != ',') {
            $listStr = str_replace($delimeter,',',$listStr);
        }
        
        $select = new Select();
        $select->from('user')
                ->columns(array($aliasName=>new Expression('group_concat(userId)')))
                ->where->equalTo('statusId',1)
                ->where->equalTo('userType',2)
                ->where->notEqualTo('userId',$userId)
                ->where->addPredicate(new predicateExpression("FIND_IN_SET(userId,'{$listStr}')",array()));
        
        $adapter = $this->tableGateway->getAdapter();
        $sql = new Sql($adapter);
        $selectString = $sql->getSqlStringForSqlObject($select);
        
        $results = $adapter->query($selectString, $adapter::QUERY_MODE_EXECUTE);
        $row = $results->current();
        if(!$row) {
            throw new \Exception('Please provide Valid user Ids');
        }
        else {
            return $row[$aliasName];
        }
    }
    
    public function searchLocationUser(array $params)
    {
        $select = new Select();
        $select->from(array('u'=>'user'))
                ->columns(array('userId','firstName','lastName','gender','userName','email','phone','occupation','skill','occupation'))
                ->join(array('ua'=>'userAddress'),'ua.userId=u.userId',array('address','longitude','latitude'))
                ->join(array('p_set'=>'privacySetting'),'p_set.userId = u.userId',array('hideProject'), Select::JOIN_LEFT)
                ->join(array('c'=>'country'),'c.countryId = ua.countryId',array('countryIsoCode','countryName'))
                ->join(array('s'=>'state'),'s.stateId = ua.stateId',array('stateCode','stateName'), Select::JOIN_LEFT)
                ->join(array('u_pic'=>'profilePic'),new Expression('u.userId = u_pic.userId and u_pic.defaultPic = 1'),array('profilePic'), Select::JOIN_LEFT)
                ->where->isNotNull('ua.longitude')
                ->where->isNotNull('ua.latitude')
                ->where->notEqualTo('ua.latitude','')
                ->where->notEqualTo('ua.longitude','')
                ->where->equalTo('p_set.findMeBySearch',1)
                ->where->equalTo('u.statusId',1)
                ->where->equalTo('u.userType',2);
        if(!empty($params['notequalto']['userId'])) {
            $select->where->notEqualTo('u.userId',$params['notequalto']['userId']);
        }
        if(!empty($params['search_txt'])) {
            $select->where->addPredicate(new PredicateExpression("concat_ws('#',ua.address,u.firstName,u.lastName,u.userName,u.email,u.phone,u.occupation,u.skill,c.countryName,s.stateName) like '%{$params['search_txt']}%'"),array());
        }
        //echo $select->getSqlString();die;
        $adapter = $this->tableGateway->getAdapter();
        $sql = new Sql($adapter);
        $selectString = $sql->getSqlStringForSqlObject($select);
        
        $results = $adapter->query($selectString, $adapter::QUERY_MODE_EXECUTE);
        if(!$results) {
            return new \stdClass();
        }
        
        return $results;
    }
    
    public function searchUsers($searchParam = array()) {
        //var_dump($searchParam);die("here");
        $sql = new Sql($this->tableGateway->getAdapter());

        $select = new Select('user');
        $select->join('lookup_status', 'lookup_status.statusId = user.statusId', array('statusCode'), Select::JOIN_LEFT)
                ->join(array('uadd' => 'userAddress'), 'uadd.userId=user.userId', array('address', 'stateId', 'countryId', 'longitude', 'latitude'), Select::JOIN_LEFT)
                ->join(array('ps' => 'privacySetting'), 'ps.userId=user.userId', array('settingId'), Select::JOIN_LEFT)
                //->join(array('uInt'=>'userInterest'), 'uInt.userId=user.userId', array('interest1','interest2','interest3','interest'=>new Expression("concat_ws(',',interest1,interest2,interest3)")), Select::JOIN_LEFT);
                ->join(array('uInt' => 'userInterest'), 'uInt.userId=user.userId', array('interest1', 'interest2', 'interest3'), Select::JOIN_LEFT);

        if (isset($searchParam['firstName']) && ($searchParam['firstName'] != ""))
            $select->where->OR->like('user.firstName', $searchParam['firstName'] . "%");
        
        if (isset($searchParam['lastName']) && ($searchParam['lastName'] != ""))
            $select->where->OR->like('user.lastName', $searchParam['lastName'] . "%");

        if (isset($searchParam['email']) && ($searchParam['email'] != ""))
            $select->where->OR->like('user.email', $searchParam['email'] . "%");

        if (isset($searchParam['phone']) && ($searchParam['phone'] != ""))
            $select->where->OR->like('user.phone', '%' . $searchParam['phone'] . "%");
        
//        if (isset($searchParam['countryId']) && ($searchParam['countryId'] != ""))
//            $select->where->like('uadd.countryId', '%' . $searchParam['countryId'] . "%");

        $select->group('user.userId');
        
        #echo $select->getSqlString();die;
        #$select->where->notequalto('user.userTypeId',2);

        $statement = $sql->prepareStatementForSqlObject($select);
        $results = $statement->execute();
        $resultSet = new ResultSet;
        $resultSet->initialize($results);
        $response = array();
        foreach ($resultSet as $row) {
            $response[] = $this->object_to_array($row);
        }
        return $response;
    }

    function object_to_array($object) {
        return (array) $object;
    }
    
    public function changeLoginUserStatusToDeleted($userId){
        
        $data=array('statusId'=>9);        
        if ($userId) {
                try {
                    $this->tableGateway->update($data, array('userId' => $userId));
                }
                catch(\Zend\Db\Adapter\ExceptionInterface $e) {
                     $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
                    throw new \Admin\Service\MyException($message);
                }
                catch (\Exception $e) {
                    $message = $e->getMessage();
                    throw new \Admin\Service\MyException($message);
                }
            }
            else {
                throw new \Exception('User id does not exist');
            }
        
    }
    
}
