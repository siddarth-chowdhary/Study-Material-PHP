<?php
namespace Admin\Model;

// Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;


class ChatUser implements InputFilterAwareInterface
{
    public $chatId;
    public $userId;
    public $visibility;
    public $password;

    public function exchangeArray($data)
    {
         $this->chatId     = (!empty($data['chatId'])) ? $data['chatId'] : null;
         $this->userId = (!empty($data['userId'])) ? $data['userId'] : null;
         $this->visibility  = (!empty($data['visibility'])) ? $data['visibility'] : null;
         $this->password  = (!empty($data['password'])) ? $data['password'] : null;
    }
    
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }

     // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
    
     public function getInputFilter()
     {
         if (!$this->inputFilter) {
             $inputFilter = new InputFilter();

             $inputFilter->add(array(
                 'name'     => 'chatId',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
             ));

             $inputFilter->add(array(
                 'name'     => 'userId',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
             ));
             $inputFilter->add(array(
                 'name'     => 'visibility',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
             ));
             

             $inputFilter->add(array(
                 'name'     => 'password',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 1,
                             'max'      => 100,
                         ),
                     ),
                 ),
             ));

             $this->inputFilter = $inputFilter;
         }

         return $this->inputFilter;
     }

}
