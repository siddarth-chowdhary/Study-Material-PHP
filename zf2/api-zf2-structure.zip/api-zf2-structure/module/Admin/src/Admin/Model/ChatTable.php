<?php

namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Expression;

class ChatTable extends ModelTable {

    protected $tableGateway;

    public function __construct(TableGateway $tableGateway) {
        $this->tableGateway = $tableGateway;
    }

    public function fetchAll($paginated = false, $searchParam = array()) {
        if ($paginated) {
            // create a new Select object for the table chat

            $selectType = new Select();
            $selectType->from('chatUser')
                    ->columns(array('cnt' => new Expression('count(*)'), 'chatId', 'userId' => new Expression('group_concat(userId)')))
                    ->group('chatId');

            $select = new Select();
            $select->from('chat')
                    ->columns(array(Select::SQL_STAR))
                    ->join(array('cu' => 'chatUser'), 'cu.chatId = chat.chatId', array('chatType' => new Expression("if(x.cnt > 2, 'Group', 'Individual')")), Select::JOIN_LEFT)
                    ->join(array('ls' => 'lookup_status'), 'cu.visibility=ls.statusId', array('statusCode'))
                    ->join(array('x' => $selectType), 'x.chatId = cu.chatId', array())
                    ->group('chat.chatId');
            if (!empty($searchParam['userId'])) {
                $select->where->equalto('cu.userId', $searchParam['userId']);
            }

            #echo $select->getSqlString();die;
            // create a new result set based on the chat entity
            //$resultSetPrototype = new ResultSet();
            //$resultSetPrototype->setArrayObjectPrototype(new chat());
            // create a new pagination adapter object
            $paginatorAdapter = new DbSelect(
                    // our configured select object
                    $select,
                    // the adapter to run it against
                    $this->tableGateway->getAdapter()
                    //,
                    // the result set to hydrate
                    //$resultSetPrototype
            );
            $paginator = new Paginator($paginatorAdapter);
            return $paginator;
        }
        $resultSet = $this->tableGateway->select();
        return $resultSet;
    }

    public function getChat($chatId) {
        $chatId = (int) $chatId;
        $rowset = $this->tableGateway->select(array('chatId' => $chatId));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }

    public function saveChat(Chat $chat) {
        $dateObj = new \DateTime('NOW');
        $data = array(
            'createdDate' => !empty($chat->createdDate) ? $chat->createdDate : $dateObj->format('Y-m-d:H:i:s'),
        );

        $chatId = (int) $chat->chatId;
        if ($chatId == 0) {
            $this->tableGateway->insert($data);
        } else {
            if ($this->getChat($chatId)) {
                $this->tableGateway->update($data, array('chatId' => $chatId));
            } else {
                throw new \Exception('Chat id does not exist');
            }
        }
    }

    public function deleteChat($chatId) {
        $this->tableGateway->delete(array('chatId' => (int) $chatId));
    }

    public function fetchChatReceiverData($paginated = false, $searchParam = array()) {


        if ($paginated) {
            // create a new Select object for the table chat
           
            $select = new Select();
            $select->from('message')
                    ->columns(array(Select::SQL_STAR,'receiver' => new Expression('group_concat(concat(us.firstName," ",us.lastName,"#",ls.statusCode))')))
                    ->join(array('mr' => 'messageReceiver'), 'mr.messageId=message.messageId', array())
                    ->join(array('u' => 'user'), 'u.userId=message.userId', array('firstName','lastName'))
                    ->join(array('us' => 'user'), 'us.userId=mr.userId', array())
                    ->join(array('ls' => 'lookup_status'), 'mr.statusId = ls.statusId', array())
                    ->group('mr.messageId');          
            if (!empty($searchParam['chatId'])) {
                $select->where->equalto('chatId', $searchParam['chatId']);
                $select->where->notEqualTo('message.userId', 'mr.userId');
            }
            
            //echo $select->getSqlString();die;

            // create a new pagination adapter object
            $paginatorAdapter = new DbSelect(
                    // our configured select object
                    $select,
                    // the adapter to run it against
                    $this->tableGateway->getAdapter()
                    //,
                    // the result set to hydrate
                    //$resultSetPrototype
            );
            $paginator = new Paginator($paginatorAdapter);
            return $paginator;
        }
        $resultSet = $this->tableGateway->select();
        return $resultSet;
    }

}
