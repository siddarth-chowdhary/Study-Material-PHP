<?php
namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Expression;

class ProjectImageTable extends ModelTable
{
     protected $tableGateway;

     public function __construct(TableGateway $tableGateway)
     {
         $this->tableGateway = $tableGateway;
     }

     public function fetchAll($paginated=false,$searchParam=array())
     {
         if ($paginated) {
             // create a new Select object for the table album
             $select = new Select();
             
             $select->from(array('pi'=>'projectImage'))
                    ->columns(array(select::SQL_STAR))
                    ->join('project', 'project.projectId=pi.projectId', array('projectName'), Select::JOIN_LEFT);
            
            if(!empty($searchParam['projectId'])) {
                $select->where->equalto('pi.projectId', $searchParam['projectId']);
            }
                    
             
             #echo $select->getSqlString();die;
             //$resultSetPrototype = new ResultSet();
             //$resultSetPrototype->setArrayObjectPrototype(new Project());
             // create a new pagination adapter object
             $paginatorAdapter = new DbSelect(
                 // our configured select object
                 $select,
                 // the adapter to run it against
                 $this->tableGateway->getAdapter()
                 // the result set to hydrate
                 //$resultSetPrototype
             );
             
             $paginator = new Paginator($paginatorAdapter);
             
            # echo '<pre>';print_r($paginator);echo '</pre>';
             return $paginator;
         }
         
         $resultSet = $this->tableGateway->select();
         return $resultSet;
     }

     public function getProjectImage($imageId)
     {
         return $this->getDetailById('imageId',$imageId);
     }

     public function saveProjectImage(ProjectImage $project)
     {
         $data = array(
            'imageId' => $project->imageId,
            'projectId'  => $project->projectId,
            'image'  => $project->image,
        );

        $imageId = (int) $project->imageId;
        if ($imageId == 0) {
            try {
                $this->tableGateway->insert($data);
            }
            catch(\Zend\Db\Adapter\ExceptionInterface $e) {
                 $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
                throw new \Admin\Service\MyException($message);
            }
            catch (\Exception $e) {
                $message = $e->getMessage();
                throw new \Admin\Service\MyException($message);
            }
        }
        else {
            if ($this->getProject($projectId)) {
                try {
                    $this->tableGateway->update($data, array('imageId' => $imageId));
                }
                catch(\Zend\Db\Adapter\ExceptionInterface $e) {
                     $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
                    throw new \Admin\Service\MyException($message);
                }
                catch (\Exception $e) {
                    $message = $e->getMessage();
                    throw new \Admin\Service\MyException($message);
                }
            }
            else {
                throw new \Exception('Project Image does not exist');
            }
        }
    }

    public function deleteProjectImage($imageId,$projectId)
    {
        $this->tableGateway->delete(array('imageId' => (int) $imageId,'projectId' => (int) $projectId));
    }
    public function getProjectByName($projectName,$id="") { 
        if(empty($id)){
            $rowset = $this->tableGateway->select(array('projectName' => $projectName));
        }
        else {
			$rowset = $this->tableGateway->select(function (select $select)use($projectName,$id) {
				$select->where->equalto('projectName', $projectName)->notequalto('projectId',$id);
			});   
		}        
        $row = $rowset->current();
        if (!$row) {
            return false;
        }
        return $row;
    }    
 }
