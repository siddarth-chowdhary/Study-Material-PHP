<?php
namespace Admin\Model;

// Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;


class Chat implements InputFilterAwareInterface
{
    public $chatId;
    public $createdDate;
    protected $inputFilter;

    public function exchangeArray($data)
    {
         $dateObj = new \DateTime('NOW');
         $this->chatId     = (!empty($data['chatId'])) ? $data['chatId'] : null;
         $this->createdDate = (!empty($data['createdDate'])) ? $data['createdDate'] : $dateObj->format('Y-m-d H:i:s');
    }
    
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }

     // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
    
    
    /*
     $validator = new Zend\Validator\Db\RecordExists(
       array(
          'table'   => 'users',
          'field'   => 'emailaddress',
          'adapter' => \Zend\Db\TableGateway\Feature\GlobalAdapterFeature::getStaticAdapter()
       )
    );
    */
    
     public function getInputFilter($passreq = false)
     {
         if (!$this->inputFilter) {
             $inputFilter = new InputFilter();

             $inputFilter->add(array(
                 'name'     => 'chatId',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
             ));

             $inputFilter->add(array(
                 'name'     => 'userId',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
                 
             ));
             
             $inputFilter->add(array(
                 'name'     => 'statusId',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
                 
             ));
             
             $inputFilter->add(array(
                 'name'     => 'password',
                 'required' => $passreq,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',                             
                         ),
                     ),
                 ),
             ));
             
             $inputFilter->add(array(
                 'name'     => 'user_id',
                 'required' => false,
                 
             ));
             
             $inputFilter->add(array(
                 'name'     => 'message',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
             ));

             $this->inputFilter = $inputFilter;
         }

         return $this->inputFilter;
     }

}
