<?php
namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Adapter\Platform\Sql92;
use Zend\Db\Sql\Sql;

class ModelTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway) {
        $this->tableGateway = $tableGateway;
    }
    
    public function executeSelectObject(Select $select,$echo = '')
    {
        $adapter = $this->tableGateway->getAdapter();
        $sql = new Sql($adapter);
        $selectString = $sql->getSqlStringForSqlObject($select);
        if($echo != '') {
            die($selectString);
        }
        $rowset = $adapter->query($selectString, $adapter::QUERY_MODE_EXECUTE);
        return $rowset;
    }
    
    public function getDetailById($primaryKey,$id)
    {
        $id  = (int) $id;        
        $rowset = $this->tableGateway->select(array($primaryKey => $id));        
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    
    public function getDetailByColumns(array $params,$count=1)
    {
        $rowset = $this->tableGateway->select($params);
        if($count == 1) {
            $row = $rowset->current();
        }
        else {
            $row = $rowset;
        }
        
        if (!$row) {
            throw new \Exception("Could not find row ". implode(',',$params));
        }
        return $row;
    }
    
    public function realEscapeValue($value)
    {
        $adapter = $this->tableGateway->getAdapter();
        $platform = $adapter->getPlatform();
        return $platform->quoteValue($value);
    }
    
    
    protected function multiInsert($table, array $data)
    {
        
        if (count($data)) {
            $columns = (array)current($data);
            $columns = array_keys($columns);
            $columnsCount = count($columns);
            $adapter = $this->tableGateway->getAdapter();
            $platform = $adapter->getPlatform();
            \array_filter($columns, function (&$item) use ($platform) {
                $item = $platform->quoteIdentifier($item);
            });
            $columns = "(" . implode(',', $columns) . ")";
            

            $placeholder = array_fill(0, $columnsCount, '?');
            $placeholder = "(" . implode(',', $placeholder) . ")";
            $placeholder = implode(',', array_fill(0, count($data), $placeholder));

            $values = array();
            foreach ($data as $row) {
                foreach ($row as $key => $value) {
                    $values[] = $value;
                }
            }


            $table = $platform->quoteIdentifier($table);
            $q = "INSERT INTO $table $columns VALUES $placeholder";
            try {
                $this->tableGateway->getAdapter()->query($q)->execute($values);
            }
            catch(\Exception $e){
                die($e->getMessage());
            }
        }
    }
    
    public function lastInsertedValue(){
		return $this->tableGateway->lastInsertValue;
	}
}
