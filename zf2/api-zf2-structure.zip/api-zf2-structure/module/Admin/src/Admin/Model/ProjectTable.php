<?php
namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Expression;
use Zend\Db\Sql\Sql;

class ProjectTable extends ModelTable
{
     protected $tableGateway;

     public function __construct(TableGateway $tableGateway)
     {
         $this->tableGateway = $tableGateway;
     }

     public function fetchAll($paginated=false,$searchParams = array())
     {
         #echo '<pre>';print_r($searchParams);die;
         if ($paginated) {
             // create a new Select object for the table album
            $select = new Select();
             
            $select->from('project')
                    ->columns(array('projectId','projectName','projectDetail','visibility','createdDate'))
                    ->join('user', 'user.userId=project.userId', array('createdBy'=>new Expression('case when user.lastName is NOT NUll then concat(user.firstName," ", user.lastName) else user.firstName END')), Select::JOIN_LEFT)
                    ->join('lookup_status', 'lookup_status.statusId=project.visibility', array('statusCode'), Select::JOIN_LEFT);
            if(!empty($searchParams['projectName'])) {
                $select->where->like('project.projectName', '%'.$searchParams['projectName'] . "%");
            }
            if(!empty($searchParams['statusCode'])) {
                $select->where->like('project.visibility', '%'.$searchParams['statusCode'] . "%");
            }
            if(!empty($searchParams['createdDate'])) {
                $select->where->like('project.createdDate', '%'.$searchParams['createdDate'] . "%");
            }
            if(!empty($searchParams['createdBy'])) {
                $select->where->nest
                    ->addPredicate (new \Zend\Db\Sql\Predicate\Expression("concat(firstName,' ',lastName) like '%".$searchParams['createdBy']."%' or concat(lastName,' ',firstName) like '%".$searchParams['createdBy']."%' "),array())
                    ->unnest();
            }
            $select->order('project.createdDate DESC');
             // create a new result set based on the Album entity]
             #echo $select->getSqlString();die;
             //$resultSetPrototype = new ResultSet();
             //$resultSetPrototype->setArrayObjectPrototype(new Project());
             // create a new pagination adapter object
             $paginatorAdapter = new DbSelect(
                 // our configured select object
                 $select,
                 // the adapter to run it against
                 $this->tableGateway->getAdapter()
                 // the result set to hydrate
                 //$resultSetPrototype
             );
             
             $paginator = new Paginator($paginatorAdapter);
             
            # echo '<pre>';print_r($paginator);echo '</pre>';
             return $paginator;
         }
         
         $resultSet = $this->tableGateway->select();
         return $resultSet;
     }

     public function getProject($projectId)
     {
         return $this->getDetailById('projectId',$projectId);
     }
    
    public function getProjectByUserId($userId,$count=1)
    {
        $select = new Select();
        $select->from('project')
                ->columns(array('projectCount'=>new Expression('count(*)'),Select::SQL_STAR))
                ->join(array('l_status'=>'lookup_status'),'l_status.statusId = project.visibility',array('statusCode'))
                ->order('projectId')
                ->where->equalTo('userId',$userId);
        //var_dump( $select->getSqlString() );
        
        $rowset = $this->executeSelectObject($select);
        
        if($count == 1) {
            $row = $rowset->current();
        }
        else {
            $row = $rowset;
        }
        if (!$row) {
            throw new \Exception("Could not find rows for column {$userId}");
        }
        return $row;
    }
    
    /**
     * 
     * @param type $userId
     * @return type
     * This function returns all projects in db where visibility is 4 i.e. visible
     */
    public function searchProject($userId = '')
     {
         $select = new Select();
         $select->from('project')
                ->columns(
                    array(
                        'projectId'
                        ,'projectOwnerUserId' =>'userId'
                        ,'projectName'
                        ,'projectDetail'
                        ,'minuteDiff'=>new Expression('abs(TIMESTAMPDIFF(MINUTE,CURRENT_TIMESTAMP(),project.createdDate))')
                    )
                )
                ->join(array('p_v_count'=>'projectViewCount'),'p_v_count.projectId = project.projectId',array('views'=>new Expression('count(p_v_count.projectId)')), Select::JOIN_LEFT)
                ->join(array('u'=>'user'),'u.userId=project.userId',array())
                ->join(array('c_p_s'=>'contactPrivacySetting'),'c_p_s.contactUserId = u.userId',array('hideProject'), Select::JOIN_LEFT)
                ->group('project.projectId')
                ->where->equalTo('u.statusId',1)
                ->where->equalTo('project.visibility',4);
        
        //echo $select->getSqlString();die;        
        $rowset = $this->executeSelectObject($select);
        
        if (!$rowset) {
            throw new \Exception("Could not find rows");
        }
        return $rowset;

    }
     
    public function getProjectListOfUser($userId) {
        $select  = new Select();
        $select->from('project')
            ->columns(
                array(
                    'projectId'
                    ,'projectName'
                    ,'lockProjectDetail'
                    ,'visibility'
                    ,'createdDate'=>new Expression('date_format(date(project.createdDate), "%d/%m/%Y")')
                    ,'updatedDate'=>new Expression('date_format(date(project.updatedDate), "%d/%m/%Y")')
                    ,'userAction'=>new Expression('if(date_format(date(project.createdDate), "%Y-%m-%d") = date_format(date(project.updatedDate), "%Y-%m-%d"),"createdDate","updatedDate")')
                )
            )
            ->join(array('u'=>'user'),'u.userId=project.userId',array())
            ->join(array('p_v_count'=>'projectViewCount'),'p_v_count.projectId = project.projectId',array('views'=>new Expression('count(p_v_count.projectId)')), Select::JOIN_LEFT)
            ->join(array('ls'=>'lookup_status'),'ls.statusId=project.visibility',array('visibilityStatus'=>'statusCode'))
            ->join(array('p_img'=>'projectImage'),'p_img.projectId=project.projectId',array('photos'=>new Expression('count(p_img.projectId)')), Select::JOIN_LEFT)
            ->group('project.projectId')
            ->where->EqualTo('project.userId',$userId);
        
        $rowset = $this->executeSelectObject($select);
        if (!$rowset) {
            throw new \Exception("Could not find rows for column {$userId}");
        }
        return $rowset;
    }
    
     public function saveProject(Project $project)
     {
         $data = array(
            'projectName' => $project->projectName,
            'projectDetail'  => $project->projectDetail,
            'projectName'  => $project->projectName,
            'userId'  => $project->userId,
            'visibility'  => $project->visibility,
            'updatedDate' => $project->updatedDate,
            'lockProjectDetail' => $project->lockProjectDetail,
        );

        $projectId = (int) $project->projectId;
        if ($projectId == 0) {
            try {
                $data['createdDate'] = $project->createdDate;
                $this->tableGateway->insert($data);
            }
            catch(\Zend\Db\Adapter\ExceptionInterface $e) {
                 $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
                throw new \Admin\Service\MyException($message);
            }
            catch (\Exception $e) {
                $message = $e->getMessage();
                throw new \Admin\Service\MyException($message);
            }
        }
        else {
            if ($this->getProject($projectId)) {
                try {
                    $this->tableGateway->update($data, array('projectId' => $projectId));
                }
                catch(\Zend\Db\Adapter\ExceptionInterface $e) {
                     $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
                    throw new \Admin\Service\MyException($message);
                }
                catch (\Exception $e) {
                    $message = $e->getMessage();
                    throw new \Admin\Service\MyException($message);
                }
            }
            else {
                throw new \Exception('Project does not exist');
            }
        }
    }

    public function deleteProject($projectId)
    {
        $this->tableGateway->delete(array('projectId' => (int) $projectId));
    }
    public function getProjectByName($projectName,$id="") { 
        if(empty($id)){
            $rowset = $this->tableGateway->select(array('projectName' => $projectName));
        }
        else {
			$rowset = $this->tableGateway->select(function (select $select)use($projectName,$id) {
				$select->where->equalto('projectName', $projectName)->notequalto('projectId',$id);
			});   
		}        
        $row = $rowset->current();
        if (!$row) {
            return false;
        }
        return $row;
    }
    
 }
