<?php
namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

class ProjectViewCountTable extends ModelTable
{
    public function fetchAll($paginated = false, $searchParam = array())
    {
        
    }
    
    public function saveProjectCount(ProjectViewCount $projectView)
    {
         $data = array(
            'addressId' => $projectView->projectId,
            'userId' => $projectView->userId,
            'address' => $projectView->address
        );
        $id = (int) $projectView->projectId;
        if ($id == 0) {
            $this->tableGateway->insert($data);
        } else {
            if ($this->getUser($id)) {
                $this->tableGateway->update($data, array('projectId' => $id,'userId'=>$userId));
            } else {
                throw new \Exception('User Address id does not exist');
            }
        }
    }
    
    
    public function save(ProjectViewCount $projectView) {
        $data = array(
            'projectId' => $projectView->projectId,
            'userId' => $projectView->userId,
            'createdDate' => $projectView->createdDate,
        );
        try {
            $this->tableGateway->insert($data);
            return true;
        } catch (\Exception $e) {
            $message = $e->getMessage();
            throw new \Admin\Service\MyException($message);
        }
    }

}

