<?php

namespace Admin\Model;

use Zend\InputFilter\InputFilter;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class User implements InputFilterAwareInterface
{
    public $userId;
    public $userType;
    public $userName;
    public $loginFrom;
    public $firstName;
    public $lastName;
    public $gender;
    public $profilePicId;
    public $email;
    public $phone;
    public $password;
    public $accessToken;
    public $occupation;
    public $skill;
    public $statusId;
    public $createdDate;
    public $updatedDate;
    /*public $address;
    public $stateId;
    public $countryId;
    public $longitude;
    public $latitude;
    public $userInterest;*/
    
    protected $inputFilter,$apiInputFilter;
    
    public function exchangeArray($data)
    {
         $dateObj = new \DateTime('NOW');
         $this->userId     = (!empty($data['userId'])) ? $data['userId'] : null;
         $this->userType = (!empty($data['userType'])) ? $data['userType'] : 2;
         $this->userName = (!empty($data['userName'])) ? $data['userName'] : null;
         $this->loginFrom  = (!empty($data['loginFrom'])) ? $data['loginFrom'] : 0;
         $this->firstName  = (!empty($data['firstName'])) ? $data['firstName'] : null;
         $this->lastName  = (!empty($data['lastName'])) ? $data['lastName'] : null;
         $this->gender  = (!empty($data['gender'])) ? $data['gender'] : '0';
         $this->profilePicId  = (!empty($data['profilePicId'])) ? $data['profilePicId'] : 0;
         $this->email  = (!empty($data['email'])) ? $data['email'] : null;
         if(!empty($data['countryPhoneCode']) && !empty($data['phone'])){
           $data['phone']= $data['countryPhoneCode'].'-'.$data['phone']; 
         }         
         $this->phone  = (!empty($data['phone'])) ? $data['phone'] : null;
         $this->password  = (!empty($data['password'])) ? $data['password'] : null;
         $this->accessToken  = (!empty($data['accessToken'])) ? $data['accessToken'] : null;
         $this->occupation  = (!empty($data['occupation'])) ? $data['occupation'] : null;
         $this->skill  = (!empty($data['skill'])) ? $data['skill'] : null;
         $this->statusId  = (!empty($data['statusId'])) ? $data['statusId'] : 2;
         $this->createdDate  = (!empty($data['createdDate'])) ? $data['createdDate'] : $dateObj->format('Y-m-d H:i:s');
         $this->updatedDate  = (!empty($data['updatedDate'])) ? $data['updatedDate'] : $dateObj->format('Y-m-d H:i:s');
    }
    
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }
    
    // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
     
     public function getInputFilter() {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();

            $factory = new InputFactory();
			
            $inputFilter->add($factory->createInput(array(
                        'name' => 'userId',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Int'),
                        ),
                        'options' => array(
                            'label' => 'UserId',
                        ),
            )));
            $inputFilter->add($factory->createInput(array(
                        'name' => 'userType',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'Int'),
                        ),
                        'options' => array(
                            'label' => 'UserType',
                        ),
            )));
            $inputFilter->add($factory->createInput(array(
                        'name' => 'userName',
                        'required' => true,
                         'filters'  => array(
                            array('name' => 'StripTags'),
                            array('name' => 'StringTrim'),
						),
                        'options' => array(
                            'label' => 'userName',
                        ),
                'validators' => array(
                array(
                    'name' => 'StringLength',
                    'options' => array(
                        'encoding' => 'UTF-8',
                        'min' => 6,
                        'max' => 20,
                        'message' => array(
                            'The input should be 6-20 characters long'
                        ),
                    ),
                ),
            ),
            )));
            $inputFilter->add($factory->createInput(array(
                        'name' => 'loginFrom',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Int'),
                        ),
                        'options' => array(
                            'label' => 'LoginFrom',
                        ),
            )));
            $inputFilter->add($factory->createInput(array(
                        'name' => 'firstName',
                        'required' => true,
                        'filters'  => array(
							array('name' => 'StripTags'),
                            array('name' => 'StringTrim'),
						),
                        'options' => array(
                            'label' => 'FirstName',
                        ),
                        /*'validators' => array(
                            array(
                                'name' => 'StringLength',
                                'options' => array(
                                    'encoding' => 'UTF-8',
                                    'min' => 2,
                                    'max' => 30,
                                ),
                            ),
                        ),*/
                        'validators' => array(
                            array(
                                'name' => 'regex',
                                'options' => array(
                                    'pattern' => '/^[[:alpha:]]*$/'
                                    ,'message' => array(
                                        'Only Alpha keyword are allowed'
                                    ),
                                ),
                            ),
                        )
            )));
            $inputFilter->add($factory->createInput(array(
                        'name' => 'lastName',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StripTags'),
                            array('name' => 'StringTrim'),
                        ),
                        'options' => array(
                            'label' => 'LastName',
                        ),
                        'validators' => array(
                            array(
                                'name' => 'regex'
                                ,'options' => array(
                                    'pattern' => '/^[[:alpha:]]*$/'
                                    ,'message' => array(
                                        'Only Alpha keyword are allowed'
                                    ),
                                ),
                            ),
                        )
            )));
            $inputFilter->add($factory->createInput(array(
                        'name' => 'email',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StripTags'),
                            array('name' => 'StringTrim'),
                        ),
                        'options' => array(
                            'label' => 'Email',
                        ),
                        /*
                        'validators'=>array(
                            'name'=>'EmailAddress'
                            ,'options'=>array(
                                'domain' => false
                                ,'useMxCheck'  => false
                            ),
                        ),*/
                       
            )));
             $inputFilter->add($factory->createInput(array(
                        'name' => 'countryPhoneCode',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StripTags'),
                            array('name' => 'StringTrim'),
                        ),
                        
                        'validators'=>array( 
                            array(
                                'name'=>'NotEmpty',
                                'break_chain_on_failure' => true,
                                'options'=>array(
                                    'message' => array('Country phone code is required'),
                                ),
                            ),
                            array(
                                'name' => 'StringLength',
                                'break_chain_on_failure' => true,
                                'options' => array(
                                    'encoding' => 'UTF-8',
                                    'min' => 1,
                                    'max' => 19,
                                    'message' => array(
                                    'The input is less than 1 characters long'
                            ),
                                ),
                            ),
                        ),
                       
            )));
            
            $inputFilter->add($factory->createInput(array(
                        'name' => 'phone',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StripTags'),
                            array('name' => 'StringTrim'),
                        ),
                        'options' => array(
                            'label' => 'Phone',
                        ),
                        'validators' => array(
                            array(
                                'name' => 'StringLength',
                                'options' => array(
                                    'encoding' => 'UTF-8',
                                    'min' => 5,
                                    'max' => 19,
                                    'message' => array(
										'The input is less than 5 characters long'
									),
                                ),
                            ),
                        ),
            )));
            
            $inputFilter->add($factory->createInput(array(
                        'name' => 'password',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StripTags'),
                            array('name' => 'StringTrim'),
                        ),
                        'options' => array(
                            'label' => 'Password',
                        ),
                        'attributes' => array(
							'placeholder' => 'Password',
							'id' => 'password',
						),
                        'validators' => array(
                            array(
                                'name' => 'StringLength',
                                'options' => array(
                                    'encoding' => 'UTF-8',
                                    'min' => 5,
                                    'max' => 64,
                                ),
                            ),
                        ),
            )));
           
            $inputFilter->add($factory->createInput(array(
                        'name' => 'occupation',
						'required' => false,
						'filters' => array(
							array('name' => 'StripTags'),
							array('name' => 'StringTrim')
						),
						'options' => array(
							'label' => 'Occupation',
						),
						'validators' => array(
							array(
								'name' => 'StringLength',
								'options' => array(
									'encoding' => 'UTF-8',
									'min' => 1,
									'max' => 100,
								),
							),
							
						),
            )));
            $inputFilter->add($factory->createInput(array(
                        'name' => 'skill',
						'required' => false,
						'filters' => array(
							array('name' => 'StripTags'),
							array('name' => 'StringTrim')
						),
						'options' => array(
							'label' => 'Skill',
						),
						'validators' => array(
							array(
								'name' => 'StringLength',
								'options' => array(
									'encoding' => 'UTF-8',
									'min' => 1,
									'max' => 100,
								),
							),
							
						),
            )));
            
        $inputFilter->add($factory->createInput(array(
            'name' => 'interest',
            'required' => false,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Interest',
            ),
            'validators' => array(
                    array(
                            'name' => 'StringLength',
                            'options' => array(
                                    'encoding' => 'UTF-8',
                                    'min' => 1,
                                    'max' => 100,
                            ),
                    ),

            ),
        )));
        $inputFilter->add($factory->createInput(array(
            'name' => 'interest2',
            'required' => false,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Interest2',
            ),
            'validators' => array(
                    array(
                            'name' => 'StringLength',
                            'options' => array(
                                    'encoding' => 'UTF-8',
                                    'min' => 1,
                                    'max' => 100,
                            ),
                    ),

            ),
        )));
        $inputFilter->add($factory->createInput(array(
            'name' => 'interest3',
            'required' => false,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Interest3',
            ),
            'validators' => array(
                    array(
                            'name' => 'StringLength',
                            'options' => array(
                                    'encoding' => 'UTF-8',
                                    'min' => 1,
                                    'max' => 100,
                            ),
                    ),

            ),
        )));
        
        $inputFilter->add($factory->createInput(array(
            'name' => 'countryId',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'options' => array(
                'label' => 'Country',
            ),
        )));
        $inputFilter->add($factory->createInput(array(
            'name' => 'stateId',
            'required' => false,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'options' => array(
                'label' => 'State',
            ),
        )));
        
        $inputFilter->add($factory->createInput(array(
            'name' => 'address',  
            'required' => true,
            'options' => array(
                'label' => 'Address',
            ),
            'validators' => array(
                    array(
                            'name' => 'StringLength',
                            'options' => array(
                                    'encoding' => 'UTF-8',
                                    'min' => 1,
                                    'max' => 254,
                            ),
                    ),

            ),
        )));
        $inputFilter->add($factory->createInput(array(
                        'name' => 'gender',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'Int'),
                        ),
                        'options' => array(
                            'label' => 'Gender',
                        ),
            )));
            $this->inputFilter = $inputFilter;
        }
        return $this->inputFilter;
    }
    
     // API Form input filter
    
    public function getApiInputFilter($updateForm = false) {
        if(!$this->apiInputFilter) {
            $apiInputFilter = new InputFilter();
            $apiInputFilter->add(array(
                'name' => 'userId',
                'required' => false,
                'filters' => array(
                    array('name' => 'Int'),
                ),
                'options' => array(
                    'label' => 'UserId',
                ),
            ));
            
            $apiInputFilter->add(array(
                        'name' => 'user_name',
                        'required' => ($updateForm === true) ? true : false,
                         'filters'  => array(
                            array('name' => 'StripTags'),
                            array('name' => 'StringTrim'),
						),
                        'options' => array(
                            'label' => 'User Name',
                        ),
                'validators' => array(
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'User Name is required',
                        ),
                    ),
                    array(
                        'name' => 'StringLength',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min' => 6,
                            'max' => 20,
                            'message' => 'The input should be 6-20 characters long',
                        ),
                    ),
                ),
            ));
            $apiInputFilter->add(array(
                        'name' => 'password_token',
                        'required' => ($updateForm === true) ? true : false,
                         'filters'  => array(
                            array('name' => 'StringTrim'),
						),
                        'options' => array(
                            'label' => 'Password Token',
                        ),
                'validators' => array(
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'Password Token is required',
                        ),
                    ),
                    array(
                        'name' => 'StringLength',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min' => 40, // its min size of sha1 hash string. actually sha1 will create hash string of length 40
                            'max' => 50, // but for precaution we are taking 10 more length
                            'message' => 'The input should be 40-50 characters long',
                        ),
                    ),
                ),
            ));
            $apiInputFilter->add(array(
                        'name' => 'firstName',
                        'required' => true,
                        'filters'  => array(
							array('name' => 'StripTags'),
                            array('name' => 'StringTrim'),
						),
                        'options' => array(
                            'label' => 'FirstName',
                        ),
                        'validators' => array(
                            array(
                                'name'=>'NotEmpty',
                                'options'=>array(
                                    'message' => 'First name is required',
                                ),
                                'break_chain_on_failure' => true,
                            ),
                            array(
                                'name' => 'regex',
                                'options' => array(
                                    'pattern' => '/^[[:alpha:]]*$/'
                                    ,'message' => 'Only Alpha keyword are allowed',
                                ),
                                'break_chain_on_failure' => true
                            ),
                            
                        )
            ));
            
            $apiInputFilter->add(array(
                        'name' => 'phone',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StripTags'),
                            array('name' => 'StringTrim'),
                        ),
                        'options' => array(
                            'label' => 'Phone',
                        ),
                        'validators' => array(
                            array(
                                'name'=>'NotEmpty',
                                'break_chain_on_failure' => true,
                                'options'=>array(
                                    'message' => 'Phone is required',
                                ),
                            ),
                            array(
                                'name' => 'StringLength',
                                'break_chain_on_failure' => true,
                                'options' => array(
                                    'encoding' => 'UTF-8',
                                    'min' => 8,
                                    'max' => 15,
                                    'message' => 'Phone number must contain min 8 characters',
                                ),
                            ),
                        ),
            ));
            
            $apiInputFilter->add(array(
                        'name' => 'lastName',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StripTags'),
                            array('name' => 'StringTrim'),
                        ),
                        'options' => array(
                            'label' => 'LastName',
                        ),
                        'validators' => array(
                             array(
                                'name'=>'NotEmpty',
                                'break_chain_on_failure' => true,
                                'options'=>array(
                                    'message' => 'Last Name is required',
                                ),
                            ),
                            array(
                                'name' => 'regex'
                                ,'options' => array(
                                    'pattern' => '/^[[:alpha:]]*$/'
                                    ,'message' => 'Only Alpha keyword are allowed',
                                ),
                            ),
                        )
            ));
            $apiInputFilter->add(array(
                        'name' => 'latitude',
                        'required' => false,
                        'options' => array(
                            'label' => 'Latitude',
                        ),
                        'validators' => array(
                            array(
                                'name'=>'Float',
                                'options'=>array(
                                    'message'=>'Latitude should be float/real value'
                                ),
                            ),
                        )
            ));
            $apiInputFilter->add(array(
                        'name' => 'longitude',
                        'required' => false,
                        'options' => array(
                            'label' => 'Longitude',
                        ),
                        'validators' => array(
                            array(
                                'name'=>'Float',
                                'options'=>array(
                                    'message'=>'Longitude should be float/real value'
                                ),
                            ),
                        )
            ));
            $apiInputFilter->add(array(
                        'name' => 'password',
                        'required' => ($updateForm === true) ? false : true,
                        'filters' => array(
                            array('name' => 'StripTags'),
                            array('name' => 'StringTrim'),
                        ),
                        'options' => array(
                            'label' => 'Password',
                        ),
                        'attributes' => array(
							'placeholder' => 'Password',
							'id' => 'password',
						),
                        'validators' => array(
                            array(
                                'name'=>'NotEmpty',
                                'break_chain_on_failure' => true,
                                'options'=>array(
                                    'message' => 'Password is required',
                                ),
                            ),
                            array(
                                'name' => 'StringLength',
                                'break_chain_on_failure' => true,
                                'options' => array(
                                    'encoding' => 'UTF-8',
                                    'min' => 5,
                                    'max' => 64,
                                    'message'=>'Password length should be between 5-20 charactor long'
                                ),
                            ),
                        ),
            ));
            $this->apiInputFilter = $apiInputFilter;
        }
        return $this->apiInputFilter;
     }
}
