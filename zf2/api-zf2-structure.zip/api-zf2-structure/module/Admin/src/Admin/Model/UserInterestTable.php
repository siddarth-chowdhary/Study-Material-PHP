<?php

namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Sql;

class UserInterestTable extends ModelTable {

    public function fetchAll($paginated = false) {
        if ($paginated) {
            // create a new Select object for the table album
            $select = new Select('userInterest');
            // create a new result set based on the Album entity
            $resultSetPrototype = new ResultSet();
            $resultSetPrototype->setArrayObjectPrototype(new LookupInterest());
            // create a new pagination adapter object
            $paginatorAdapter = new DbSelect(
                    // our configured select object
                    $select,
                    // the adapter to run it against
                    $this->tableGateway->getAdapter(),
                    // the result set to hydrate
                    $resultSetPrototype
            );
            $paginator = new Paginator($paginatorAdapter);
            return $paginator;
        }
        $resultSet = $this->tableGateway->select();
        return $resultSet;
    }

    public function getInterests($userId) {
        $userId = (int) $userId;
        $select = new Select();
        $select->from('userInterest')
                ->columns(array(Select::SQL_STAR))
        ->where->equalto('userId', $userId);
        $adapter = $this->tableGateway->getAdapter();
        $sql = new Sql($adapter);
        $selectString = $sql->getSqlStringForSqlObject($select);

        $results = $adapter->query($selectString, $adapter::QUERY_MODE_EXECUTE);
        $row = $results->current();
        if (empty($row)) {
            throw new \Exception("Could not find row $userId");
        }
        return $row;
    }

    public function saveUserInterest(UserInterest $userInterest) {
        $interest = explode(',', $userInterest->interest1);
        $this->deleteLookupInterest($userInterest->userId);
        $data['userId'] = $userInterest->userId;
        $count = 1;
        if (isset($userInterest->interest1) && $userInterest->interest1 != '') {
            $data['interest1'] = $userInterest->interest1;
        }
        if (isset($userInterest->interest2) && $userInterest->interest2 != '') {
            $data['interest2'] = $userInterest->interest2;
        }
        if (isset($userInterest->interest3) && $userInterest->interest3 != '') {
            $data['interest3'] = $userInterest->interest3;
        }
        /* foreach($interest as $key=>$val) {
          if(empty($val))
          continue;

          if($count<=3) {
          $data['interest'.$count] =  $val;
          $count++;
          }
          else {
          break;
          }
          } */
        #echo "<pre>";print_r($data);exit;
        $this->tableGateway->insert($data);
    }

    public function deleteLookupInterest($userId) {
        $this->tableGateway->delete(array('userId' => (int) $userId));
    }

}
