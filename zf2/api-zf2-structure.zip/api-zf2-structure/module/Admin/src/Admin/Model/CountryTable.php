<?php
namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;


class CountryTable extends ModelTable
{
     public function fetchAll($paginated=false,$column = array())
     {
         if ($paginated) {
             // create a new Select object for the table album
             $select = new Select('country');
             // create a new result set based on the Album entity
             $resultSetPrototype = new ResultSet();
             $resultSetPrototype->setArrayObjectPrototype(new country());
             // create a new pagination adapter object
             $paginatorAdapter = new DbSelect(
                 // our configured select object
                 $select,
                 // the adapter to run it against
                 $this->tableGateway->getAdapter(),
                 // the result set to hydrate
                 $resultSetPrototype
             );
             $paginator = new Paginator($paginatorAdapter);
             return $paginator;
         }
         
         if(!empty($column) && $paginated === false) {
            //$where = new \Zend\Db\Sql\Where();
            //$where->in('vehicle_id', $vehiclesIds);

            //$having = new \Zend\Db\Sql\Having();
            //$having->expression('count(*) = ?', count($vehiclesIds));

            $rowset = $this->tableGateway->select(function (Select $select) use ($column) {
                $select->columns($column)
                        ->where->isNotNull('countryPhoneCode')
                        ->where->notEqualTo('countryPhoneCode','');

                //var_dump( $select->getSqlString() );
            });
            //die;
            if (!$rowset) {
                throw new \Exception("Could not find schemas for group $groupId");
            }
            return $rowset;
         }
         $resultSet = $this->tableGateway->select();
         return $resultSet;
     }

     public function getCountry($countryId)
     {
         $countryId  = (int) $countryId;
         $rowset = $this->tableGateway->select(array('countryId' => $countryId));
         $row = $rowset->current();
         if (!$row) {
             throw new \Exception("Could not find row $id");
         }
         return $row;
     }

     public function saveCountry(Country $country)
     {
         $data = array(
             'countryCode' => $country->countryCode,
             'countryName'  => $country->countryName,
             'countryPhoneCode'  => $country->countryPhoneCode,
             'countryIsoCode'  => $country->countryIsoCode,
         );

         $countryId = (int) $country->countryId;
         if ($countryId == 0) {
             $this->tableGateway->insert($data);
         } else {
             if ($this->getCountry($countryId)) {
                 $this->tableGateway->update($data, array('countryId' => $countryId));
             } else {
                 throw new \Exception('Country id does not exist');
             }
         }
     }

     public function deleteCountry($countryId)
     {
         $this->tableGateway->delete(array('countryId' => (int) $countryId));
     }
     public function getCountryBycode($countryCode,$id="") { 
		
        if(empty($id)){			
			$rowset = $this->tableGateway->select(array('countryCode' => $countryCode));
		} else {			
			$rowset = $this->tableGateway->select(function (select $select)use($countryCode,$id) {
				$select->where->equalto('countryCode', $countryCode)->notequalto('countryId',$id);
			});   
		}        
        $row = $rowset->current();      
        if (!$row) {
            return false;
        }
        return $row;
    } 
 }
