<?php
namespace Admin\Model;
 
use Zend\Authentication\Storage;
use Zend\Session\ManagerInterface as SessionManager;
 
class MyAuthStorage extends Storage\Session
{
    public function __construct($namespace = null, $member = null, SessionManager $manager = null){
        return parent::__construct($namespace,$member,$manager);
    }
    public function setRememberMe($rememberMe = 0, $time = 1209600)
    {
         if ($rememberMe == 1) {
             $this->session->getManager()->rememberMe($time);
         }
    }
     
    public function forgetMe()
    {
        $this->session->getManager()->forgetMe();
    }
}
