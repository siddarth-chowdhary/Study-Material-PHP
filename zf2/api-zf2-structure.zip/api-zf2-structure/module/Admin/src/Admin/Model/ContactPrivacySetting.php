<?php
namespace Admin\Model;

// Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;


class ContactPrivacySetting implements InputFilterAwareInterface
{
    public $contactSettingId;
    public $userId;
    public $contactUserId;
    public $hideLinkedin;
    public $hideProject;
    public $hideProfilePhoto;
    public $block;
    public $report;
    protected $inputFilter;
    

    public function exchangeArray($data) {
        $this->contactSettingId = (!empty($data['contactSettingId'])) ? $data['contactSettingId'] : null;
        $this->userId = (!empty($data['userId'])) ? $data['userId'] : null;
        $this->contactUserId = (!empty($data['contactUserId'])) ? $data['contactUserId'] : null;
        $this->hideLinkedin = (!empty($data['hideLinkedin'])) ? $data['hideLinkedin'] : 1;
        $this->hideProject = (!empty($data['hideProject'])) ? $data['hideProject'] : 1;
        $this->hideProfilePhoto = (!empty($data['hideProfilePhoto'])) ? $data['hideProfilePhoto'] : 1;
        $this->block = (!empty($data['block'])) ? $data['block'] : 1;
        $this->report = (!empty($data['report'])) ? $data['report'] : 1;
    }

    public function getArrayCopy()
    {
        return get_object_vars($this);
    }

     // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
    
    
    /*
     $validator = new Zend\Validator\Db\RecordExists(
       array(
          'table'   => 'users',
          'field'   => 'emailaddress',
          'adapter' => \Zend\Db\TableGateway\Feature\GlobalAdapterFeature::getStaticAdapter()
       )
    );
    */
    
     public function getInputFilter($passreq = false)
     {
         if (!$this->inputFilter) {
             $inputFilter = new InputFilter();

             $inputFilter->add(array(
                 'name'     => 'contactSettingId',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
             ));



             $this->inputFilter = $inputFilter;
         }

         return $this->inputFilter;
     }

}
