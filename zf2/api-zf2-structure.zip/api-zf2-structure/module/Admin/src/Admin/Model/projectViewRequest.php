<?php
namespace Admin\Model;

// Add these import statements
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;
use DateTime;

class projectViewRequest implements InputFilterAwareInterface
{
    public $requestId;
    public $projectId;
    public $userId;
    public $statusId;
    public $createdDate;
    
    protected $inputFilter;

    public function exchangeArray($data)
    {
         $this->requestId     = (!empty($data['requestId'])) ? $data['requestId'] : null;
         $this->projectId = (!empty($data['projectId'])) ? $data['projectId'] : null;
         $this->userId  = (!empty($data['userId'])) ? $data['userId'] : null;
         $this->statusId  = (!empty($data['statusId'])) ? $data['statusId'] : null;
         $this->createdDate = (!empty($data['createdDate'])) ? $data['createdDate'] : '';
    }
    
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }

     // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
    
     public function getInputFilter()
     {
         if (!$this->inputFilter) {
             $inputFilter = new InputFilter();

             $inputFilter->add(array(
                 'name'     => 'requestId',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
             ));
             $inputFilter->add(array(
                'name'     => 'projectId',
                'required' => true,
                'filters'  => array(
                    array('name' => 'Int'),
                ),
                'options' => array(
                    'label' => 'Project Id',
                ),
             ));
             $inputFilter->add(array(
                'name'     => 'userId',
                'required' => true,
                'filters'  => array(
                    array('name' => 'Int'),
                ),
                'options' => array(
                    'label' => 'user Id',
                ),
             ));
             $inputFilter->add(array(
                'name'     => 'statusId',
                'required' => true,
                'filters'  => array(
                    array('name' => 'Int'),
                ),
                'options' => array(
                    'label' => 'status Id',
                ),
             ));

             $this->inputFilter = $inputFilter;
         }

         return $this->inputFilter;
     }

}
