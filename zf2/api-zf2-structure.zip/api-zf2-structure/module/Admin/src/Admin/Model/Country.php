<?php
namespace Admin\Model;

// Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;


class Country implements InputFilterAwareInterface
{
    public $countryId;
    public $countryCode;
    public $countryName;
    public $countryPhoneCode;
    public $countryIsoCode;
    protected $inputFilter;

    public function exchangeArray($data)
    {
         $this->countryId     = (!empty($data['countryId'])) ? $data['countryId'] : null;
         $this->countryCode = (!empty($data['countryCode'])) ? $data['countryCode'] : null;
         $this->countryName  = (!empty($data['countryName'])) ? $data['countryName'] : null;
         $this->countryPhoneCode  = (!empty($data['countryPhoneCode'])) ? $data['countryPhoneCode'] : null;
         $this->countryIsoCode  = (!empty($data['countryIsoCode'])) ? $data['countryIsoCode'] : null;
    }
    
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }

     // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
    
    
    /*
     $validator = new Zend\Validator\Db\RecordExists(
       array(
          'table'   => 'users',
          'field'   => 'emailaddress',
          'adapter' => \Zend\Db\TableGateway\Feature\GlobalAdapterFeature::getStaticAdapter()
       )
    );
    */
    
     public function getInputFilter()
     {
         if (!$this->inputFilter) {
             $inputFilter = new InputFilter();

             $inputFilter->add(array(
                 'name'     => 'countryId',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
             ));

             $inputFilter->add(array(
                 'name'     => 'countryCode',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                    array('name'=>'Alpha'),
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 3,
                             'max'      => 3,
                         ),
                     ),
                 ),
             ));
             $inputFilter->add(array(
                 'name'     => 'countryIsoCode',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                    array('name'=>'Alpha'),
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 2,
                             'max'      => 2,
                         ),
                     ),
                 ),
             ));
             $inputFilter->add(array(
                 'name'     => 'countryPhoneCode',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                    array('name'=>'Digits'),
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 1,
                             'max'      => 4,
                         ),
                     ),
                 ),
             ));

             $inputFilter->add(array(
                 'name'     => 'countryName',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 1,
                             'max'      => 60,
                         ),
                     ),
                 ),
             ));

             $this->inputFilter = $inputFilter;
         }

         return $this->inputFilter;
     }

}
