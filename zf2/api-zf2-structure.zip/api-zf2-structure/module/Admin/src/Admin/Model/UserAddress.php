<?php

namespace Admin\Model;

use Zend\InputFilter\InputFilter;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class UserAddress implements InputFilterAwareInterface
{
    public $addressId;
    public $userId;
    public $address;
    public $countryId;
    public $stateId;
    public $longitude;
    public $latitude;
    
    protected $inputFilter;
    
    public function exchangeArray($data)
    {
         $this->addressId     = (!empty($data['addressId'])) ? $data['addressId'] : null;
         $this->userId     = (!empty($data['userId'])) ? $data['userId'] : null;
         $this->address = (!empty($data['address'])) ? $data['address'] : '';
         $this->countryId  = (!empty($data['countryId'])) ? $data['countryId'] : 0;
         $this->stateId  = (!empty($data['stateId'])) ? $data['stateId'] : 0;
         $this->longitude  = (!empty($data['longitude'])) ? $data['longitude'] : null;
         $this->latitude  = (!empty($data['latitude'])) ? $data['latitude'] : null;
    }
    
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }
    
    // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
     
     public function getInputFilter() {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();

            $factory = new InputFactory();
			
            $inputFilter->add($factory->createInput(array(
                        'name' => 'addressId',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Int'),
                        ),
                        'options' => array(
                            'label' => 'Address Id',
                        ),
            )));
            $inputFilter->add($factory->createInput(array(
                        'name' => 'userId',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'Int'),
                        ),
                        'options' => array(
                            'label' => 'User Id',
                        ),
            )));
            $inputFilter->add($factory->createInput(array(
                        'name' => 'stateId',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'Int'),
                        ),
                        'options' => array(
                            'label' => 'State Id',
                        ),
            )));
            $inputFilter->add($factory->createInput(array(
                        'name' => 'address',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
                        'options' => array(
                            'label' => 'Address',
                        ),
            )));
            $inputFilter->add($factory->createInput(array(
                        'name' => 'longitude',
                        'required' => true,
                        'allow_empty'=>true,
                        'filters'  => array(
							array('name' => 'StringTrim'),
						),
                        'options' => array(
                            'label' => 'Longitude',
                        ),
                        'validators' => array(
                            array(
                                'name' => 'step',
                            ),
                        )
            )));
            $inputFilter->add($factory->createInput(array(
                        'name' => 'latitude',
                        'required' => true,
                        'allow_empty'=>true,
                        'filters'  => array(
							array('name' => 'StringTrim'),
						),
                        'options' => array(
                            'label' => 'Latitude',
                        ),
                        'validators' => array(
                            array(
                                'name' => 'step',
                            ),
                        )
            )));
            $this->inputFilter = $inputFilter;
        }
        return $this->inputFilter;
    }
}
