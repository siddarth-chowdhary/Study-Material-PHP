<?php
namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

class UserAddressTable extends ModelTable
{
    public function fetchAll($paginated = false, $searchParam = array(),$loggedUserId="")
    {
        if ($paginated) {
            // create a new Select object for the table album
            $select = new Select('userAddress');

            if (isset($searchParam['address']) && ($searchParam['address'] != ""))
                $select->where->like('userAddress.address', "%". $searchParam['address'] . "%");


            //echo $select->getSqlString();die;
            // create a new result set based on the User entity
            $resultSetPrototype = new ResultSet();
            $resultSetPrototype->setArrayObjectPrototype(new UserAddress());
            // create a new pagination adapter object
            $paginatorAdapter = new DbSelect(
                // our configured select object
                $select,
                // the adapter to run it against
                $this->tableGateway->getAdapter(),
                // the result set to hydrate
                $resultSetPrototype
            );
            $paginator = new Paginator($paginatorAdapter);
            return $paginator;
        }
        $resultSet = $this->tableGateway->select();
        return $resultSet;
    }
    
	public function getUserAddress($id) {
        return $this->getDetailById('addressId',$id);
    }
     public function saveUserAddress(UserAddress $userAddress)
     {
         $data = array(
            'addressId' => $userAddress->addressId,
            'userId' => $userAddress->userId,
            'address' => $userAddress->address,
            'countryId' => $userAddress->countryId,
            'stateId' => $userAddress->stateId,
            'longitude' => $userAddress->longitude,
            'latitude' => $userAddress->latitude,
        );
        $id = (int) $userAddress->addressId;
        if ($id == 0) {
            $this->deleteAddressByUserId($userAddress->userId);
            $this->tableGateway->insert($data);
        } else {
            if ($this->getUser($id)) {
                $this->tableGateway->update($data, array('addressId' => $id));
            } else {
                throw new \Exception('User Address id does not exist');
            }
        }
    }

    public function deleteAddressByUserId($userId)
    {
        $this->tableGateway->delete(array('userId' => (int) $userId));
    }
    public function deleteUserAddress($id)
    {
         $this->tableGateway->delete(array('addressId' => (int) $id));
    }
}
