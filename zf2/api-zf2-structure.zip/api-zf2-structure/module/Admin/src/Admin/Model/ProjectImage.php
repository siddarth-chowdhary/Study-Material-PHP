<?php
namespace Admin\Model;

// Add these import statements
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;
use DateTime;

class ProjectImage implements InputFilterAwareInterface
{
    public $imageId;
    public $projectId;
    public $image;
    
    protected $inputFilter;

    public function exchangeArray($data)
    {
         $this->imageId     = (!empty($data['imageId'])) ? $data['imageId'] : null;
         $this->projectId = (!empty($data['projectId'])) ? $data['projectId'] : null;
         $this->image  = (!empty($data['image'])) ? $data['image'] : null;
    }
    
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }

     // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
    
     public function getInputFilter()
     {
         if (!$this->inputFilter) {
             $inputFilter = new InputFilter();

             $inputFilter->add(array(
                 'name'     => 'imageId',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
             ));
             $inputFilter->add(array(
                'name'     => 'projectId',
                'required' => true,
                'filters'  => array(
                    array('name' => 'Int'),
                ),
                'options' => array(
                    'label' => 'Project Id',
                ),
             ));

             $inputFilter->add(array(
                 'name'     => 'image',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'options' => array(
                    'label' => 'Image Name',
                ),
             ));

             $this->inputFilter = $inputFilter;
         }

         return $this->inputFilter;
     }

}
