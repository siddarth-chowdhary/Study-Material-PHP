<?php
namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;


class MessageReceiverTable extends ModelTable
{
     /*
     protected $tableGateway;

     public function __construct(TableGateway $tableGateway)
     {
         $this->tableGateway = $tableGateway;
     }*/

     public function fetchAll($paginated=false)
     {
         if ($paginated) {
             // create a new Select object for the table messageReceiver
             $select = new Select('messageReceiver');
             // create a new result set based on the messageReceiver entity
             $resultSetPrototype = new ResultSet();
             $resultSetPrototype->setArrayObjectPrototype(new ChatUser());
             // create a new pagination adapter object
             $paginatorAdapter = new DbSelect(
                 // our configured select object
                 $select,
                 // the adapter to run it against
                 $this->tableGateway->getAdapter(),
                 // the result set to hydrate
                 $resultSetPrototype
             );
             $paginator = new Paginator($paginatorAdapter);
             return $paginator;
         }
         $resultSet = $this->tableGateway->select();
         return $resultSet;
     }

     public function getMessageReceiver($id)
     {
         return $this->getDetailByColumn('messageId',$id);
     }

     public function saveMessageReceiver(MessageReceiver $messagereceiver)
     {
         $data = array(
             'messageId' => $messagereceiver->messageId,             
             'userId'=>$messagereceiver->userId,
             'receivedDate'=>$messagereceiver->receivedDate,
             'statusId'=>$messagereceiver->statusId,
         );
         $this->tableGateway->insert($data);
          
     }
     
     public function saveMultipleMessageReceiverRecord($tblName,array $data)
     {
        $this->multiInsert($tblName,$data);
     }
	/*
     public function deleteAlbum($id)
     {
         $this->tableGateway->delete(array('id' => (int) $id));
     }*/
 }
