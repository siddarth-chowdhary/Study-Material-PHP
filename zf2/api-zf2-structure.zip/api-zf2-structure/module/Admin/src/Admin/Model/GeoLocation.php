<?php
namespace Admin\Model;

// Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;


class GeoLocation implements InputFilterAwareInterface
{ 
    
    public function exchangeArray($data)
    {    
    }
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }

     // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
     
     public function getInputFilter($passreq = false)
     {
         if (!$this->inputFilter) {
             $inputFilter = new InputFilter();

             
             $inputFilter->add(array(
                 'name'     => 'searchItem',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
             ));

             $this->inputFilter = $inputFilter;
         }

         return $this->inputFilter;
     }

}
