<?php
namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Sql;

class LookupStatusTable
{
     protected $tableGateway;

     public function __construct(TableGateway $tableGateway)
     {
         $this->tableGateway = $tableGateway;
     }

     public function fetchAll($paginated=false,$searchParam = array())
     {
         if ($paginated) {
             // create a new Select object for the table album
             $select = new Select('lookup_status');
             if (isset($searchParam['statusId']) && ($searchParam['statusId'] != ""))
                $select->where->in('lookup_status.statusId', $searchParam['statusId']);
             
             // create a new result set based on the Album entity
             $resultSetPrototype = new ResultSet();
             $resultSetPrototype->setArrayObjectPrototype(new LookupStatus());
             // create a new pagination adapter object
             $paginatorAdapter = new DbSelect(
                 // our configured select object
                 $select,
                 // the adapter to run it against
                 $this->tableGateway->getAdapter(),
                 // the result set to hydrate
                 $resultSetPrototype
             );
             $paginator = new Paginator($paginatorAdapter);
             return $paginator;
         }
         
         if(!empty($searchParam)) {
            $select = new Select('lookup_status');
            if (isset($searchParam['statusId']) && ($searchParam['statusId'] != ""))
                $select->where->in('lookup_status.statusId', $searchParam['statusId']);
            
            $adapter = $this->tableGateway->getAdapter();
            $sql = new Sql($adapter);
            $selectString = $sql->getSqlStringForSqlObject($select);
            $results = $adapter->query($selectString, $adapter::QUERY_MODE_EXECUTE);
            
            return $results;
         }
         
         $resultSet = $this->tableGateway->select();
         return $resultSet;
     }

     public function getLookupStatus($statusId)
     {
         $statusId  = (int) $statusId;
         $rowset = $this->tableGateway->select(array('statusId' => $statusId));
         $row = $rowset->current();
         if (!$row) {
             throw new \Exception("Could not find row $id");
         }
         return $row;
     }

     public function saveLookupStatus(LookupStatus $lookupStatus)
     {
         $data = array(
             'statusCode' => $lookupStatus->statusCode           
         );

         $statusId = (int) $lookupStatus->statusId;
         if ($statusId == 0) {
             $this->tableGateway->insert($data);
         } else {
             if ($this->getLookupStatus($statusId)) {
                 $this->tableGateway->update($data, array('statusId' => $statusId));
             } else {
                 throw new \Exception('LookupStatus id does not exist');
             }
         }
     }

     public function deleteLookupStatus($statusId)
     {
         $this->tableGateway->delete(array('statusId' => (int) $statusId));
     }
     public function getLookupStatusBystatusCode($statusCode,$id="") { 
		
        if(empty($id)){			
			$rowset = $this->tableGateway->select(array('statusCode' => $statusCode));
		} else {			
			$rowset = $this->tableGateway->select(function (select $select)use($statusCode,$id) {
				$select->where->equalto('statusCode', $statusCode)->notequalto('statusId',$id);
			});   
		}        
        $row = $rowset->current();      
        if (!$row) {
            return false;
        }
        return $row;
    } 
 }
