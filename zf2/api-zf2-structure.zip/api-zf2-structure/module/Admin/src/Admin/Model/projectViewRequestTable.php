<?php
namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Expression;
use Zend\Db\Sql\Sql;

class projectViewRequestTable extends ModelTable
{
     protected $tableGateway;

     public function __construct(TableGateway $tableGateway)
     {
         $this->tableGateway = $tableGateway;
     }

     public function fetchAll($paginated=false,$searchParam=array())
     {
         if ($paginated) {
             // create a new Select object for the table album
             $select = new Select();
             
             $select->from(array('pvr'=>'projectViewRequest'))
                    ->columns(array(select::SQL_STAR))
                    ->join('lookup_status','lookup_status.statusId=pvr.statusId',array('statusCode'), Select::JOIN_INNER)
                    ->join('project', 'project.projectId=pvr.projectId', array('projectName'), Select::JOIN_INNER)
                    ->join('user', 'user.userId=pvr.userId', array('requestedBy'=>new Expression('case when user.lastName is NOT NUll then concat(user.firstName," ", user.lastName) else user.firstName END')), Select::JOIN_INNER);
            
            if(!empty($searchParam['projectId'])) {
                $select->where->equalto('project.projectId', $searchParam['projectId']);
            }
                    
             
             #echo $select->getSqlString();die;
             // create a new pagination adapter object
             $paginatorAdapter = new DbSelect(
                 // our configured select object
                 $select,
                 // the adapter to run it against
                 $this->tableGateway->getAdapter()
                 // the result set to hydrate
                 //$resultSetPrototype
             );
             
             $paginator = new Paginator($paginatorAdapter);
             
            # echo '<pre>';print_r($paginator);echo '</pre>';
             return $paginator;
         }
         
         $resultSet = $this->tableGateway->select();
         return $resultSet;
     }

     public function getProjectImage($imageId)
     {
         return $this->getDetailById('imageId',$imageId);
     }

     public function saveProjectImage(ProjectImage $project)
     {
         $data = array(
            'imageId' => $project->imageId,
            'projectId'  => $project->projectId,
            'image'  => $project->image,
        );

        $imageId = (int) $project->imageId;
        if ($imageId == 0) {
            try {
                $this->tableGateway->insert($data);
            }
            catch(\Zend\Db\Adapter\ExceptionInterface $e) {
                 $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
                throw new \Admin\Service\MyException($message);
            }
            catch (\Exception $e) {
                $message = $e->getMessage();
                throw new \Admin\Service\MyException($message);
            }
        }
        else {
            if ($this->getProject($projectId)) {
                try {
                    $this->tableGateway->update($data, array('imageId' => $imageId));
                }
                catch(\Zend\Db\Adapter\ExceptionInterface $e) {
                     $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
                    throw new \Admin\Service\MyException($message);
                }
                catch (\Exception $e) {
                    $message = $e->getMessage();
                    throw new \Admin\Service\MyException($message);
                }
            }
            else {
                throw new \Exception('Project Image does not exist');
            }
        }
    }

    public function deleteProjectImage($imageId,$projectId)
    {
        $this->tableGateway->delete(array('imageId' => (int) $imageId,'projectId' => (int) $projectId));
    }
    public function getProjectByName($projectName,$id="") { 
        if(empty($id)){
            $rowset = $this->tableGateway->select(array('projectName' => $projectName));
        }
        else {
			$rowset = $this->tableGateway->select(function (select $select)use($projectName,$id) {
				$select->where->equalto('projectName', $projectName)->notequalto('projectId',$id);
			});   
		}        
        $row = $rowset->current();
        if (!$row) {
            return false;
        }
        return $row;
    }
    
    public function save(projectViewRequest $projectViewRequest) 
    {
        $data = array(
            'projectId' => $projectViewRequest->projectId,
            'userId' => $projectViewRequest->userId,
            'statusId'=> $projectViewRequest->statusId,
            'createdDate'=> $projectViewRequest->createdDate,
        );
        try {
            $this->tableGateway->insert($data);
            return true;
        } catch (\Exception $e) {
            $message = $e->getMessage();
            throw new \Admin\Service\MyException($message);
        }
    }
    /**
     * @desc - This function returns the chat and project requests 
     * received by the specific userID.
     */
    public function getChatRequestsForProjects($userId) {
        $sql = new Sql($this->tableGateway->getAdapter()); 
        $select = new Select();
        $select->from('project')
                ->columns(array('projectId','projectName'))
                ->join(array('pvr' =>'projectViewRequest'), 'project.projectId=pvr.projectId', array('userId'), Select::JOIN_INNER)
                ->join(array('usr'=>'user'),'pvr.userId=usr.userId',array('userName'),  Select::JOIN_INNER)
        ;
        if (!empty($userId)) {
            $select->where->equalto('project.userId', $userId);
            $select->where->equalto('pvr.statusId', 7);
        }
        $statement = $sql->prepareStatementForSqlObject($select);
//        print_r($statement);die;
        $results = $statement->execute();
        $resultSet = new ResultSet;
        $resultSet->initialize($results);
        $response = array();
        foreach ($resultSet as $row) {
            $response[] = $this->object_to_array($row);
        }
        return $response;
    }
    private function object_to_array($object) {
        return (array) $object;
    }
 }
