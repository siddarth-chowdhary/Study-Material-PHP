<?php

namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Expression;

class GeoLocationTable extends ModelTable {

    public function fetchAll($paginated = false, $searchParam) {
        if ($paginated) {
            // create a new Select object for the table chat
            $select = new Select();
            $select->from(array('u'=>'user'))
                    ->columns(array(Select::SQL_STAR))
                    ->join(array('ua' => 'userAddress'), 'ua.userId = u.userId', array('longitude','latitude','address'), $select::JOIN_LEFT)
                    ->join(array('ui' => 'userInterest'), 'ui.userId = u.userId', array('interest1','interest2','interest3'), $select::JOIN_LEFT)
                    ->join(array('c' => 'country'), 'ua.countryId = c.countryId', array('countryName','countryCode'), $select::JOIN_LEFT)
                    ->join(array('s' => 'state'), 's.stateId = ua.stateId', array('stateCode','stateName'), $select::JOIN_LEFT);
            $select->where->equalto('u.statusId', 1);
            $select->where->notEqualTo('ua.longitude', '');
            $select->where->isNotNull('ua.longitude');
            $select->where->notEqualTo('ua.latitude', '');
            $select->where->isNotNull('ua.latitude');
            if (isset($searchParam['searchItem']) and $searchParam['searchItem'] != '') {
                $searchstring=$searchParam['searchItem'];
                $select->where->nest->like('ua.address', '%' . $searchstring . '%')
                        ->or
                        ->like('u.firstName', '%' . $searchstring . '%')
                        ->or
                        ->like('u.lastName', '%' . $searchstring . '%')
                        ->or
                        ->like('u.email', '%' . $searchstring . '%')
                        ->or
                        ->like('u.phone', '%' . $searchstring . '%')
                        ->or
                        ->like('u.occupation', '%' . $searchstring . '%')
                        ->or
                        ->like('u.skill', '%' . $searchstring . '%')
                        ->or
                        ->like('ui.interest1', '%' . $searchstring . '%')
                        ->or
                        ->like('ui.interest2', '%' . $searchstring . '%')
                        ->or
                        ->like('ui.interest3', '%' . $searchstring . '%')
                        ->or
                        ->like('c.countryName', '%' . $searchstring . '%')
                        ->or
                        ->like('s.stateName', '%' . $searchstring . '%')
                        ->unnest();
            }

            #echo $select->getSqlString();die;
            // create a new result set based on the chat entity
            //$resultSetPrototype = new ResultSet();
            //$resultSetPrototype->setArrayObjectPrototype(new chat());
            // create a new pagination adapter object
            $paginatorAdapter = new DbSelect(
                    // our configured select object
                    $select,
                    // the adapter to run it against
                    $this->tableGateway->getAdapter()
                    //,
                    // the result set to hydrate
                    //$resultSetPrototype
            );
            $paginator = new Paginator($paginatorAdapter);
            return $paginator;
        }
        $resultSet = $this->tableGateway->select();
        return $resultSet;
    }

}
