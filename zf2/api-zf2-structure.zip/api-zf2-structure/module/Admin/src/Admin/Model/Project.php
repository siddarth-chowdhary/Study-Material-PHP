<?php
namespace Admin\Model;

// Add these import statements
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;
use DateTime;

class Project implements InputFilterAwareInterface
{
    public $projectId;
    public $projectName;
    public $projectDetail;
    public $userId;    
    public $visibility;
    public $createdDate;
    public $updatedDate;
    public $lockProjectDetail;
    
    protected $inputFilter;

    public function exchangeArray($data)
    {
         $dateObj = new DateTime('NOW');
         $this->projectId     = (!empty($data['projectId'])) ? $data['projectId'] : null;
         $this->projectName = (!empty($data['projectName'])) ? $data['projectName'] : null;
         $this->projectDetail  = (!empty($data['projectDetail'])) ? $data['projectDetail'] : null;
         $this->lockProjectDetail  = (!empty($data['lockProjectDetail'])) ? $data['lockProjectDetail'] : 1;
         $this->userId  = (!empty($data['userId'])) ? $data['userId'] : null;
         $this->createdDate  = (!empty($data['createdDate'])) ? $data['createdDate'] : $dateObj->format('Y-m-d H:i:s');
         $this->updatedDate  = (!empty($data['updatedDate'])) ? $data['updatedDate'] : $dateObj->format('Y-m-d H:i:s');
         $this->visibility  = ($data['visibility']!=='') ? $data['visibility'] : null;    }
    
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }

     // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
    
    
    /*
     $validator = new Zend\Validator\Db\RecordExists(
       array(
          'table'   => 'users',
          'field'   => 'emailaddress',
          'adapter' => \Zend\Db\TableGateway\Feature\GlobalAdapterFeature::getStaticAdapter()
       )
    );
    */
    
     public function getInputFilter()
     {
         if (!$this->inputFilter) {
             $inputFilter = new InputFilter();

             $inputFilter->add(array(
                 'name'     => 'projectId',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
             ));

             $inputFilter->add(array(
                 'name'     => 'projectName',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 1,
                             'max'      => 50,
                         ),
                     ),
                 ),
             ));

             $inputFilter->add(array(
                 'name'     => 'projectDetail',
                 'required' => true,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 1,
                             'max'      => 60,
                         ),
                     ),
                 ),
             ));
             $inputFilter->add(array(
                        'name' => 'userId',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'Int'),
                        ),
                        'options' => array(
                            'label' => 'userId',
                        ),
            ));

             $this->inputFilter = $inputFilter;
         }

         return $this->inputFilter;
     }

}
