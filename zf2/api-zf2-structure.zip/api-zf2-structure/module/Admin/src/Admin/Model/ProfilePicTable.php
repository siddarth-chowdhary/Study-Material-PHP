<?php
namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Expression;
use Zend\Db\Sql\Sql;

class ProfilePicTable extends ModelTable
{
     protected $tableGateway;

     public function __construct(TableGateway $tableGateway)
     {
         $this->tableGateway = $tableGateway;
     }

     public function fetchAll($paginated=false,$searchParam=array())
     {
         
      
         if ($paginated) {
             // create a new Select object for the table album
             $select = new Select();
             
             $select->from(array('pi'=>'profilePic'))
                    ->columns(array(select::SQL_STAR))
                    ->join('user', 'user.userId=pi.userId', array('userName'), Select::JOIN_LEFT);
            
            if(!empty($searchParam['userId'])) {
                $select->where->equalto('pi.userId', $searchParam['userId']);
            }
                    
             
             #echo $select->getSqlString();die;
             //$resultSetPrototype = new ResultSet();
             //$resultSetPrototype->setArrayObjectPrototype(new Project());
             // create a new pagination adapter object
             $paginatorAdapter = new DbSelect(
                 // our configured select object
                 $select,
                 // the adapter to run it against
                 $this->tableGateway->getAdapter()
                 // the result set to hydrate
                 //$resultSetPrototype
             );
             
             $paginator = new Paginator($paginatorAdapter);
             
            # echo '<pre>';print_r($paginator);echo '</pre>';
             return $paginator;
         }
         
         $resultSet = $this->tableGateway->select();
         
         return $resultSet;
     }

     public function getProfilePic($profilePicId)
     {
         return $this->getDetailById('profilePicId',$profilePicId);
     }

     public function saveProfilePic(ProfilePic $profile)
     {
         $data = array(
            'profilePicId' => $profile->profilePicId,
            'userId'  => $profile->userId,
            'profilePic'  => $profile->profilePic,
            'defaultPic'  => $profile->defaultPic,
            'createdDate'  => $profile->createdDate,
            'updatedDate'  => $profile->updatedDate,
        );
        $newData=array('defaultPic'  => $profile->defaultPic);
        $profilePicId = (int) $profile->profilePicId;
        $userId = (int) $profile->userId;
        if ($profilePicId == 0) {
            try {
                $picReturnval=$this->getDefaultProfilePic($data['userId']);
                if($picReturnval==null){
                    $data['defaultPic']=1;
                }
                $this->tableGateway->insert($data);
            }
            catch(\Zend\Db\Adapter\ExceptionInterface $e) {
                 $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
                throw new \Admin\Service\MyException($message);
            }
            catch (\Exception $e) {
                $message = $e->getMessage();
                throw new \Admin\Service\MyException($message);
            }
        }
        else {
            if ($userId) {
                try {
                    $newData['defaultPic']=0;
                    $this->tableGateway->update($newData, array('userId'=>$userId));
                    $newData['defaultPic']=1; 
                    $this->tableGateway->update($newData, array('profilePicId' => $profilePicId));
                }
                catch(\Zend\Db\Adapter\ExceptionInterface $e) {
                     $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
                    throw new \Admin\Service\MyException($message);
                }
                catch (\Exception $e) {
                    $message = $e->getMessage();
                    throw new \Admin\Service\MyException($message);
                }
            }
            else {
                throw new \Exception('Profile Image does not exist');
            }
        }
    }

    public function deleteProfilePic($profilePicId)
    {   
        $this->tableGateway->delete(array('profilePicId' => (int) $profilePicId));
    }
   /* public function getProjectByName($projectName,$id="") { 
        if(empty($id)){
            $rowset = $this->tableGateway->select(array('projectName' => $projectName));
        }
        else {
			$rowset = $this->tableGateway->select(function (select $select)use($projectName,$id) {
				$select->where->equalto('projectName', $projectName)->notequalto('projectId',$id);
			});   
		}        
        $row = $rowset->current();
        if (!$row) {
            return false;
        }
        return $row;
    }*/
    public function getDefaultProfilePic($userId){
        
        $id  = (int) $userId;
        $select = new Select();
        $select->from('profilePic')
                ->columns(array(select::SQL_STAR))                
                ->where->equalto('profilePic.userId',$id)
                ->where->equalto('profilePic.defaultPic',1);
        $adapter = $this->tableGateway->getAdapter();
        $sql = new Sql($adapter);
        $selectString = $sql->getSqlStringForSqlObject($select);
        $results = $adapter->query($selectString, $adapter::QUERY_MODE_EXECUTE);
        $row = $results->current();
        return $row;
        
    }
    
 }
