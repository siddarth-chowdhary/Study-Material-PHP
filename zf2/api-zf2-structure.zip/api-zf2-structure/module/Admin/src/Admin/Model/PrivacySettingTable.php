<?php

namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Expression;

class PrivacySettingTable extends ModelTable {

    public function fetchAll($paginated = false, $searchParam = array()) {
        if ($paginated) {
            // create a new Select object for the table chat

            $select = new Select();
            $select->from('privacySetting')
                    ->columns(array(Select::SQL_STAR))
                    ->group('privacySetting.settingId');
            if (!empty($searchParam['userId'])) {
                $select->where->equalto('privacySetting.userId', $searchParam['userId']);
            }

            #echo $select->getSqlString();die;
            // create a new result set based on the chat entity
            //$resultSetPrototype = new ResultSet();
            //$resultSetPrototype->setArrayObjectPrototype(new chat());
            // create a new pagination adapter object
            $paginatorAdapter = new DbSelect(
                    // our configured select object
                    $select,
                    // the adapter to run it against
                    $this->tableGateway->getAdapter()
                    //,
                    // the result set to hydrate
                    //$resultSetPrototype
            );
            $paginator = new Paginator($paginatorAdapter);
            return $paginator;
        }
        $resultSet = $this->tableGateway->select();
        return $resultSet;
    }

    public function getPrivacySetting($settingId) {
        $settingId = (int) $settingId;
        $rowset = $this->tableGateway->select(array('settingId' => $settingId));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $settingId");
        }
        return $row;
    }

    public function savePrivacySetting(PrivacySetting $privacysetting) {
        $settingId = (int) $privacysetting->settingId;
        $data=array(
            'userId'=>$privacysetting->userId,
            'findMeByPhone'=>$privacysetting->findMeByPhone,
            'findMeByEmail'=>$privacysetting->findMeByEmail,
            'findMeBySearch'=>$privacysetting->findMeBySearch,
            'hideSkill'=>$privacysetting->hideSkill,
            'hideLinkedin'=>$privacysetting->hideLinkedin,
            'hideProject'=>$privacysetting->hideProject,
            'hideProfilePhoto'=>$privacysetting->hideProfilePhoto,
            'block'=>$privacysetting->block,
            'report'=>$privacysetting->report,
        );
        if ($settingId == 0) {//echo "<pre>";print_r($privacysetting);exit;
            $this->tableGateway->insert($data);
        } else {
            if ($this->getPrivacySetting($settingId)) {//print_r($data);exit;
                $this->tableGateway->update($data, array('settingId' => $settingId));
            } else {
                throw new \Exception('Setting id does not exist');
            }
        }
    }

    public function deletePrivacySetting($settingId) {
        $this->tableGateway->delete(array('settingId' => (int) $settingId));
    }
    public function deletePrivacySettingByUserId($userId) {
        $this->tableGateway->delete(array('userId' => (int) $userId));
    }
    
    public function updateUserPrivacySetting($data) {
        if ($data['colName'] == "findMeByPhone" ||
                $data['colName'] == "findMeByEmail" ||
                $data['colName'] == "findMeBySearch" ||
                $data['colName'] == "hideSkill" ||
                $data['colName'] == "hideLinkedin" ||
                $data['colName'] == "hideProject" ||
                $data['colName'] == "hideProfilePhoto" ||
                $data['colName'] == "block" ||
                $data['colName'] == "report"
        ) {
            $updateData = '';
            $updateData[$data['colName']] = $data['colValue'];
            try {
                $this->tableGateway->update($updateData, array('userId' => $data['userId']));
                return true;
            } catch (\Exception $e) {
                $message = $e->getMessage();
                throw new \Admin\Service\MyException($message);
            }
        } else {
            return "Error - Invalid Column Name";
        }
    }

    public function getPrivacySettingsForUser($userId) {
        $rowset = $this->tableGateway->select(array('userId' => $userId));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $userId");
        }
        return $row;
    }

}
