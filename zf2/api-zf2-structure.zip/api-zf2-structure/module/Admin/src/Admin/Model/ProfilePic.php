<?php
namespace Admin\Model;

// Add these import statements
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;
use DateTime;

class ProfilePic implements InputFilterAwareInterface
{
    public $profilePicId;
    public $userId;
    public $profilePic;
    public $defaultPic;
    public $createdDate;
    public $updatedDate;
    
    protected $inputFilter;

    public function exchangeArray($data)
    {
        $dateObj = new \DateTime('NOW'); 
         $this->profilePicId     = (!empty($data['profilePicId'])) ? $data['profilePicId'] : null;
         $this->userId = (!empty($data['userId'])) ? $data['userId'] : null;
         $this->profilePic  = (!empty($data['profilePic'])) ? $data['profilePic'] : null;
         $this->defaultPic  = (!empty($data['defaultPic'])) ? $data['defaultPic'] : 0;
         $this->createdDate  = (!empty($data['createdDate'])) ? $data['createdDate'] : $dateObj->format('Y-m-d H:i:s');
         $this->updatedDate  = (!empty($data['updatedDate'])) ? $data['updatedDate'] : $dateObj->format('Y-m-d H:i:s');
    }
    
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }

     // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
    
     public function getInputFilter()
     {
         if (!$this->inputFilter) {
             $inputFilter = new InputFilter();

             $inputFilter->add(array(
                 'name'     => 'profilePicId',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
             ));
             $inputFilter->add(array(
                'name'     => 'userId',
                'required' => true,
                'filters'  => array(
                    array('name' => 'Int'),
                ),
                'options' => array(
                    'label' => 'User Id',
                ),
             ));

             $inputFilter->add(array(
                 'name'     => 'profilePic',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'options' => array(
                    'label' => 'profilePic Name',
                ),
             ));
              $inputFilter->add(array(
                'name'     => 'defaultPic',
                'required' => false,
                'filters'  => array(
                    array('name' => 'Int'),
                ),
                'options' => array(
                    'label' => 'Default Pic',
                ),
             ));

             $this->inputFilter = $inputFilter;
         }

         return $this->inputFilter;
     }

}
