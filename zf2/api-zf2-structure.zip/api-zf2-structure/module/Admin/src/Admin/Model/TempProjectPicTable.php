<?php

namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Expression;

class TempProjectPicTable extends ModelTable {

    protected $tableGateway;

    public function __construct(TableGateway $tableGateway) {
        $this->tableGateway = $tableGateway;
    }

    public function fetchAll($paginated = false, $searchParam = array()) {
        
        if ($paginated) {
            // create a new Select object for the table chat

            $selectType = new Select();
            $select = new Select();
            $select->from('tempProjectPic')
                    ->columns(array(Select::SQL_STAR));
            if (!empty($searchParam['tempProjectId'])) {
                $select->where->equalto('tempProjectPic.tempProjectId', $searchParam['tempProjectId']);
            }          
                // create a new pagination adapter object
                $paginatorAdapter = new DbSelect(
                        // our configured select object
                        $select,
                        // the adapter to run it against
                        $this->tableGateway->getAdapter()
                        //,
                        // the result set to hydrate
                        //$resultSetPrototype
                );
                $paginator = new Paginator($paginatorAdapter);
                return $paginator;
            }
           
            $resultSet = $this->tableGateway->select();
            return $resultSet;
     
    }

    public function saveTempProjectPic(TempProjectPic $tempProject) {
        $data = array(
            'tempId' => $tempProject->tempId,
            'tempProjectId' => $tempProject->tempProjectId,
            'imageName' => $tempProject->imageName,
        );

        $tempProjectId = (int) $tempProject->tempProjectId;

        try {
            $this->tableGateway->insert($data);
        } catch (\Zend\Db\Adapter\ExceptionInterface $e) {
            $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
            throw new \Admin\Service\MyException($message);
        } catch (\Exception $e) {
            $message = $e->getMessage();
            throw new \Admin\Service\MyException($message);
        }
    }

    public function updateTempProjectPic(TempProjectPic $tempProject) {
        $data = array(
            'tempId' => $tempProject->tempId,
            'tempProjectId' => $tempProject->tempProjectId,
            'imageName' => $tempProject->imageName,
        );

        try {
            $this->tableGateway->update($data, array('tempId' => $data['tempId']));
        } catch (\Zend\Db\Adapter\ExceptionInterface $e) {
            $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
            throw new \Admin\Service\MyException($message);
        } catch (\Exception $e) {
            $message = $e->getMessage();
            throw new \Admin\Service\MyException($message);
        }
    }

    public function deleteTempProjectPic($tempId) {
        $this->tableGateway->delete(array('tempId' => (int) $tempId));
    }
    public function deleteTempProjectPicByTempProjectId($tempProjectId) {
        $this->tableGateway->delete(array('tempProjectId' => (int) $tempProjectId));
    }

    public function getTempProjectId($tempId) {
        return $this->getDetailById('tempId', $tempId);
    }
   

}
