<?php
namespace Admin\Model;

use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Db\Sql\Expression;

class UserContactDetailTable extends ModelTable
{
     public function fetchAll($paginated=false,$searchParams = array())
     {
         if ($paginated) {
             // create a new Select object for the table album
             $select = new Select();
             $select->from('userContactDetail')
                    ->columns(array(Select::SQL_STAR))
                    ->join(array('uc'=>'userContact'),'uc.contactId=userContactDetail.contactId',array('contactName'), Select::JOIN_LEFT);
            if(!empty($searchParams['contactId'])) {
                $select->where->equalto('uc.contactId',$searchParams['contactId']);
            }
            #echo $select->getSqlString();die;
             // create a new pagination adapter object
             $paginatorAdapter = new DbSelect(
                 // our configured select object
                 $select,
                 // the adapter to run it against
                 $this->tableGateway->getAdapter()
             );
             $paginator = new Paginator($paginatorAdapter);
             return $paginator;
         }
         $resultSet = $this->tableGateway->select();
         return $resultSet;
     }

     public function getUserContactDetail($contactId)
     {
         return $this->getDetailByColumns(array('contactId'=>$contactId),'multi');
     }

     public function saveUserContactDetail(array $userContactDetail,$contactId)
     {
        $this->delete($contactId);
        
        try {
            $this->multiInsert('userContactDetail',$userContactDetail);
        }
        catch(\Zend\Db\Adapter\ExceptionInterface $e) {
             $message = $e->getPrevious() ? $e->getPrevious()->getMessage() : $e->getMessage();
            throw new \Admin\Service\MyException($message);
        }
        catch (\Exception $e) {
            $message = $e->getMessage();
            throw new \Admin\Service\MyException($message);
        }
         
     }
     
     public function delete($contactId)
     {
         $this->tableGateway->delete(array('contactId' => (int) $contactId));
     }
 }
