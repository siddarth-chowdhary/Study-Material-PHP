<?php

namespace Admin\Controller;

use Admin\Controller\PController;
use Zend\View\Model\ViewModel;
use Admin\Model\Chat;
use Admin\Model\ChatUser;
use Admin\Model\Message;
use Admin\Model\MessageReceiver;
use Admin\Form\ChatForm;

class ChatController extends PController {

    public function indexAction() {
        $userId = (int) $this->params()->fromRoute('id', 0);
        if (!$userId) {
            return $this->redirect()->toRoute('admin/child', array(
                        'controller' => 'user'
                        , 'action' => 'index'
            ));
        }

        $search['userId'] = $userId;
        // grab the paginator from the ChatTable        
        $paginator = $this->getChatTable()->fetchAll(true, $search);
        // set the current page to what has been passed in query string, or to 1 if none set
        $paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
        // set the number of items per page to 10
        $paginator->setItemCountPerPage(10);

        return new ViewModel(
                array(
            'paginator' => $paginator
            , 'userId' => $userId
                )
        );
    }

    public function addAction() {

        $userId = (int) $this->params()->fromRoute('id', 0);

        if (!$userId) {
            return $this->redirect()->toRoute('admin/child', array(
                        'controller' => 'chat'
                        , 'action' => 'index'
            ));
        }

        $VisibilityArray = $chatReceivedUserArray = array();
        $VisibilityArray = array(4 => "Public", 3 => 'Private');

        $userArr = $this->getUserTable()->getUserList(array('userType' => 2, "statusId" => 1, "notequalto" => array('userId' => $userId)));

        foreach ($userArr as $chatCreateUser) {
            $chatReceivedUserArray[$chatCreateUser->userId] = $chatCreateUser->firstName . ' ' . $chatCreateUser->lastName;
        }

        $form = new ChatForm($VisibilityArray, $chatReceivedUserArray);
        $form->get('submit')->setValue('Add');
        $form->get('userId')->setValue($userId);
        $errorMessage = "";
        $message = "";
        $request = $this->getRequest();
        if ($request->isPost()) {
            $chat = new Chat();
            $data = $request->getPost()->toArray();
            $passReq = false;
            if (!empty($data['statusId']) && $data['statusId'] == 3) {
                $passReq = true;
            }
            $form->setInputFilter($chat->getInputFilter($passReq));
            $form->setData($request->getPost());

            $chat->exchangeArray($data);


            if ($form->isValid()) { //echo "<pre>";print_r($data);exit;
                $chat->exchangeArray($form->getData());
                $this->getChatTable()->saveChat($chat);
                $idInserted = $this->getChatTable()->lastInsertedValue();

                $data['chatId'] = $idInserted;
                $this->insertRelativeTableOfChat($data);
                $message = "Chat Created";
                $this->flashmessenger()->addMessage($message);
                // Redirect to list of albums
                return $this->redirect()->toRoute('admin/child', array('controller' => 'chat', 'action' => 'index', 'id' => $userId));
            }
        }
        return new ViewModel(array('form' => $form, 'errorMessage' => $errorMessage));
    }

    public function editAction() {

        $chatId = (int) $this->params()->fromRoute('id', 0);
        if (!$chatId) {
            return $this->redirect()->toRoute('admin/child', array(
                        'controller' => 'chat'
                        , 'action' => 'add'
            ));
        }
        $isChatAvailable = true;
        $errorMessage = "";
        $message = "";
        // Get the Album with the specified id.  An exception is thrown
        // if it cannot be found, in which case go to the index page.
        try {
            $chat = $this->getChatTable()->getChat($chatId);
        } catch (\Exception $ex) {
            return $this->redirect()->toRoute('admin/child', array(
                        'controller' => 'chat'
                        , 'action' => 'index'
            ));
        }

        $form = new ChatForm();
        $form->bind($chat);
        $form->get('submit')->setAttribute('value', 'Update');

        $request = $this->getRequest();

        if ($request->isPost()) {

            $form->setInputFilter($chat->getInputFilter());
            $form->setData($request->getPost());
            $data = $request->getPost()->toArray();

            if ($isChatAvailable) {
                if ($form->isValid()) {
                    $this->getChatTable()->saveChat($chat);
                    $message = "Chat Updated";
                    $this->flashmessenger()->addMessage($message);
                    // Redirect to list of albums
                    return $this->redirect()->toRoute('admin/child', array(
                                'controller' => 'chat'
                                , 'action' => 'index'
                    ));
                }
            } else {
                $errorMessage = "chat exist use another";
            }
        }
        $viewModel = new ViewModel(array(
            'id' => $chatId,
            'form' => $form,
            'errorMessage' => $errorMessage,
        ));
        $viewModel->setTemplate('admin/chat/add.phtml');
        return $viewModel;
    }

    public function deleteAction() {
        $chatId = (int) $this->params()->fromRoute('id', 0);

        if (!$chatId) {
            return $this->redirect()->toRoute('admin/child', array(
                        'controller' => 'chat'
                        , 'action' => 'index'
            ));
        }

        $this->getChatTable()->deleteChat($chatId);
        // Redirect to list of albums

        return $this->redirect()->toRoute('admin/child', array(
                    'controller' => 'chat'
                    , 'action' => 'index'
        ));
    }

    protected function insertRelativeTableOfChat($formData) {

        //Insert data in chatUser table


        $ctCreateUser = $ctReceivedUser = $getInsertChatUserTableData = $multipleMessageReceiver = array();

        $chatUser = new ChatUser();
        $chatUser->exchangeArray($formData);
        $chatUser->visibility = $formData['statusId'];
        $chatUser->user_Id = $formData['user_Id'];
        //echo "<pre>";
        //print_r($chatUser);exit;
        $ctCreateUser[] = array('chatId' => $chatUser->chatId, 'userId' => $chatUser->userId,
            'visibility' => $chatUser->visibility, 'password' => $chatUser->password);
        foreach ($chatUser->user_Id as $receivedUserArr) {
            $ctReceivedUser[] = array('chatId' => $chatUser->chatId, 'userId' => $receivedUserArr,
                'visibility' => $chatUser->visibility, 'password' => '');
        }
        $getInsertChatUserTableData = array_merge($ctCreateUser, $ctReceivedUser);

        //$insertChatUser = $this->getChatUserTable()->saveChatUser($chatUser);//single insert
        $insertChatUser = $this->getChatUserTable()->saveMultipleRecord('chatUser', $getInsertChatUserTableData); //multiple insert
        //insert data in message table

        $message = new Message();
        $message->exchangeArray($formData);

        $message->chatId = $formData['chatId'];
        $insertMessage = $this->getMessageTable()->saveMessage($message);
        $messageInsertId = $this->getMessageTable()->lastInsertedValue();

        //insert data in MessageReceiver table

        $messageReceiver = new MessageReceiver();
        $messageReceiver->exchangeArray($formData);
        $messageReceiver->messageId = $messageInsertId;

        foreach ($chatUser->user_Id as $uid) {
            $multipleMessageReceiver[] = array('messageId' => $messageReceiver->messageId, 'userId' => $uid,
                'receivedDate' => $messageReceiver->receivedDate, 'statusId' => 7);
        }

        //$insertMessageReceiver = $this->getMessageReceiverTable()->saveMessageReceiver($messageReceiver);//single insert
        $insertmessageReceiver = $this->getMessageReceiverTable()->saveMultipleMessageReceiverRecord('messageReceiver', $multipleMessageReceiver); //multiple insert
    }

    public function viewchatAction() {

        $userId = $this->params()->fromQuery('uid');
        $chatId = (int) $this->params()->fromRoute('id', 0);
        $search['userId'] = $userId;
        $search['chatId'] = $chatId;
        // grab the paginator from the ChatTable       
        $paginator = $this->getChatTable()->fetchChatReceiverData(true, $search);
        // set the current page to what has been passed in query string, or to 1 if none set
        $paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
        // set the number of items per page to 10
        $paginator->setItemCountPerPage(10);

        return new ViewModel(
                array(
            'paginator' => $paginator
            , 'userId' => $userId
            , 'chatId' => $chatId
                )
        );
    }

}
