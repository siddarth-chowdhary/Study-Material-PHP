<?php
namespace Admin\Controller;

use Admin\Controller\PController;
use Zend\View\Model\ViewModel;
use Admin\Model\Project;
use Admin\Model\projectViewRequest;
use Admin\Form\ProjectForm;

class ProjectController extends PController
{
    public function indexAction()
    {
        $search = $this->params()->fromQuery('search', array());
        $page = (int) $this->params()->fromQuery('page', 1);
        $itemPerPage = 10;
        // grab the paginator from the AlbumTable
        $paginator = $this->getProjectTable()->fetchAll(true,$search);
        // set the current page to what has been passed in query string, or to 1 if none set
        $paginator->setCurrentPageNumber($page);
        // set the number of items per page to 10
        $paginator->setItemCountPerPage($itemPerPage);
        
        $statusArr = $this->getLookupStatusTable()->fetchAll(false, array('statusId'=>array(3,4)));
        foreach ($statusArr as $statusArrKey => $statusArrVal) {            
            $statusArray[$statusArrVal->statusId] = $statusArrVal->statusCode;
         } 
        
        
        return new ViewModel(
            array(
                'paginator' => $paginator
                ,'search' => $search
                ,'statusArr' => $statusArray
                ,'page'=>$page
                ,'itemPerPage'=>$itemPerPage
            )
        );
    }
    public function addAction()
    {
		 $isProjectAvailable = true;
		 $errorMessage = "";
		 $message = "";
		 $userArr = $this->getUserTable()->fetchAll(false, array('statusId'=>'1'));
		 foreach ($userArr as $userArrKey => $userArrVal) {            
            $userArray[$userArrVal->userId] = $userArrVal->firstName." ".$userArrVal->lastName;
         }
         $statusArr = $this->getLookupStatusTable()->fetchAll(false, array('statusId'=>array(3,4)));
		 foreach ($statusArr as $statusArrKey => $statusArrVal) {            
            $statusArray[$statusArrVal->statusId] = $statusArrVal->statusCode;
         }         
         $form = new ProjectForm($userArray,$statusArray);
         $form->get('submit')->setValue('Add');
         $request = $this->getRequest();
         if ($request->isPost()) {
            $project = new Project();
            $data = $request->getPost()->toArray();
            
            $form->setInputFilter($project->getInputFilter());
            $form->setData($request->getPost());

            if ($form->isValid()) {
                 $project->exchangeArray($form->getData());
                 $this->getProjectTable()->saveProject($project);
                 $message = "Project Created";
                 $this->flashmessenger()->addMessage($message);
                 // Redirect to list of albums
                 return $this->redirect()->toRoute('admin/child',array('controller'=>'project','action'=>'index'));
            }
		   
         }
         return array('form' => $form,'errorMessage'=>$errorMessage);
     }
    public function editAction()
     {
         $projectId = (int) $this->params()->fromRoute('id', 0);
         if (!$projectId) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'project'
                 ,'action' => 'add'
             ));
         }
		 $isProjectAvailable = true;
		 $errorMessage = "";
		 $message = "";
         // Get the Album with the specified id.  An exception is thrown
         // if it cannot be found, in which case go to the index page.
         try {
             $project = $this->getProjectTable()->getProject($projectId);
         }
         catch (\Exception $ex) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'project'
                 ,'action' => 'index'
             ));
         }
         $userArr = $this->getUserTable()->fetchAll(false, array('statusId'=>'1'));
		 foreach ($userArr as $userArrKey => $userArrVal) {            
            $userArray[$userArrVal->userId] = $userArrVal->firstName." ".$userArrVal->lastName;
         }
         $statusArr = $this->getLookupStatusTable()->fetchAll(false, array('statusId'=>array(3,4)));
		 foreach ($statusArr as $statusArrKey => $statusArrVal) {            
            $statusArray[$statusArrVal->statusId] = $statusArrVal->statusCode;
         }   
         $form = new ProjectForm($userArray,$statusArray);
         $form->bind($project);
         $form->get('submit')->setAttribute('value', 'Update');

         $request = $this->getRequest();
         
         if ($request->isPost()) {
			
             $form->setInputFilter($project->getInputFilter());
             $form->setData($request->getPost());
			 $data = $request->getPost()->toArray();
             /*if(!empty($data['projectName'])){			
				if($this->getProjectTable()->getProjectByName($data['projectName'],$projectId)) {
							
						$isProjectAvailable = false;
						$errorMessage = "Project name exist use another";
				}
			}*/
			if($isProjectAvailable){
				if ($form->isValid()) {
					$this->getProjectTable()->saveProject($project);
					$message = "Project Updated";
					$this->flashmessenger()->addMessage($message);
					 // Redirect to list of albums
					return $this->redirect()->toRoute('admin/child', array(
					 'controller' => 'project'
					 ,'action' => 'index'
					));
				}
			} else {
			   $errorMessage = "Project name exist use another";
		    }
         }
         $viewModel = new ViewModel(array(
             'id' => $projectId,
             'form' => $form,
             'errorMessage'=>$errorMessage,
         ));
         $viewModel->setTemplate('admin/project/add.phtml');
         return $viewModel;
     }
     public function deleteAction()
     {
         $projectId = (int) $this->params()->fromRoute('id', 0);
         
         if (!$projectId) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'project'
                 ,'action' => 'index'
             ));
         }
         
        $this->getProjectTable()->deleteProject($projectId);
        // Redirect to list of albums
        
        return $this->redirect()->toRoute('admin/child', array(
         'controller' => 'project'
         ,'action' => 'index'
        ));
        
     }
    
    public function viewedAction()
    {
        $projectId = (int) $this->params()->fromRoute('id', 0);
         if (!$projectId) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'project'
                 ,'action' => 'index'
             ));
         }
        $paginator = $this->getProjectViewedTable()->fetchAll(true,array('projectId'=>$projectId));
        // set the current page to what has been passed in query string, or to 1 if none set
        $paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
        // set the number of items per page to 10
        $paginator->setItemCountPerPage(10);

        return new ViewModel(
            array(
                'paginator' => $paginator
                ,'projectId'=>$projectId
            )
        );
    }
    
    
}
