<?php
namespace Admin\Controller;

use Admin\Controller\PController;
use Zend\View\Model\ViewModel;
use Admin\Model\State;
use Admin\Form\StateForm;

class StateController extends PController
{
    public function indexAction()
    {
        /*$configVars = $this->getServiceLocator()->get('Config');
        echo '<pre>';print_r($configVars);die;*/
        
         // grab the paginator from the AlbumTable
        $paginator = $this->getStateTable()->fetchAll(true);
        // set the current page to what has been passed in query string, or to 1 if none set
        $paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
        // set the number of items per page to 10
        $paginator->setItemCountPerPage(10);

        return new ViewModel(
            array(
                'paginator' => $paginator
            )
        );
    }
    
    public function addAction()
    {
         
		 $isStateAvailable = true;
		 $errorMessage = "";
		 $message = "";
         $statusArray = array();
		 $countryArr = $this->getCountryTable()->fetchAll(false, array());
		 foreach ($countryArr as $countryArrKey => $countryArrVal) {            
            $countryArray[$countryArrVal->countryId] = $countryArrVal->countryName;
         }
        
        $statusArr = $this->getLookupStatusTable()->fetchAll(false, array('statusId'=>array(1,2)));
        foreach ($statusArr as $statusArrKey => $statusArrVal) {            
            $statusArray[$statusArrVal->statusId] = $statusArrVal->statusCode;
        }
         
         $form = new StateForm($countryArray,$statusArray);
         $form->get('submit')->setValue('Add');
         $request = $this->getRequest();
         if ($request->isPost()) {
             $state = new State();
             $data = $request->getPost()->toArray();
             if(!empty($data['stateCode'])){			
				if($this->getStateTable()->getStateBycode($data['stateCode'])) {
							
						$isStateAvailable = false;
						$errorMessage = "State code exist use another";
				}
			}
            $form->setInputFilter($state->getInputFilter());
            $form->setData($request->getPost());
			if($isStateAvailable){
				if ($form->isValid()) {
					 $state->exchangeArray($form->getData());
					 $this->getstateTable()->saveState($state);
					 $message = "State Created";
					 $this->flashmessenger()->addMessage($message);
					 // Redirect to list of albums
					 return $this->redirect()->toRoute('admin/child',array('controller'=>'state','action'=>'index'));
				}
		   } else {
			   $errorMessage = "State code exist use another";
		   }
         }
         return array('form' => $form,'errorMessage'=>$errorMessage);
     }
    public function editAction()
     {
		
         $stateId = (int) $this->params()->fromRoute('id', 0);
         if (!$stateId) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'state'
                 ,'action' => 'add'
             ));
         }
		 $isStateAvailable = true;
		 $errorMessage = "";
		 $message = "";
         // Get the Album with the specified id.  An exception is thrown
         // if it cannot be found, in which case go to the index page.
         try {
             $state = $this->getStateTable()->getState($stateId);
         }
         catch (\Exception $ex) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'state'
                 ,'action' => 'index'
             ));
         }
         $countryArr = $this->getCountryTable()->fetchAll(false, array());
		 foreach ($countryArr as $countryArrKey => $countryArrVal) {            
            $countryArray[$countryArrVal->countryId] = $countryArrVal->countryName;
         }
         $statusArray = $this->getStateTable()->statusArray();
         $form = new StateForm($countryArray,$statusArray);      
         $form->bind($state);
         $form->get('submit')->setAttribute('value', 'Update');

         $request = $this->getRequest();
         
         if ($request->isPost()) {
			
             $form->setInputFilter($state->getInputFilter());
             $form->setData($request->getPost());
			 $data = $request->getPost()->toArray();
             if(!empty($data['stateCode'])){			
				if($this->getStateTable()->getStateBycode($data['stateCode'],$stateId)) {
							
						$isStateAvailable = false;
						$errorMessage = "State code exist use another";
				}
			}
			if($isStateAvailable){
				if ($form->isValid()) {
					$this->getStateTable()->savestate($state);
					$message = "State Updated";
					$this->flashmessenger()->addMessage($message);
					 // Redirect to list of albums
					return $this->redirect()->toRoute('admin/child', array(
					 'controller' => 'state'
					 ,'action' => 'index'
					));
				}
			} else {
			   $errorMessage = "State code exist use another";
		    }
         }
         $viewModel = new ViewModel(array(
             'id' => $stateId,
             'form' => $form,
             'errorMessage'=>$errorMessage,
         ));
         $viewModel->setTemplate('admin/state/add.phtml');
         return $viewModel;
     }
     public function deleteAction()
     {
         $stateId = (int) $this->params()->fromRoute('id', 0);
         
         if (!$stateId) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'state'
                 ,'action' => 'index'
             ));
         }
         
        $this->getStateTable()->deleteState($stateId);
        // Redirect to list of albums
        
        return $this->redirect()->toRoute('admin/child', array(
         'controller' => 'state'
         ,'action' => 'index'
        ));
        
     }
     
}
