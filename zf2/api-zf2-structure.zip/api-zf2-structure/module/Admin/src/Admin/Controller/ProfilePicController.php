<?php
namespace Admin\Controller;

use Zend\View\Model\ViewModel;
use Admin\Model\ProfilePic;
use Admin\Model\User;
use Admin\Form\ProfilePicForm;
use Admin\Service\FileUpload;
use Exception;

class ProfilePicController extends PController
{
    public function indexAction()
    { 
        $userId = (int) $this->params()->fromRoute('id', 0);
        if (!$userId) {
         return $this->redirect()->toRoute('admin/child', array(
             'controller' => 'user'
             ,'action' => 'index'
         ));
        }
        $user= new User();
        $userData = $this->getUserTable()->getUser($userId);
        $form = new ProfilePicForm();  
        $form->get('userId')->setAttribute('value', $userId);
        $configVars = $this->getServiceLocator()->get('Config');
        $profile_image_dir = $configVars['profile_image_dir'];
        $request = $this->getRequest();
        
        if ($request->isPost()) {
            
            $profilePic= new ProfilePic();
            $form->setInputFilter($profilePic->getInputFilter());
            $data = $request->getPost()->toArray();
            
            
            $form->setData($data);
           # var_dump($form->isValid());die;
            if ($form->isValid()) { 
                #echo 'Valid';die;
                try {
                    $uploadObj = new FileUpload(true);
                    $File    = $this->params()->fromFiles('profilePic');
                    $uploadObj->resize = true;
                    $uploadObj->createThumb = true;
                    //$uploadObj->resizeOption = '';
                    $uploadObj->document_root = $configVars['document_root'];
                    $uploadObj->convert_path = $configVars['convert_path'];
                    
                    $fileName = $uploadObj->upload($File,array($profile_image_dir,$userId));
                    $data['profilePic'] = $fileName;
                    $profilePic->exchangeArray($data);
                    try {
                        $this->getProfilePicTable()->saveProfilePic($profilePic);
                        
                        $idInserted = $this->getProfilePicTable()->lastInsertedValue();
                        $row = $this->getProfilePicTable()->getProfilePic($idInserted);
                        if(isset($row->defaultPic) && $row->defaultPic==1){
                        $userData->profilePicId=$idInserted;
                        $user->exchangeArray($userData);
                        $this->getUserTable()->saveUser($user);
                        }
                    }
                    catch(Exception $e) {
                        $this->flashmessenger()->addMessage($e->getMessage());
                    }
                }
                catch(Exception $e) { 
                    $this->flashmessenger()->addMessage($e->getMessage());
                }
            }
            return $this->redirect()->toRoute('admin/child', array('controller'=>'profilepic','action' => 'index','id'=>$userId));
        }
       
        $paginator = $this->getProfilePicTable()->fetchAll(true,array('userId'=>$userId));
        // set the current page to what has been passed in query string, or to 1 if none set
       
        $paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
        // set the number of items per page to 10
        $paginator->setItemCountPerPage(10);
        
        return new ViewModel(
            array(
                'paginator' => $paginator
                ,'profile_image_dir'=>$profile_image_dir
                ,'form'=>$form
            )
        );
    }
    
    public function deleteAction()
    { 
        $userId = (int) $this->params()->fromRoute('id', 0);
        $profilePicId = (int) $this->params()->fromQuery('im_id',0);
       
        if (empty($userId)) {
                return $this->redirect()->toRoute('admin/child', array(
                    'controller' => 'user'
                    ,'action' => 'index'
                ));
        }
        if(empty($profilePicId)) {
            return $this->redirect()->toRoute('admin/child', array(
                'controller' => 'profilepic'
                ,'action' => 'index'
                ,'id'=>$userId
            ));
        }
        try {
            $row = $this->getProfilePicTable()->getProfilePic($profilePicId);
            if(isset($row->defaultPic) && $row->defaultPic==1){
                $this->flashmessenger()->addMessage("Default profile image canot be deleted.");
            }
            else{
            $imageName = $row->profilePic;
            //$userId = $row->userId;
            $configVars = $this->getServiceLocator()->get('Config');
            $document_root = $configVars['document_root'];        
            $this->getProfilePicTable()->deleteProfilePic($profilePicId);
            unlink($document_root.'/'.$configVars['profile_image_dir'].'/'.$userId.'/'.$imageName);
            // Redirect to list of Project Image
            $this->flashmessenger()->addMessage("Image Deleted");
            }
        }
        catch(Exception $e) {
            $this->flashmessenger()->addMessage($e->getMessage());
        }
        return $this->redirect()->toRoute('admin/child', array(
            'controller' => 'profilepic'
            ,'action' => 'index'
            ,'id'=>$userId
        ));

    }
    
    
    public function defaultProfileAction(){
        
        $userId = (int) $this->params()->fromRoute('id', 0);
        $profilePicId = (int) $this->params()->fromQuery('pid',0);
        //$profilePicData=array('userId'=>$userId,'profilePicId'=>$profilePicId,'defaultPic'=>1);
        $profilePic= new ProfilePic();
        $getProfileData=$this->getProfilePicTable()->getProfilePic($profilePicId);
        $user= new User();
        $userData = $this->getUserTable()->getUser($userId);
        if (empty($userId)) {
                return $this->redirect()->toRoute('admin/child', array(
                    'controller' => 'user'
                    ,'action' => 'index'
                ));
        }
        if(empty($profilePicId)) {
            return $this->redirect()->toRoute('admin/child', array(
                'controller' => 'profilepic'
                ,'action' => 'index'
                ,'id'=>$userId
            ));
        }
        //echo "<pre>";var_dump($getProfileData);exit;
        //$profilePic->exchangeArray($getProfileData);
        try {
            $this->getProfilePicTable()->saveProfilePic($getProfileData);
            $userData->profilePicId=$profilePicId;
             $user->exchangeArray($userData);
            $this->getUserTable()->saveUser($user);
            // Redirect to list of Project Image
            $this->flashmessenger()->addMessage("ProfilePic Updated");
        }
        catch(Exception $e) {
            $this->flashmessenger()->addMessage($e->getMessage());
        }
        return $this->redirect()->toRoute('admin/child', array(
            'controller' => 'profilepic'
            ,'action' => 'index'
            ,'id'=>$userId
        ));
        
    }
}
