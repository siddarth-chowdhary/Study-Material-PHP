<?php

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\View\Model\JsonModel;
use Admin\Model\User;
use Admin\Model\UserAddress;
use Admin\Model\UserInterest;
use Admin\Model\UserContact;
use Admin\Model\PrivacySetting;
use Admin\Form\PrivacySettingForm;
use Admin\Form\UserForm;
use Admin\Form\ResetPasswordForm;
use Zend\Validator\File\Size;
use Admin\Model\PHPMailer;
use Admin\Form\MailForm;
use Zend\Mail\Message;
use Zend\Mail\Transport\Smtp as SmtpTransport;
use Zend\Mime\Message as MimeMessage;
use Zend\Mime\Part as MimePart;
use Zend\Mail\Transport\SmtpOptions;

class UserController extends PController {

    public function indexAction() {

        $logDetail = $this->getAuthService()->getStorage()->read();
        $search = $this->params()->fromQuery('search', array());
        
        
        
        $page = (int) $this->params()->fromQuery('page', 1);
        $itemPerPage = 10;
        
        #$search['userType'] = $logDetail->userType;
        $paginator = $this->getUserTable()->fetchAll(true, $search, $logDetail->userId);

        // set the current page to what has been passed in query string, or to 1 if none set
        $paginator->setCurrentPageNumber($page);
        // set the number of items per page to 10
        $paginator->setItemCountPerPage($itemPerPage);
        $userTypeArray = $isActive = array();
        $statusArr = $this->getLookupStatusTable()->fetchAll(false, array('statusId' => array(1, 2)));
        foreach ($statusArr as $statusArrKey => $statusArrVal) {
            $isActive[$statusArrVal->statusId] = $statusArrVal->statusCode;
        }
        return new ViewModel(array(
            'paginator' => $paginator,
            'search' => $search,
            'isActive' => $isActive,
            'page' => $page
            ,'itemPerPage'=>$itemPerPage
        ));
    }

    public function addAction() {
        $message = "";
        $errorMessage = "";
        $userTypeArray = $userStatusArray = $countryArray = $stateArray = $countryPhoneCodeArray = array();
        $configVars = $this->getServiceLocator()->get('Config');


        $statusArr = $this->getLookupStatusTable()->fetchAll(false, array('statusId' => array(1, 2)));
        foreach ($statusArr as $statusArrKey => $statusArrVal) {
            $userStatusArray[$statusArrVal->statusId] = $statusArrVal->statusCode;
        }

        $countryArr = $this->getCountryTable()->fetchAll(false, array());
        foreach ($countryArr as $countryArrKey => $countryArrVal) {
            $countryArray[$countryArrVal->countryId] = $countryArrVal->countryName;
        }

        $countryPhoneArr = $this->getCountryTable()->fetchAll(false, array());
        foreach ($countryPhoneArr as $countryPhoneArrKey => $countryPhoneArrVal) {
            $countryPhoneCodeArray[$countryPhoneArrVal->countryPhoneCode] = $countryPhoneArrVal->countryName . '(' . $countryPhoneArrVal->countryPhoneCode . ')';
        }
        

        $stateArr = $this->getStateTable()->fetchAll(false, $countryId=0);
        foreach ($stateArr as $stateArrKey => $stateArrArrVal) {
            $stateArray[$stateArrArrVal->stateId] = $stateArrArrVal->stateName;
        }
        //$stateArray=array('1'=>'BIR','2'=>'PAT');
        $genderArray = $this->getUserTable()->genderArray();
        $userTypeArray = $this->getUserTable()->userTypeArray();
        $form = new UserForm($userTypeArray, $userStatusArray, $genderArray, $countryArray, $stateArray, $countryPhoneCodeArray);

        $form->get('submit')->setAttribute('value', 'Save');
        $request = $this->getRequest();
        if ($request->isPost()) {
            $user = new User();
            $form->setInputFilter($user->getInputFilter());

            $data = $request->getPost()->toArray();

            if (!empty($data['password'])) {
                $passwordEmail = $data['password'] = SHA1($data['password']);
            }
            $File = $this->params()->fromFiles('profilePic');

            $form->setData($data);

            if ($form->isValid()) {

                try {
                    $m = $this->getUserTable()->getDetailByColumns(array('email' => $data['email']));
                    $isMailExist = true;
                } catch (\Exception $e) {
                    $isMailExist = false;
                }

                if ($isMailExist) {
                    $errorMessage = "Email Id Exist use another";
                } else {
                    $replaceItem = array("(", ")", " ", "-");
                    if (!empty($data['phone'])) {
                        //$data['phone'] = str_replace($replaceItem, "", $data['phone']);
                        $data['phone'] = $data['phone'];
                    }
                    if (!empty($idInserted) && !empty($File['name'])) {
                        $extension = $this->getExtension($File['name']);
                        if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) {
                            
                        } else {
                            $tmp_path = $File['tmp_name'];
                            $imageName = time() . '.' . $extension;
                            $convert_path = $configVars['convert_path'];
                            $document_root = $configVars['document_root'];
                            $user_image = $document_root . '/userImages/' . $imageName;
                            $command_resize = "{$convert_path} {$tmp_path} -resize 130x130\!  {$user_image}";
                            try {
                                $exec_command = exec($command_resize);
                                $data['profilePic'] = $imageName;
                            } catch (Exception $e) {
                                
                            }
                        }
                    }

                    $user->exchangeArray($data);
                    try {
                        $this->getUserTable()->saveUser($user);
                        $idInserted = $this->getUserTable()->lastInsertedValue();
                        $data['userId'] = $idInserted;
                        $this->updateUserAddressAndInterest($data);
                        //Insert data in privacySetting Table
                        $privacySetting = new PrivacySetting();
                        $privacySetting->exchangeArray($data);
                        //echo "<pre>";print_r($privacySetting);exit;
                        $pvcSetting = $this->getPrivacySettingTable()->savePrivacySetting($privacySetting);

                        //save privacy setting end here
                        $message = "User Created";
                        $this->flashmessenger()->addMessage($message);
                        return $this->redirect()->toRoute('admin/child', array('controller' => 'user', 'action' => 'index'));
                    } catch (\Admin\Service\MyException $e) {
                        $errorMessage = $e->getMessage();
                    }
                }
            } else {
                #var_dump($form->getMessages());die;
                //$errorMessage= "Form is not valid.Please fill required field.";
                //$this->flashmessenger()->addMessage($errorMessage);      
            }
        }

        return new ViewModel(array('form' => $form, 'errorMessage' => $errorMessage,));
    }

    public function editAction() {

        $message = $errorMessage = $profilePicSaved = "";
        $userStatusArray = $countryArray = $stateArray = $countryPhoneArr = array();
        $id = (int) $this->params('id');

        if (!$id) {
            return $this->redirect()->toRoute('admin/child', array('controller' => 'user', 'action' => 'add'));
        }
        try {
            $userData = $this->getUserTable()->getUser($id);
        } catch (\Exception $e) {
            die($e->getMessage());
        }
        //echo "<pre>";print_r($userData);exit;
        $configVars = $this->getServiceLocator()->get('Config');

        $statusArr = $this->getLookupStatusTable()->fetchAll(false, array('statusId' => array(1, 2)));
        foreach ($statusArr as $statusArrKey => $statusArrVal) {
            $userStatusArray[$statusArrVal->statusId] = $statusArrVal->statusCode;
        }

        $countryArr = $this->getCountryTable()->fetchAll(false, array());
        foreach ($countryArr as $countryArrKey => $countryArrVal) {
            $countryArray[$countryArrVal->countryId] = $countryArrVal->countryName;
        }
        $countryPhoneArr = $this->getCountryTable()->fetchAll(false, array());
        foreach ($countryPhoneArr as $countryPhoneArrKey => $countryPhoneArrVal) {
            $countryPhoneCodeArray[$countryPhoneArrVal->countryPhoneCode] = $countryPhoneArrVal->countryName . '(' . $countryPhoneArrVal->countryPhoneCode . ')';
        }
        $request = $this->getRequest();
        if ($request->isPost()) {
            $postArr = $request->getPost()->toArray();
            $countryId = $postArr['countryId'];
        } else {
            $countryId = $userData->countryId;
        }

        $stateArr = $this->getStateTable()->fetchAll(false, $countryId);
        foreach ($stateArr as $stateArrKey => $stateArrArrVal) {
            $stateArray[$stateArrArrVal->stateId] = $stateArrArrVal->stateName;
        }

        $genderArray = $this->getUserTable()->genderArray();
        $userTypeArray = $this->getUserTable()->userTypeArray();

        $form = new UserForm($userTypeArray, $userStatusArray, $genderArray, $countryArray, $stateArray, $countryPhoneCodeArray);
        $user = new User();
        $form->setInputFilter($user->getInputFilter());

        $userTypeId = (int) $userData->userType;
        $email_user = $userData->email;

        $profilePicSaved = $userData->profilePicId;

        //echo "<pre>";print_r($userData);exit;
        $phoneDt = explode('-', $userData->phone);
        if (isset($phoneDt[1]) && $phoneDt[1] != '') {
            $userData['phone'] = $phoneDt[1];
        }
        $userData['countryPhoneCode'] = $phoneDt[0];

        $form->bind($userData);
        $form->get('submit')->setAttribute('value', 'Update');

        if ($request->isPost()) {
            $data = $request->getPost()->toArray();

            if (isset($userData->createdDate)) {
                $data['createdDate'] = $userData->createdDate;
            }
            if (empty($data['password'])) {
                $data['password'] = $userData->password;
            } else {
                $data['password'] = sha1($data['password']);
            }
            $File = $this->params()->fromFiles('profilePic');
            $form->setData($data);
            if ($form->isValid()) {
                $data['profilePicId'] = $profilePicSaved;
                $replaceItem = array("(", ")", " ", "-");
                if (!empty($data['phone'])) {

                    //$data['phone'] = str_replace($replaceItem, "", $data['phone']);                    
                    $data['phone'] = $data['phone'];
                }
                
                $user->exchangeArray($data);
                try {
                    $updateUser = $this->getUserTable()->saveUser($user);
                    $this->updateUserAddressAndInterest($data);
                    $message = "User updated";
                    $this->flashmessenger()->addMessage($message);
                    return $this->redirect()->toRoute('admin/child', array('controller' => 'user', 'action' => 'index'));
                } catch (\Admin\Service\MyException $e) {
                    $errorMessage = $e->getMessage();
                }
            } else {
                //var_dump($form->getMessages());
                //$errorMessage= "Form is not valid.Please fill required field.";
                //$this->flashmessenger()->addMessage($errorMessage);    
            }
        }
        $viewModel = new ViewModel(array(
            'id' => $id,
            'form' => $form,
            'errorMessage' => $errorMessage,
            'profilePicSaved' => $profilePicSaved,
        ));
        $viewModel->setTemplate('admin/user/add.phtml');
        return $viewModel;
    }

    public function contactsAction() {
        $id = (int) $this->params('id');
        $page = $this->params()->fromQuery('page', 1);

        if (!$id) {
            return $this->redirect()->toRoute('admin/child', array('controller' => 'user', 'action' => 'add'));
        }

        $paginator = $this->getUserContactTable()->fetchAll(true, array('userId' => $id));

        // set the current page to what has been passed in query string, or to 1 if none set
        $paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));

        // set the number of items per page to 10
        $paginator->setItemCountPerPage(10);
        return new ViewModel(array(
            'paginator' => $paginator
            , 'userId' => $id,
            'page' => $page,
        ));
    }

    public function deleteAction() {
        $id = (int) $this->params('id');
        $restaurantId = "";
        $message = "";
        if (!$id) {
            return $this->redirect()->toRoute('admin/child', array('controller' => 'user', 'action' => 'index'));
        }
        $this->getUserTable()->deleteUser($id);
        $this->getUserInterestTable()->deleteLookupInterest($id);
        $this->getUserAddressTable()->deleteAddressByUserId($id);
        $message = "User Deleted!";
        $this->flashmessenger()->addMessage($message);
        // Redirect to list of user
        return $this->redirect()->toRoute('admin/child', array('controller' => 'user', 'action' => 'index'));
    }

    public function resetAction() {
        $message = "";
        $errorMessage = "";
        $mailAddress = "";
        $form = new ResetPasswordForm();
        $id = (int) $this->params('id');
        if (!$id) {
            return $this->redirect()->toRoute('admin/child', array('controller' => 'user', 'action' => 'index'));
        }
        $user = $this->getUserTable()->getUser($id);
        if (isset($user->password)) {
            $user->password = "";
        }
        if (isset($user->email)) {
            $mailAddress = $user->email;
        }

        $form->bind($user);
        $form->get('submit')->setAttribute('value', 'Save');
        $request = $this->getRequest();
        if ($request->isPost()) {

            $data = $request->getPost();

            if (!empty($data['newpassword']) && !empty($data['oldpassword'])) {
                $data['password'] = SHA1($data['newpassword']);
                $data['userId'] = $data['userId'];
                //set data post 

                $form->setData($data);
                //var_dump($form);die;

                if ($form->isValid()) {

                    if ($this->getUserTable()->getUserByPassword(SHA1($data['oldpassword']), $id)) {
                        $user->exchangeArray($data);
                        $this->getUserTable()->resetPassword($user);

                        $message = "Password Changed!.";
                        $this->flashmessenger()->addMessage($message);
                        /* $subject = "Reset Password";
                          $body = "UserName  :". $mailAddress."<br />";
                          $body .= "Password : ". $data['newpassword'];
                          $this->sendMail($subject,$body,$mailAddress); */

                        return $this->redirect()->toRoute('admin/child', array('controller' => 'user', 'action' => 'index'));
                    } else {

                        $errorMessage = "Password not valid";
                    }
                } else {
                    //echo "<pre>";	
                    //print_r($form);			die;
                    //$errorMessage= "Form is not valid.Please fill required field.";
                    //$this->flashmessenger()->addMessage($errorMessage);    
                }
            } else {
                $errorMessage = "Please enter old password and new password";
            }
        }
        $user->password = "";
        $form->bind($user);
        return array(
            'id' => $id,
            'form' => $form,
            'errorMessage' => $errorMessage,
        );
    }

    protected function updateUserAddressAndInterest($formData) {
        #echo '<pre>';print_r($formData);die;
        $countryName = $stateName = '';
        $userAddress = new UserAddress();
        $map = $this->getServiceLocator()->get('Admin\Service\GoogleMap'); //getting the google map object using service manager
        $userAddress->exchangeArray($formData);
        if (!empty($userAddress->countryId)) {
            $countryInfo = $this->getCountryTable()->getCountry($userAddress->countryId);
            $countryName = $countryInfo->countryName;
        }
        if (!empty($userAddress->stateId)) {
            $stateArr = $this->getStateTable()->getState($userAddress->stateId);
            $stateName = $stateArr->stateName;
        }

        $latLong = $map->getLatLongByAddress($userAddress->address . ",{$stateName},{$countryName}");
        if (!empty($latLong['lat']) && !empty($latLong['long'])) {
            $userAddress->longitude = $latLong['long'];
            $userAddress->latitude = $latLong['lat'];
        }
        $updateUserAddress = $this->getUserAddressTable()->saveUserAddress($userAddress);

        $userInterest = new UserInterest();
        $userInterest->exchangeArray($formData);
        $updateUserAddress = $this->getUserInterestTable()->saveUserInterest($userInterest);
    }

    public function statusAction() {

        $userId = (int) $this->params('id');
        $statusId = $this->params()->fromQuery('statusId');
        if (!$userId) {
            return $this->redirect()->toRoute('admin/child', array('controller' => 'user', 'action' => 'index'));
        }
        $data = array('statusId' => $statusId);
        $userData = $this->getUserTable()->exchangeStatus($data, $userId);
        $statusMessage = "Status Updated Successfully";
        $this->flashmessenger()->addMessage($statusMessage);
        $page = $this->params()->fromQuery('page', 1);
        $url = $this->url()->fromRoute('admin/child', array('controller' => 'user', 'action' => 'index')) . '?page=' . $page;
        return $this->redirect()->toUrl($url);
    }

    public function privacySettingAction() {
        $settingId = (int) $this->params()->fromRoute('id', 0);
        if (!$settingId) {
            return $this->redirect()->toRoute('admin/child', array(
                        'controller' => 'user'
                        , 'action' => 'index'
            ));
        }
        $isPrivacySettingAvailable = true;
        $errorMessage = "";
        $message = "";
        // Get the Album with the specified id.  An exception is thrown
        // if it cannot be found, in which case go to the index page.
        try {
            $privacysetting = $this->getPrivacySettingTable()->getPrivacySetting($settingId);
        } catch (\Exception $ex) {
            return $this->redirect()->toRoute('admin/child', array(
                        'controller' => 'user'
                        , 'action' => 'index'
            ));
        }

        $form = new PrivacySettingForm();
        $form->bind($privacysetting);
        $form->get('submit')->setAttribute('value', 'Update');

        $request = $this->getRequest();

        if ($request->isPost()) {

            $form->setInputFilter($privacysetting->getInputFilter());
            $form->setData($request->getPost());
            $data = $request->getPost()->toArray();

            if ($isPrivacySettingAvailable) {
                if ($form->isValid()) {//echo "<pre>";print_r($data);exit;
                    $this->getPrivacySettingTable()->savePrivacySetting($privacysetting);
                    $message = "Privacy Setting Updated";
                    $this->flashmessenger()->addMessage($message);
                    // Redirect to list of albums
                    return $this->redirect()->toRoute('admin/child', array(
                                'controller' => 'user'
                                , 'action' => 'index'
                    ));
                }
            } else {
                $errorMessage = "privacy setting exist";
            }
        }
        $viewModel = new ViewModel(array(
            'id' => $settingId,
            'form' => $form,
            'errorMessage' => $errorMessage,
        ));
        $viewModel->setTemplate('admin/user/privacySetting.phtml');
        return $viewModel;
    }
    
    /**
     * @Desc To send mail to a list of users
     */
    public function mailAction() {
        $countryArr = $this->getCountryTable()->fetchAll(false, array());        
        foreach ($countryArr as $countryArrKey => $countryArrVal) {              
            $countryArray[$countryArrVal->countryId] = $countryArrVal->countryName;
        }
        $searchParams = $this->params()->fromQuery('search', array());
        $form = new MailForm($countryArray);
        $form->get('submit')->setAttribute('value', 'Search');
        $request = $this->getRequest();
        //$searchParams = $request->getPost()->toArray(); //var_dump($searchParams);exit;
        //$searchedUsers = $this->getUserTable()->searchUsers($searchParams);
        $searchedUsers = $this->getUserTable()->searchUsers($searchParams);
        $viewModel = new ViewModel(array(
            'form' => $form,
            'users' => $searchedUsers,
            'search' => $searchParams,
            'flashMessages' => $this->flashMessenger()->getMessages()
        ));
        return $viewModel;
    }

    public function firemailAction() {
        $emailIds = array();
        $message = '';
        $request = $this->getRequest();
        $response = $this->getResponse();
        if ($request->isPost()) {
            $post_data = $request->getPost();
            $emailIds = $post_data['users'];
            $message = $post_data['emailBody'];
            $tmp = array();
            foreach ($emailIds as $key => $value) {
                $tmp[] = $value;
            }
            try {
                $my_mailer = $this->getServiceLocator()->get('Admin\Service\MyMailer');
                $my_mailer->setSubject('Message By Admin')
                        ->setMessage($message)
                        ->setToMails($emailIds)
                        ->sendMail();
            } catch (\Admin\Service\MyException $e) {
                return new JsonModel(array('status' => 'error', "message" => $e->getMessage()));
            }
            return new JsonModel(array('status' => 'success', "message" => 'Success'));
        }
    }

    public function ajaxAction() {

        $request = $this->getRequest('countryId');
        $response = $this->getResponse();
        $countryId = '';
        $stateArr = $stateArray = array();
        if ($request->isPost()) {
            $data = $request->getPost()->toArray();
            $countryId = $data['countryId'];
            $stateArr = $this->getStateTable()->fetchAll(false, $countryId);

            foreach ($stateArr as $stateArrKey => $stateArrArrVal) {
                $stateArray[$stateArrArrVal->stateId] = $stateArrArrVal->stateName;
            }
            $response->setContent(\Zend\Json\Json::encode(array('success' => 1, 'stateArr' => $stateArray)));
        } else {
            $response->setContent(\Zend\Json\Json::encode(array('success' => 0)));
        }
        return $response;
    }

}
