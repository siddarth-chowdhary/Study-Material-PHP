<?php
namespace Admin\Controller;

use Zend\View\Model\ViewModel;
use Admin\Model\ProjectImage;
use Admin\Form\ProjectImageForm;
use Admin\Service\FileUpload;
use Exception;

class ProjectImageController extends PController
{
    public function indexAction()
    {
        $projectId = (int) $this->params()->fromRoute('id', 0);
        if (!$projectId) {
         return $this->redirect()->toRoute('admin/child', array(
             'controller' => 'project'
             ,'action' => 'index'
         ));
        }
         
        $form = new ProjectImageForm();  
        $form->get('projectId')->setAttribute('value', $projectId);
        $configVars = $this->getServiceLocator()->get('Config');
        $project_image_dir = $configVars['project_image_dir'];
        $request = $this->getRequest();
        $msg="Please select file";
        $pageWasRefreshed = isset($_SERVER['HTTP_CACHE_CONTROL']) && $_SERVER['HTTP_CACHE_CONTROL'] === 'max-age=0';

        if ($request->isPost() && !$pageWasRefreshed) {
            
            $projectImage= new ProjectImage();
            $form->setInputFilter($projectImage->getInputFilter());
            $data = $request->getPost()->toArray();
            $File    = $this->params()->fromFiles('image');
            $form->setData($data);
            if ($form->isValid()) {
                try {
                    $uploadObj = new FileUpload(true);
                    /*$uploadObj->resize = true;
                    $uploadObj->resizeOption = '';*/
                    $uploadObj->document_root = $configVars['document_root'];
                    $uploadObj->convert_path = $configVars['convert_path'];
                    $fileName = $uploadObj->upload($File,array($project_image_dir,$projectId));
                    $data['image'] = $fileName;
                    $projectImage->exchangeArray($data);
                    try {
                        $this->getProjectImageTable()->saveProjectImage($projectImage);
                    }
                    catch(Exception $e) {
                        $this->flashmessenger()->addMessage($msg);
                    }
                }
                catch(Exception $e) {
                    $this->flashmessenger()->addMessage($msg);
                }
            }
            return $this->redirect()->toRoute('admin/child', array('controller'=>'projectImage','action' => 'index','id'=>$projectId));
        }
        
        $paginator = $this->getProjectImageTable()->fetchAll(true,array('projectId'=>$projectId));
        // set the current page to what has been passed in query string, or to 1 if none set
        $paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
        // set the number of items per page to 10
        $paginator->setItemCountPerPage(10);

        return new ViewModel(
            array(
                'paginator' => $paginator
                ,'projectId'=>$projectId
                ,'project_image_dir'=>$project_image_dir
                ,'form'=>$form
            )
        );
    }
    
    public function deleteAction()
    {
        $projectId = (int) $this->params()->fromRoute('id', 0);
        $im_id = (int) $this->params()->fromQuery('im_id',0);
        if (empty($projectId)) {
                return $this->redirect()->toRoute('admin/child', array(
                    'controller' => 'project'
                    ,'action' => 'index'
                ));
        }
        if(empty($im_id)) {
            return $this->redirect()->toRoute('admin/child', array(
                'controller' => 'projectImage'
                ,'action' => 'index'
                ,'id'=>$projectId
            ));
        }
        $row = $this->getProjectImageTable()->getProjectImage($im_id);
        $imageName = $row->image;
        $configVars = $this->getServiceLocator()->get('Config');
        $document_root = $configVars['document_root'];
        $this->getProjectImageTable()->deleteProjectImage($im_id,$projectId);
        @unlink($document_root.'/'.$configVars['project_image_dir'].'/'.$projectId.'/'.$imageName);
        // Redirect to list of Project Image
        $this->flashmessenger()->addMessage("Image Deleted");
        return $this->redirect()->toRoute('admin/child', array(
            'controller' => 'projectImage'
            ,'action' => 'index'
            ,'id'=>$projectId
        ));

    }
}
