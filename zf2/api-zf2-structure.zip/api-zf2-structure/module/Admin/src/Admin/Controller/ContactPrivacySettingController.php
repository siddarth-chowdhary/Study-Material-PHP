<?php
namespace Admin\Controller;

use Admin\Controller\PController;
use Zend\View\Model\ViewModel;
use Admin\Model\UserContact;
use Admin\Model\UserContactDetail;
use Admin\Model\ContactPrivacySetting;
use Admin\Form\UserContactForm;
use Admin\Form\ContactPrivacySettingForm;


class ContactPrivacySettingController extends PController
{
    public function indexAction()
    {
        $userStatusArray =$userContactArray=$formData=$receiverIdData= array();
        $contactCount = 1;
        $userId = (int) $this->params()->fromRoute('id', 0);
        $contactId = (int) $this->getRequest()->getQuery('cid', 0);
        $contactSettingId = (int) $this->getRequest()->getQuery('contactSettingId', 0);
        
        //echo $contactId;exit;
        if (!$userId) {
            return $this->redirect()->toRoute('admin/child', array(
                'controller' => 'contactprivacysetting'
                ,'action' => 'index'
            ));
        }
        
        //$statusArr = $this->getLookupStatusTable()->fetchAll(false, array('statusId'=>array(1,2)));
        $statusArr = $this->getLookupStatusTable()->fetchAll(false, array());
        foreach ($statusArr as $statusArrKey => $statusArrVal) {        
            $userStatusArray[$statusArrVal->statusId] = $statusArrVal->statusCode;
        }
        //Get user contact list
        $userContactListData = $this->getUserContactTable()->fetchAll(true, array('senderId'=>$userId));
        foreach($userContactListData as $userContactListDataKey=>$userContactListDataVal){
            $receiverIdData[]=$userContactListDataVal['receiverId'];
        }
        //echo "<pre>"; print_r($receiverIdData);exit;
       
        
        $contactArr=$this->getUserTable()->getUserList(array('statusId'=>1,'userType'=>2,'notequalto'=>array('userId'=>$userId),'excludeUser'=>true));
        foreach ($contactArr as $contactArrKey => $contactArrVal) {//echo "<pre>";print_r($contactArrVal);exit;            
            if($contactArrVal->firstName!='' || $contactArrVal->lastName!=''){
            $userContactArray[$contactArrVal->userId] = $contactArrVal->firstName.' '.$contactArrVal->lastName;
            }else{
                $userContactArray[$contactArrVal->userId] = $contactArrVal->phone;
            }
        }
        /*echo "<pre>";
        print_r($userContactArray);exit;*/
        
        $request = $this->getRequest();        
        /*if ($request->isPost()) {
            $data = $request->getPost()->toArray();
            $contactCount = $data['number_count'];
        }*/
        $message='';
        $form = new ContactPrivacySettingForm($userStatusArray,$contactCount,'',$userContactArray);
        
        $contactPrivacySetting = new ContactPrivacySetting();
        
        $form->get('submit')->setValue('Add');
        try{
            $settingData=$this->getContactPrivacySettingTable()->getContactPrivacySettingByUidCntId($userId,$contactId);
        }
        catch(\Exception $e) {
            $data=array(
                        'userId'=>$userId,
                        'contactUserId'=>$contactId,           
                        'hideLinkedin'=>'1',
                        'hideProject'=>'1',
                        'hideProfilePhoto'=>'1',
                        'block'=>'1',
                        'report'=>'1',
                );
                $contactPrivacySetting->exchangeArray($data);                
                $table = $this->getContactPrivacySettingTable();
                $table->saveContactPrivacySetting($contactPrivacySetting);
                $settingData=$this->getContactPrivacySettingTable()->getContactPrivacySettingByUidCntId($userId,$contactId);
        }
        $form->bind($settingData);
        
        if ($request->isPost()) {
           
           $form->setInputFilter($contactPrivacySetting->getInputFilter());

            $data = $request->getPost()->toArray();

            $form->setData($data);
            $contactPrivacySetting->exchangeArray($data);
            //echo "<pre>";print_r($contactPrivacySetting);exit;
            $this->getContactPrivacySettingTable()->saveContactPrivacySetting($contactPrivacySetting);
            $message = "Setting updated successfully";
            $this->flashmessenger()->addMessage($message);
        }
        
        //$form->get('senderId')->setValue($userId);
       
        return new ViewModel(
            array(
                'message'=>$message,
                'form' => $form
                ,'count_number' => $contactCount
            )
        );
    }
    
    public function editAction()
    {
	$contact_id = (int) $this->params()->fromRoute('id', 0);
        if (!$contact_id) {
            return $this->redirect()->toRoute('admin/child', array(
                'controller' => 'user'
                ,'action' => 'index'
            ));
        }
        
        $errorMessage = $userStatusArray = "";
		$message = "";
        try {
            $userContact = $this->getUserContactTable()->getUserContact($contact_id);
        }
        catch (\Exception $ex) {
            $this->flashmessenger()->addMessage('Selected contact not exist.');
            return $this->redirect()->toRoute('admin/child', array(
                'controller' => 'user'
                ,'action' => 'index'
            ));
        }
        #echo '<pre>';print_r($userContact);die;
        $userSavedContactArr = $this->getUserContactDetailTable()->getUserContactDetail($contact_id);
        $i=1;
        foreach($userSavedContactArr as $key=>$number) {
            #echo '<pre>';print_r($number);die;
            $column = "contactNumber-{$i}";
            $userContact->$column = $number->contactNumber;
            $i++;
        }
        $contactCount = ($i >1) ? $i-1 : 1;
        //echo $contactCount;
        //echo '<pre>';var_export($userContact);die;
        
        $statusArr = $this->getLookupStatusTable()->fetchAll(false, array('statusId'=>array(1,2)));
        foreach ($statusArr as $statusArrKey => $statusArrVal) {            
            $userStatusArray[$statusArrVal->statusId] = $statusArrVal->statusCode;
        }
        
         $request = $this->getRequest();
        if ($request->isPost()) {
            $data = $request->getPost()->toArray();
            $contactCount = $data['number_count'];
        }
        
        $form = new UserContactForm($userStatusArray,$contactCount);
         $form->setInputFilter($userContact->getInputFilter($contactCount));
         $form->bind($userContact);
         $form->get('submit')->setAttribute('value', 'Update');
         $request = $this->getRequest();
         
         if ($request->isPost()) {
			$data = $request->getPost()->toArray();
            
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $userContact->exchangeArray($data);
                
                $this->getUserContactTable()->saveUserContact($userContact);
                //$data['contactId'] = $lastInsertedId;
               // $this->updateUserContactDetail($data);
                $message = "Contact Added";
                $this->flashmessenger()->addMessage($message);
                return $this->redirect()->toRoute('admin/child',array('controller'=>'user','action'=>'contacts','id'=>$userContact->userId));
            }
         }
         $viewModel = new ViewModel(array(
             'form' => $form
             ,'errorMessage'=>$errorMessage
             ,'count_number' => $contactCount
         ));
         $viewModel->setTemplate('admin/user-contact/index.phtml');
         return $viewModel;
     }
     
     
     protected function updateUserContactDetail($data) {
        if(!empty($data['number_count'])) {
            $contDetailData = array();
            $checkNumber = array();
            for($i=1;$i<=$data['number_count'];$i++) {
                if(empty($data['contactNumber-'.$i]))
                    continue;
                $cNumber = str_replace(array('(',')',' ','-'),'',$data['contactNumber-'.$i]);
                
                if(!isset($checkNumber[$cNumber])) {
                    $checkNumber[$cNumber] = '';
                    $contDetailData[] = array(
                                        'contactId'=>$data['contactId']
                                        ,'contactNumber'=>$cNumber
                                        ,'defaultContact'=>0
                                    );
                }
                /*$userContactDetail = new UserContactDetail();
                $userContactDetail->exchangeArray($contDetailData);*/
            }
            try {
                $this->getUserContactDetailTable()->saveUserContactDetail($contDetailData,$data['contactId']);
            }
            catch(\Exception $e){}
        }
    }
     
     public function deleteAction()
     {
         $userId = (int) $this->params()->fromRoute('id', 0);
         $cid = (int) $this->params()->fromQuery('cid',0);
         if (!$userId) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'user'
                 ,'action' => 'index'
             ));
         }
         if (!$cid) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'user'
                 ,'action' => 'contacts'
                 ,'id' => $userId
             ));
         }
         
        $this->getUserContactTable()->delete($cid);
        //$this->getUserContactDetailTable()->delete($cid);
        // Redirect to list of albums
        
        return $this->redirect()->toRoute('admin/child', array(
         'controller' => 'user'
         ,'action' => 'contacts'
         ,'id' => $userId
        ));
        
     }
}
