<?php
namespace Admin\Controller;

use Admin\Controller\PController;
use Zend\View\Model\ViewModel;
use Admin\Model\Country;
use Admin\Form\CountryForm;

class CountryController extends PController
{
    public function indexAction()
    {
        // grab the paginator from the AlbumTable
        $paginator = $this->getCountryTable()->fetchAll(true);
        $page = $this->params()->fromQuery('page', 1); 
        // set the current page to what has been passed in query string, or to 1 if none set
        $paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
        // set the number of items per page to 10
        $paginator->setItemCountPerPage(10);

        return new ViewModel(
            array(
                'paginator' => $paginator,
                'page'=>$page
            )
        );
    }
    
    public function addAction()
    {
         $form = new CountryForm();
         $form->get('submit')->setValue('Add');
		 $isCountryAvailable = true;
		 $errorMessage = "";
		 $message = "";
         $request = $this->getRequest();
         if ($request->isPost()) {
             $country = new Country();
             $data = $request->getPost()->toArray();
             if(!empty($data['countryCode'])){			
				if($this->getCountryTable()->getCountryBycode($data['countryCode'])) {
							
						$isCountryAvailable = false;
						$errorMessage = "Country code exist use another";
				}
			}
            $form->setInputFilter($country->getInputFilter());
            $form->setData($request->getPost());
			if($isCountryAvailable){
				if ($form->isValid()) {
					 $country->exchangeArray($form->getData());
					 $this->getCountryTable()->saveCountry($country);
					 $message = "Country Created";
					 $this->flashmessenger()->addMessage($message);
					 // Redirect to list of albums
					 return $this->redirect()->toRoute('admin/child',array('controller'=>'country','action'=>'index'));
				}
		   } else {
			   $errorMessage = "Country code exist use another";
		   }
         }
         return new ViewModel(array('form' => $form,'errorMessage'=>$errorMessage));
     }
    public function editAction()
     {
		
         $countryId = (int) $this->params()->fromRoute('id', 0);
         if (!$countryId) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'country'
                 ,'action' => 'add'
             ));
         }
		 $isCountryAvailable = true;
		 $errorMessage = "";
		 $message = "";
         // Get the Album with the specified id.  An exception is thrown
         // if it cannot be found, in which case go to the index page.
         try {
             $country = $this->getCountryTable()->getCountry($countryId);
         }
         catch (\Exception $ex) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'country'
                 ,'action' => 'index'
             ));
         }

         $form  = new CountryForm();
         $form->bind($country);
         $form->get('submit')->setAttribute('value', 'Update');

         $request = $this->getRequest();
         
         if ($request->isPost()) {
			
             $form->setInputFilter($country->getInputFilter());
             $form->setData($request->getPost());
			 $data = $request->getPost()->toArray();
             if(!empty($data['countryCode'])) {
				if($this->getCountryTable()->getCountryBycode($data['countryCode'],$countryId)) {
						$isCountryAvailable = false;
						$errorMessage = "Country code exist use another";
				}
			}
			if($isCountryAvailable){
				if ($form->isValid()) {
					$this->getCountryTable()->saveCountry($country);
					$message = "Country Updated";
					$this->flashmessenger()->addMessage($message);
					 // Redirect to list of albums
					return $this->redirect()->toRoute('admin/child', array(
					 'controller' => 'country'
					 ,'action' => 'index'
					));
				}
			} else {
			   $errorMessage = "Country code exist use another";
		    }
         }
         $viewModel = new ViewModel(array(
             'id' => $countryId,
             'form' => $form,
             'errorMessage'=>$errorMessage,
         ));
         $viewModel->setTemplate('admin/country/add.phtml');
         return $viewModel;
     }
     public function deleteAction()
     {
         $countryId = (int) $this->params()->fromRoute('id', 0);
         
         if (!$countryId) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'country'
                 ,'action' => 'index'
             ));
         }
         
        $this->getCountryTable()->deleteCountry($countryId);
        // Redirect to list of albums
        
        return $this->redirect()->toRoute('admin/child', array(
         'controller' => 'country'
         ,'action' => 'index'
        ));
        
     }
}
