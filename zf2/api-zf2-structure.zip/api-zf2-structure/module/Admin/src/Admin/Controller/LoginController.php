<?php
namespace Admin\Controller;


use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Http\Client;
use Zend\Http\Client\Adapter\Curl;
use Admin\Form\LoginForm;
use Admin\Model\User;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;


class LoginController extends PController
{
    protected $userTable;
    public function onDispatch(MvcEvent $e)
    {
        $this->layout('layout/login');
        return parent::onDispatch($e);
    }
    
    public function indexAction()
    {
        if ($this->getAuthService()->hasIdentity()) {
            return $this->redirect()->toRoute('admin/child', array('controller'=>'user','action' => 'index'));
        }
        
        
        $form = new LoginForm();
        $errorMessages = array();
        $request = $this->getRequest();
        if ($request->isPost()) {
            $email = $this->getRequest()->getPost('email');
            $password = $this->getRequest()->getPost('password');
            if($email!='' && $password!='') {
                
                $auth = $this->getAuthService()->getAdapter();
                        $auth->setIdentity($email);
                        $auth->setCredential($password);
                
                $result = $this->getAuthService()->authenticate();
                
                foreach ($result->getMessages() as $message) {
                    //save message temporary into flashmessenger
                    //$this->flashmessenger()->addMessage($message);
                    $errorMessages[] = $message;
                }
                
                if ($result->isValid()) {
                    $redirect = 'success';
                    
                    //check if it has rememberMe :
                    if ($request->getPost('rememberme') == 1) {
                        $this->getSessionStorage()->setRememberMe(1);
                        //set storage again
                        $this->getAuthService()->setStorage($this->getSessionStorage());
                    }
                    $this->getAuthService()->setStorage($this->getSessionStorage());
                    $detail = $this->getUserTable()->getDetailByColumns(array('email'=>$email));
                    $this->getAuthService()->getStorage()->write($detail);
                    return $this->redirect()->toRoute('admin/child', array('controller'=>'user','action' => 'index'));
                }
            }
            else {
                $errorMessages[] = "Invalid username or password";
                //$this->flashmessenger()->addMessage("Invalid username or password");
            }
        }
        
        $view = new viewModel(array('form' => $form, 'flashMessages' => $errorMessages));
        return $view;
        
    }
    
    public function logoutAction()
    {
        if ($this->getAuthService()->hasIdentity()) {
            $this->getSessionStorage()->forgetMe();
            $this->getAuthService()->clearIdentity();
            #$this->flashmessenger()->addMessage("You've been logged out");
        }
        return $this->redirect()->toRoute('admin/child',array('controller'=>'login','action'=>'index'));
    }
}
