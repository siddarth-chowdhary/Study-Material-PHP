<?php
namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\Http\Client;
use Zend\Http\Client\Adapter\Curl;
use Zend\Mvc\MvcEvent;
use Zend\Session\Container;

class PController extends AbstractActionController
{
    protected $storage, $authservice;
    protected $userTable
            ,$LookupStatusTable
            ,$countryTable
            ,$stateTable
            ,$UserAddressTable
            ,$UserInterestTable
            ,$UserContactTable
            ,$ProjectImageTable
            ,$ProjectViewedTable
            ,$ProjectTable
            ,$ChatTable
            ,$UserContactDetail
            ,$ProfilePicTable
            ,$ChatUserTable
            ,$MessageReceiverTable
            ,$MessageTable
            ,$GeoLocationTable
            ,$PrivacySettingTable
            ,$ContactPrivacySettingTable
            ;
    /*protected $acceptMapping = array(
            'Zend\View\Model\ViewModel' => array(
                'text/html'
            )
        );*/
    
    public function getAuthService() {
        if (!$this->authservice) {
            $this->authservice = $this->getServiceLocator()
                    ->get('AuthService');
        }
        return $this->authservice;
    }

    public function getSessionStorage() {
        if (!$this->storage) {
            $this->storage = $this->getServiceLocator()
                    ->get('Admin\Model\MyAuthStorage');
        }
        return $this->storage;
    }  
    
    public function onDispatch(MvcEvent $e)
    {
        /*$logDetail = $this->getAuthService()->getStorage()->read();
        echo '<pre>';print_r($logDetail);echo '</pre>';die;*/
        
        $controllerName =$this->params('controller');
        $controllerName  = strtolower(str_replace('\\','',strrchr($controllerName, '\\')));
        
        
        if (!$this->getAuthService()->hasIdentity() && $controllerName != 'login') {
            return $this->redirect()->toRoute('admin/child', array('controller'=>'login','action' => 'index'));
        }
        return parent::onDispatch($e);
    }
    
    public function sendMail($subject,$body_text,$mailAddress,$fromName='Pelara',$fromEmail='info@Pelara.com')
    {
        $config = $this->getServiceLocator()->get('Config');		
		$smtpDetail = $config['smtp_detail'];
        try {
            $message = new Message();
            $message->addTo($mailAddress)
                    ->addFrom($fromEmail,$fromName)
                    ->setSubject($subject);
            // Setup SMTP transport using LOGIN authentication
            $transport = new SmtpTransport();
            $options = new SmtpOptions(array(
                            'host' => $smtpDetail['host'],
                            'connection_class' => 'login',
                            'connection_config' => array(
                                'ssl' => $smtpDetail['ssl'],
                                'username' => $smtpDetail['user_name'],
                                'password' => $smtpDetail['password']
                            ),
                            'port' => $smtpDetail['port'],
                        )
                    );
             
            $html = new MimePart($body_text);
            $html->type = "text/html";
             
            $body = new MimeMessage();
            $body->addPart($html);
             
            $message->setBody($body);
             
            $transport->setOptions($options);
            $transport->send($message);
        }
        catch(Exception $e) {}
    }
    
    protected function getExtension($str) {
		$i = strrpos($str,".");
		if (!$i) { return ""; } 
		$l = strlen($str) - $i;
		$ext = substr($str,$i+1,$l);
		return strtolower($ext);
	}
    
    public function getLookupStatusTable()
    {
         if (!$this->LookupStatusTable) {
             $sm = $this->getServiceLocator();
             $this->LookupStatusTable = $sm->get('Admin\Model\LookupStatusTable');
         }
         return $this->LookupStatusTable;
    }
    public function getUserTable() {
        if (!$this->userTable) {
            $sm = $this->getServiceLocator();
            $this->userTable = $sm->get('Admin\Model\UserTable');
        }
        return $this->userTable;
    }
    
    public function getUserContactTable()
    {
         if (!$this->UserContactTable) {
             $sm = $this->getServiceLocator();
             $this->UserContactTable = $sm->get('Admin\Model\UserContactTable');
         }
         return $this->UserContactTable;
    }
    public function getUserContactDetailTable()
    {
         if (!$this->UserContactDetail) {
             $sm = $this->getServiceLocator();
             $this->UserContactDetail = $sm->get('Admin\Model\UserContactDetailTable');
         }
         return $this->UserContactDetail;
    }
    public function getUserAddressTable()
    {
         if (!$this->UserAddressTable) {
             $sm = $this->getServiceLocator();
             $this->UserAddressTable = $sm->get('Admin\Model\UserAddressTable');
         }
         return $this->UserAddressTable;
    }
    public function getUserInterestTable()
    {
         if (!$this->UserInterestTable) {
             $sm = $this->getServiceLocator();
             $this->UserInterestTable = $sm->get('Admin\Model\UserInterestTable');
         }
         return $this->UserInterestTable;
    }
    
    public function getCountryTable()
    {
         if (!$this->countryTable) {
             $sm = $this->getServiceLocator();
             $this->countryTable = $sm->get('Admin\Model\CountryTable');
         }
         return $this->countryTable;
    }
   
    public function getStateTable() {
        if (!$this->stateTable) {
            $sm = $this->getServiceLocator();
            $this->stateTable = $sm->get('Admin\Model\StateTable');
        }
        return $this->stateTable;
    }
    public function getProjectImageTable() {
        if (!$this->ProjectImageTable) {
            $sm = $this->getServiceLocator();
            $this->ProjectImageTable = $sm->get('Admin\Model\ProjectImageTable');
        }
        return $this->ProjectImageTable;
    }
    
    public function getProfilePicTable() {
        if (!$this->ProfilePicTable) {
            $sm = $this->getServiceLocator();
            $this->ProfilePicTable = $sm->get('Admin\Model\ProfilePicTable');
        }
        return $this->ProfilePicTable;
    }
    
    public function getProjectTable()
    {
         if (!$this->ProjectTable) {
             $sm = $this->getServiceLocator();
             $this->ProjectTable = $sm->get('Admin\Model\ProjectTable');
         }
         return $this->ProjectTable;
    }
    public function getProjectViewedTable()
    {
         if (!$this->ProjectViewedTable) {
             $sm = $this->getServiceLocator();
             $this->ProjectViewedTable = $sm->get('Admin\Model\projectViewRequestTable');
         }
         return $this->ProjectViewedTable;
    }
    
    public function getChatTable()
    {
         if (!$this->ChatTable) {
             $sm = $this->getServiceLocator();             
             $this->ChatTable = $sm->get('Admin\Model\ChatTable');
         }
         return $this->ChatTable;
    }
    public function getChatUserTable()
    {
         if (!$this->ChatUserTable) {
             $sm = $this->getServiceLocator();             
             $this->ChatUserTable = $sm->get('Admin\Model\ChatUserTable');
         }
         return $this->ChatUserTable;
    }
    public function getMessageReceiverTable()
    {
         if (!$this->MessageReceiverTable) {
             $sm = $this->getServiceLocator();             
             $this->MessageReceiverTable = $sm->get('Admin\Model\MessageReceiverTable');
         }
         return $this->MessageReceiverTable;
    }
    public function getMessageTable()
    {
         if (!$this->MessageTable) {
             $sm = $this->getServiceLocator();             
             $this->MessageTable = $sm->get('Admin\Model\MessageTable');
         }
         return $this->MessageTable;
    }
    public function getGeoLocationTable()
    {
        if (!$this->GeoLocationTable) {
             $sm = $this->getServiceLocator();
             $this->GeoLocationTable = $sm->get('Admin\Model\GeoLocationTable');
         }
         return $this->GeoLocationTable;
    }
    public function getPrivacySettingTable()
    {
        if (!$this->PrivacySettingTable) {
             $sm = $this->getServiceLocator();
             $this->PrivacySettingTable = $sm->get('Admin\Model\PrivacySettingTable');
         }
         return $this->PrivacySettingTable;
    }
    public function getContactPrivacySettingTable()
    {
        if (!$this->ContactPrivacySettingTable) {
             $sm = $this->getServiceLocator();
             $this->ContactPrivacySettingTable = $sm->get('Admin\Model\ContactPrivacySettingTable');
         }
         return $this->ContactPrivacySettingTable;
    }
    
    
}
