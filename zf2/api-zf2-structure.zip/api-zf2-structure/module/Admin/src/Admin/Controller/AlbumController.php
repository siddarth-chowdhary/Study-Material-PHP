<?php
namespace Admin\Controller;

use Admin\Controller\PController;
use Zend\View\Model\ViewModel;
use Admin\Model\Album;
use Admin\Form\AlbumForm;

class AlbumController extends PController
{
    protected $albumTable;

    public function indexAction()
    {
        /*$configVars = $this->getServiceLocator()->get('Config');
        echo '<pre>';print_r($configVars);die;*/
        
         // grab the paginator from the AlbumTable
        $paginator = $this->getAlbumTable()->fetchAll(true);
        // set the current page to what has been passed in query string, or to 1 if none set
        $paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
        // set the number of items per page to 10
        $paginator->setItemCountPerPage(10);

        return new ViewModel(
            array(
                'paginator' => $paginator
            )
        );
    }
    public function getAlbumTable()
    {
         if (!$this->albumTable) {
             $sm = $this->getServiceLocator();
             $this->albumTable = $sm->get('Admin\Model\AlbumTable');
         }
         return $this->albumTable;
    }
    
    public function addAction()
    {
         $form = new AlbumForm();
         $form->get('submit')->setValue('Add');

         $request = $this->getRequest();
         if ($request->isPost()) {
             $album = new Album();
             $form->setInputFilter($album->getInputFilter());
             $form->setData($request->getPost());

             if ($form->isValid()) {
                 $album->exchangeArray($form->getData());
                 $this->getAlbumTable()->saveAlbum($album);

                 // Redirect to list of albums
                 return $this->redirect()->toRoute('admin/child',array('controller'=>'album','action'=>'index'));
             }
         }
         return array('form' => $form);
     }
    public function editAction()
     {
         $id = (int) $this->params()->fromRoute('id', 0);
         if (!$id) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'album'
                 ,'action' => 'add'
             ));
         }

         // Get the Album with the specified id.  An exception is thrown
         // if it cannot be found, in which case go to the index page.
         try {
             $album = $this->getAlbumTable()->getAlbum($id);
         }
         catch (\Exception $ex) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'album'
                 ,'action' => 'index'
             ));
         }

         $form  = new AlbumForm();
         $form->bind($album);
         $form->get('submit')->setAttribute('value', 'Edit');

         $request = $this->getRequest();
         if ($request->isPost()) {
             $form->setInputFilter($album->getInputFilter());
             $form->setData($request->getPost());

             if ($form->isValid()) {
                 $this->getAlbumTable()->saveAlbum($album);

                 // Redirect to list of albums
                 return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'album'
                 ,'action' => 'index'
             ));
             }
         }

         $view = new ViewModel(array(
             'id' => $id,
             'form' => $form,
         ));
         //$view->setTemplate('admin/index/add.phtml');
         return $view;
     }
     public function deleteAction()
     {
         $id = (int) $this->params()->fromRoute('id', 0);
         
         if (!$id) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'album'
                 ,'action' => 'index'
             ));
         }
         
        $this->getAlbumTable()->deleteAlbum($id);
        // Redirect to list of albums
        
        return $this->redirect()->toRoute('admin/child', array(
         'controller' => 'album'
         ,'action' => 'index'
        ));
        /*if ($request->isPost()) {
             $del = $request->getPost('del', 'No');

             if ($del == 'Yes') {
                 $id = (int) $request->getPost('id');
                 $this->getAlbumTable()->deleteAlbum($id);
             }

             // Redirect to list of albums
             return $this->redirect()->toRoute('admin', array(
                 'controller' => 'index'
                 ,'action' => 'index'
             ));
         }
        
         return array(
             'id'    => $id,
             'album' => $this->getAlbumTable()->getAlbum($id)
         );
         */
     }
}
