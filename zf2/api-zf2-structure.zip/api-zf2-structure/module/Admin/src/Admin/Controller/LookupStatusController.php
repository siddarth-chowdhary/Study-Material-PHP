<?php
namespace Admin\Controller;
use Admin\Controller\PController;
use Zend\View\Model\ViewModel;
use Admin\Model\LookupStatus;
use Admin\Form\LookupStatusForm;

class LookupStatusController extends PController
{
    public function indexAction()
    {
        /*$configVars = $this->getServiceLocator()->get('Config');
        echo '<pre>';print_r($configVars);die;*/
        
         // grab the paginator from the AlbumTable
        $paginator = $this->getLookupStatusTable()->fetchAll(true);
        // set the current page to what has been passed in query string, or to 1 if none set
        $paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
        // set the number of items per page to 10
        $paginator->setItemCountPerPage(10);

        return new ViewModel(
            array(
                'paginator' => $paginator
            )
        );
    }
    
    public function addAction()
    {
         $form = new LookupStatusForm();
         $form->get('submit')->setValue('Add');
		 $isLookupStatusAvailable = true;
		 $errorMessage = "";
		 $message = "";
         $request = $this->getRequest();
         if ($request->isPost()) {
             $LookupStatus = new LookupStatus();
             $data = $request->getPost()->toArray();
             if(!empty($data['statusCode'])){			
				if($this->getLookupStatusTable()->getLookupStatusBystatusCode($data['statusCode'])) {
							
						$isLookupStatusAvailable = false;
						$errorMessage = "Status Code exist use another";
				}
			}
            $form->setInputFilter($LookupStatus->getInputFilter());
            $form->setData($request->getPost());
			if($isLookupStatusAvailable){
				if ($form->isValid()) {
					 $LookupStatus->exchangeArray($form->getData());
					 $this->getLookupStatusTable()->saveLookupStatus($LookupStatus);
					 $message = "Status Created";
					 $this->flashmessenger()->addMessage($message);
					 // Redirect to list of albums
					 return $this->redirect()->toRoute('admin/child',array('controller'=>'lookupStatus','action'=>'index'));
				}
		   } else {
			   $errorMessage = "Status Code exist use another";
		   }
         }
         return array('form' => $form,'errorMessage'=>$errorMessage);
     }
    public function editAction()
     {
		
         $LookupStatusId = (int) $this->params()->fromRoute('id', 0);
         if (!$LookupStatusId) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'lookupStatus'
                 ,'action' => 'add'
             ));
         }
		 $isLookupStatusAvailable = true;
		 $errorMessage = "";
		 $message = "";
         // Get the Album with the specified id.  An exception is thrown
         // if it cannot be found, in which case go to the index page.
         try {
             $LookupStatus = $this->getLookupStatusTable()->getLookupStatus($LookupStatusId);
         }
         catch (\Exception $ex) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'lookupStatus'
                 ,'action' => 'index'
             ));
         }

         $form  = new LookupStatusForm();
         $form->bind($LookupStatus);
         $form->get('submit')->setAttribute('value', 'Update');

         $request = $this->getRequest();
         
         if ($request->isPost()) {
			
             $form->setInputFilter($LookupStatus->getInputFilter());
             $form->setData($request->getPost());
			 $data = $request->getPost()->toArray();
             if(!empty($data['statusCode'])){			
				if($this->getLookupStatusTable()->getLookupStatusBystatusCode($data['statusCode'],$LookupStatusId)) {
							
						$isLookupStatusAvailable = false;
						$errorMessage = "Status Code exist use another";
				}
			}
			if($isLookupStatusAvailable){
				if ($form->isValid()) {
					$this->getLookupStatusTable()->saveLookupStatus($LookupStatus);
					$message = "Status Updated";
					$this->flashmessenger()->addMessage($message);
					 // Redirect to list of albums
					return $this->redirect()->toRoute('admin/child', array(
					 'controller' => 'lookupStatus'
					 ,'action' => 'index'
					));
				}
			} else {
			   $errorMessage = "Status Code	 exist use another";
		    }
         }
         $view = new ViewModel(array(
             'id' => $LookupStatusId,
             'form' => $form,
             'errorMessage'=>$errorMessage,
         ));
         $view->setTemplate('admin/lookup-status/add.phtml');
         return $view;
     }
     public function deleteAction()
     {
         $LookupStatusId = (int) $this->params()->fromRoute('id', 0);
         
         if (!$LookupStatusId) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'lookupStatus'
                 ,'action' => 'index'
             ));
         }
         
        $this->getLookupStatusTable()->deleteLookupStatus($LookupStatusId);
        // Redirect to list of albums
        
        return $this->redirect()->toRoute('admin/child', array(
         'controller' => 'lookupStatus'
         ,'action' => 'index'
        ));
        
     }
}
