<?php

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Admin\Model\Album;
use Admin\Model\GeoLocation;
use Admin\Form\AlbumForm;
use Admin\Form\GeoLocationForm;

class IndexController extends PController {

    protected $albumTable;

    public function indexAction() {
        $request = $this->getRequest();
        $search = $request->getPost()->toArray(); //print_r($data);exit;
        $formData = $request->getPost()->toArray(); //print_r($data);exit;       
        // grab the paginator from the user        
        //$paginator = $this->getGeoLocationTable()->fetchAll(true, $search);
        // set the current page to what has been passed in query string, or to 1 if none set        
        $markers = $infowindowVal = array();
        /*

          foreach ($paginator as $key => $val) {
          $keys = $val['firstName'] . ' ' . $val['lastName'] . ' ' . $val['stateName'] . ' ' . $val['countryName'];
          $markers[$keys] = $val['latitude'] . ',' . $val['longitude'];
          $infowindowVal[]=array('firstName'=>$val['firstName'],'lastName'=>$val['lastName'],'address'=>$val['address'],'myLatlngt'=>$val['latitude'] . ',' . $val['longitude']);
          } */
        //echo "<pre>";print_r($markers);exit;
        $uri = $this->getRequest()->getUri();
        $base = sprintf('%s://%s', $uri->getScheme(), $uri->getHost());
        if ($base == 'http://ventureapp.local' || $base == 'http://ventureapp.in') {
            $latitude = 28.500436;
            $longtitude = 77.086665;
            $imgPath = '/img/zf2-logo.png';
        } else {
            $latitude = $this->getLatLongVal()['lat'][0];
            $longtitude = $this->getLatLongVal()['long'][0];
            $imgPath = '/ventureapp/public/img/zf2-logo.png';
        }
        $form = new GeoLocationForm();
        $form->get('submit')->setValue('Get User Location');

        $latitude1 = $latitude;
        $longitude1 = $longtitude;

        $configVars = $this->getServiceLocator()->get('Config');
        $kmToMileDiff = $configVars['km_to_mile_difference'];
        $defaultMapSearchDistance = $configVars['default_map_search_distance'];
        if(isset($formData['searchItem']) && $formData['searchItem']!=''){
        $formData['search_txt'] = $formData['searchItem'];
        }
        
        $searchDistance = !empty($formData['distance']) ? $formData['distance'] : 5;


        $searchDistance = $searchDistance * $kmToMileDiff;
        //$searchDistance = $kmToMileDiff;
        //echo $searchDistance;exit;
        $userArr = array();
        $i = 0;

        $searchUser = $this->getUserTable()->searchLocationUser($formData);
        $actionHelper = $this->getServiceLocator()->get('Admin\Service\ActionHelper');
        foreach ($searchUser as $key => $user) {
            $latitude2 = $user->latitude;
            $longitude2 = $user->longitude;
            $distance = $actionHelper->greatCircleDistance($latitude1, $longitude1, $latitude2, $longitude2);

            if ($distance <= $searchDistance) {
                $keys = $user['firstName'] . ' ' . $user['lastName'] . ' ' . $user['stateName'] . ' ' . $user['countryName'];
                $markers[$keys] = $user['latitude'] . ',' . $user['longitude'];
                $infowindowVal[] = array('firstName' => $user['firstName'], 'lastName' => $user['lastName'], 'address' => $user['address'], 'myLatlngt' => $user['latitude'] . ',' . $user['longitude']);
                $user['distance']=  floor($distance/$kmToMileDiff);
                  $userArr[] = (array) $user;
                  /* $userArr[$i]['distance'] =  floor($distance/$kmToMileDiff);
                  $i++;
                 */
            }
        }
        

       //echo "<pre>";print_r($userArr);exit;

        /* $markers = array(
          'Mozzat Web Team' => '17.516684,79.961589'
          , 'Home Town' => '16.916684,80.683594'
          , 'Home Town' => '15.916684,80.683594'
          , 'Home Town palace' => '20.916684,80.683594'
          );  //markers location with latitude and longitude
         */
        $config = array(
            'sensor' => 'true'         //true or false
            , 'panControl' => 'true'         //true or false
            , 'streetViewControl' => 'true'         //true or false
            , 'div_id' => 'map-canvas'          //div id of the google map
            , 'div_class' => 'span6'    //div class of the google map
            , 'zoom' => 4                //zoom level
            , 'width' => "auto"         //width of the div
            , 'height' => "300px"        //height of the div
            //, 'lat' => 16.916684         //lattitude => center latitude
            //, 'lon' => 80.683594         //longitude => center longitude
            , 'lat' => $latitude        //lattitude => center latitude
            , 'lon' => $longtitude       //longitude => center longitude
            , 'centereMarkerImage' => $imgPath      //Center marker Image
            , 'animation' => 'none'      //animation of the marker
            , 'markers' => $markers       //loading the array of markers
            , 'infowindowVal' => $infowindowVal
            , 'center_changed' => 'false'       //loading the array of markers
            , 'user_name' => 'Rajeev Kumar singh'       //set name of current user
            , 'mapTypeControlOptions' => array('style' => 'google.maps.MapTypeControlStyle.DROPDOWN_MENU', 'position' => 'google.maps.ControlPosition.TOP_RIGHT')
        );

        $map = $this->getServiceLocator()->get('Admin\Service\GoogleMap'); //getting the google map object using service manager
        $map->initialize($config);                                         //loading the config   
        $html = $map->generate();                                         //genrating the html map content  
        
        return new ViewModel(array('map_html' => $html, 'form' => $form, 'search' => $search,'searchUsers'=>$userArr));
    }

    public function getAlbumTable() {
        if (!$this->albumTable) {
            $sm = $this->getServiceLocator();
            $this->albumTable = $sm->get('Admin\Model\AlbumTable');
        }
        return $this->albumTable;
    }

    public function addAction() {
        $form = new AlbumForm();
        $form->get('submit')->setValue('Add');

        $request = $this->getRequest();
        if ($request->isPost()) {
            $album = new Album();
            $form->setInputFilter($album->getInputFilter());
            $form->setData($request->getPost());

            if ($form->isValid()) {
                $album->exchangeArray($form->getData());
                $this->getAlbumTable()->saveAlbum($album);

                // Redirect to list of albums
                return $this->redirect()->toRoute('admin', array('controller' => 'index', 'action' => 'index'));
            }
        }
        return array('form' => $form);
    }

    public function editAction() {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute('admin', array(
                        'controller' => 'index'
                        , 'action' => 'add'
            ));
        }

        // Get the Album with the specified id.  An exception is thrown
        // if it cannot be found, in which case go to the index page.
        try {
            $album = $this->getAlbumTable()->getAlbum($id);
        } catch (\Exception $ex) {
            return $this->redirect()->toRoute('admin', array(
                        'controller' => 'index'
                        , 'action' => 'index'
            ));
        }

        $form = new AlbumForm();
        $form->bind($album);
        $form->get('submit')->setAttribute('value', 'Edit');

        $request = $this->getRequest();
        if ($request->isPost()) {
            $form->setInputFilter($album->getInputFilter());
            $form->setData($request->getPost());

            if ($form->isValid()) {
                $this->getAlbumTable()->saveAlbum($album);

                // Redirect to list of albums
                return $this->redirect()->toRoute('admin', array(
                            'controller' => 'index'
                            , 'action' => 'index'
                ));
            }
        }

        $view = new ViewModel(array(
            'id' => $id,
            'form' => $form,
        ));
        //$view->setTemplate('admin/index/add.phtml');
        return $view;
    }

    public function deleteAction() {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute('admin', array(
                        'controller' => 'index'
                        , 'action' => 'index'
            ));
        }

        $request = $this->getRequest();
        $id = (int) $request->getPost('id');
        $this->getAlbumTable()->deleteAlbum($id);
        // Redirect to list of albums
        return $this->redirect()->toRoute('admin', array(
                    'controller' => 'index'
                    , 'action' => 'index'
        ));
        /* if ($request->isPost()) {
          $del = $request->getPost('del', 'No');

          if ($del == 'Yes') {
          $id = (int) $request->getPost('id');
          $this->getAlbumTable()->deleteAlbum($id);
          }

          // Redirect to list of albums
          return $this->redirect()->toRoute('admin', array(
          'controller' => 'index'
          ,'action' => 'index'
          ));
          }

          return array(
          'id'    => $id,
          'album' => $this->getAlbumTable()->getAlbum($id)
          );
         */
    }

    /**
     * Constructor to initialise the database connnection 
     * Make sure the getting the instance of the right database  
     * */
    public function getIpAddr() {

        //$xml = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=" . $this->getRealIpAddr());        
        $url = "http://www.geoplugin.net/xml.gp?ip=" . $this->getRealIpAddr();
        $cresponse = $this->curlCall($url);
        //var_dump($cresponse);die;
        @$xml = @simplexml_load_string($cresponse);
        return @$xml;
    }

    function getRealIpAddr() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {   //check ip from share internet
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {   //to check ip is pass from proxy
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        //$ip='182.71.165.218';//India
        //$ip='5.9.173.231';//Germany

        return $ip;
    }

    public function curlCall($url) {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//  curl_setopt($ch,CURLOPT_HEADER, false);

        $output = curl_exec($ch);

        curl_close($ch);
        return $output;
    }

    public function getLatLongVal() {
        $getIpaddr = $this->getIpAddr();
        $val = array("status" => "success", "lat" => $getIpaddr->geoplugin_latitude, "long" => $getIpaddr->geoplugin_longitude);
        return $val;
    }

}
