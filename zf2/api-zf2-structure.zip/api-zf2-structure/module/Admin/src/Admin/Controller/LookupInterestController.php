<?php
namespace Admin\Controller;
use Admin\Controller\PController;
use Zend\View\Model\ViewModel;
use Admin\Model\LookupInterest;
use Admin\Form\LookupInterestForm;

class LookupInterestController extends PController
{
    protected $LookupInterestTable;

    public function indexAction()
    {
        /*$configVars = $this->getServiceLocator()->get('Config');
        echo '<pre>';print_r($configVars);die;*/
        
         // grab the paginator from the AlbumTable
        $paginator = $this->getLookupInterestTable()->fetchAll(true);
        // set the current page to what has been passed in query string, or to 1 if none set
        $paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
        // set the number of items per page to 10
        $paginator->setItemCountPerPage(10);

        return new ViewModel(
            array(
                'paginator' => $paginator
            )
        );
    }
    public function getLookupInterestTable()
    {
         if (!$this->LookupInterestTable) {
             $sm = $this->getServiceLocator();
             $this->LookupInterestTable = $sm->get('Admin\Model\LookupInterestTable');
         }
         return $this->LookupInterestTable;
    }
    
    public function addAction()
    {
         $form = new LookupInterestForm();
         $form->get('submit')->setValue('Add');
		 $isLookupInterestAvailable = true;
		 $errorMessage = "";
		 $message = "";
         $request = $this->getRequest();
         if ($request->isPost()) {
             $LookupInterest = new LookupInterest();
             $data = $request->getPost()->toArray();
             if(!empty($data['interest'])){			
				if($this->getLookupInterestTable()->getLookupInterestByInterest($data['interest'])) {
							
						$isLookupInterestAvailable = false;
						$errorMessage = "Interest exist use another";
				}
			}
            $form->setInputFilter($LookupInterest->getInputFilter());
            $form->setData($request->getPost());
			if($isLookupInterestAvailable){
				if ($form->isValid()) {
					 $LookupInterest->exchangeArray($form->getData());
					 $this->getLookupInterestTable()->saveLookupInterest($LookupInterest);
					 $message = "Interest Created";
					 $this->flashmessenger()->addMessage($message);
					 // Redirect to list of albums
					 return $this->redirect()->toRoute('admin/child',array('controller'=>'lookupInterest','action'=>'index'));
				}
		   } else {
			   $errorMessage = "Interest exist use another";
		   }
         }
         return array('form' => $form,'errorMessage'=>$errorMessage);
     }
    public function editAction()
     {
		
         $LookupInterestId = (int) $this->params()->fromRoute('id', 0);
         if (!$LookupInterestId) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'lookupInterest'
                 ,'action' => 'add'
             ));
         }
		 $isLookupInterestAvailable = true;
		 $errorMessage = "";
		 $message = "";
         // Get the Album with the specified id.  An exception is thrown
         // if it cannot be found, in which case go to the index page.
         try {
             $LookupInterest = $this->getLookupInterestTable()->getLookupInterest($LookupInterestId);
         }
         catch (\Exception $ex) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'lookupInterest'
                 ,'action' => 'index'
             ));
         }

         $form  = new LookupInterestForm();
         $form->bind($LookupInterest);
         $form->get('submit')->setAttribute('value', 'Update');

         $request = $this->getRequest();
         
         if ($request->isPost()) {
			
             $form->setInputFilter($LookupInterest->getInputFilter());
             $form->setData($request->getPost());
			 $data = $request->getPost()->toArray();
             if(!empty($data['interest'])){			
				if($this->getLookupInterestTable()->getLookupInterestByInterest($data['interest'],$LookupInterestId)) {
							
						$isLookupInterestAvailable = false;
						$errorMessage = "Interest exist use another";
				}
			}
			if($isLookupInterestAvailable){
				if ($form->isValid()) {
					$this->getLookupInterestTable()->saveLookupInterest($LookupInterest);
					$message = "Interest Updated";
					$this->flashmessenger()->addMessage($message);
					 // Redirect to list of albums
					return $this->redirect()->toRoute('admin/child', array(
					 'controller' => 'lookupInterest'
					 ,'action' => 'index'
					));
				}
			} else {
			   $errorMessage = "Interest exist use another";
		    }
         }
         $viewModel = new ViewModel(array(
             'id' => $LookupInterestId,
             'form' => $form,
             'errorMessage'=>$errorMessage,
         ));
         $viewModel->setTemplate('admin/lookup-interest/add.phtml');
         return $viewModel;
     }
     public function deleteAction()
     {
         $LookupInterestId = (int) $this->params()->fromRoute('id', 0);
         
         if (!$LookupInterestId) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'lookupInterest'
                 ,'action' => 'index'
             ));
         }
         
        $this->getLookupInterestTable()->deleteLookupInterest($LookupInterestId);
        // Redirect to list of albums
        
        return $this->redirect()->toRoute('admin/child', array(
         'controller' => 'lookupInterest'
         ,'action' => 'index'
        ));
        
     }
}
