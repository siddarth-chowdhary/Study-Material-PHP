<?php
namespace Admin\Controller;

use Admin\Controller\PController;
use Zend\View\Model\ViewModel;
use Admin\Model\UserContact;
use Admin\Model\UserContactDetail;
use Admin\Form\UserContactForm;

class UserContactController extends PController
{
    public function indexAction()
    {
        $userStatusArray =$userContactArray=$formData=$receiverIdData= array();
        $contactCount = 1;
        $userId = (int) $this->params()->fromRoute('id', 0);
        if (!$userId) {
            return $this->redirect()->toRoute('admin/child', array(
                'controller' => 'user'
                ,'action' => 'index'
            ));
        }
        
        //$statusArr = $this->getLookupStatusTable()->fetchAll(false, array('statusId'=>array(1,2)));
        $statusArr = $this->getLookupStatusTable()->fetchAll(false, array());
        foreach ($statusArr as $statusArrKey => $statusArrVal) {        
            $userStatusArray[$statusArrVal->statusId] = $statusArrVal->statusCode;
        }
        //Get user contact list
        $userContactListData = $this->getUserContactTable()->fetchAll(true, array('senderId'=>$userId));
        foreach($userContactListData as $userContactListDataKey=>$userContactListDataVal){
            $receiverIdData[]=$userContactListDataVal['receiverId'];
        }
        //echo "<pre>"; print_r($receiverIdData);exit;
       
        
        $contactArr=$this->getUserTable()->getUserList(array('statusId'=>1,'userType'=>2,'notequalto'=>array('userId'=>$userId),'excludeUser'=>true));
        foreach ($contactArr as $contactArrKey => $contactArrVal) {//echo "<pre>";print_r($contactArrVal);exit;            
            if($contactArrVal->firstName!='' || $contactArrVal->lastName!=''){
            $userContactArray[$contactArrVal->userId] = $contactArrVal->firstName.' '.$contactArrVal->lastName;
            }else{
                $userContactArray[$contactArrVal->userId] = $contactArrVal->phone;
            }
        }
        /*echo "<pre>";
        print_r($userContactArray);exit;*/
        
        $request = $this->getRequest();
        /*if ($request->isPost()) {
            $data = $request->getPost()->toArray();
            $contactCount = $data['number_count'];
        }*/
        
        $form = new UserContactForm($userStatusArray,$contactCount,'',$userContactArray);
        
        $userContact = new UserContact();
        $form->setInputFilter($userContact->getInputFilter($contactCount));
        $form->get('submit')->setValue('Add');
        $form->get('senderId')->setValue($userId);
        
        if ($request->isPost()) {
            //$data = $request->getPost()->toArray();
            
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $data = $form->getData();
                $userContact->exchangeArray($data);
                $dateObj = new \DateTime('NOW');
                if(is_array($data['receiverId'])){
                    foreach($data['receiverId'] as $key=>$val){
                        $formData[]=array('contactId'=>$data['contactId'],'senderId'=>$data['senderId'],
                        'receiverId'=>$val,'statusId'=>8,
                        'createdDate'=>$dateObj->format('Y-m-d H:i:s'),'updatedDate'=>$dateObj->format('Y-m-d H:i:s'));         
                    }
                }
                //echo "<pre>";print_r($formData);exit;
                 $this->getUserContactTable()->saveMultipleContact('userContact',$formData);
                //$this->getUserContactTable()->saveUserContact($userContact);
                //$lastInsertedId = $this->getUserContactTable()->lastInsertedValue();
                //$data['contactId'] = $lastInsertedId;
                //$this->updateUserContactDetail($data);
                $message = "Contact Added";
                $this->flashmessenger()->addMessage($message);
                // Redirect to list of albums
                return $this->redirect()->toRoute('admin/child',array('controller'=>'user','action'=>'contacts','id'=>$userId));
            }
            
        }
        return new ViewModel(
            array(
                'form' => $form
                ,'count_number' => $contactCount
            )
        );
    }
    
    public function editAction()
    {
		$contact_id = (int) $this->params()->fromRoute('id', 0);
        if (!$contact_id) {
            return $this->redirect()->toRoute('admin/child', array(
                'controller' => 'user'
                ,'action' => 'index'
            ));
        }
        
        $errorMessage = $userStatusArray = "";
		$message = "";
        try {
            $userContact = $this->getUserContactTable()->getUserContact($contact_id);
        }
        catch (\Exception $ex) {
            $this->flashmessenger()->addMessage('Selected contact not exist.');
            return $this->redirect()->toRoute('admin/child', array(
                'controller' => 'user'
                ,'action' => 'index'
            ));
        }
        #echo '<pre>';print_r($userContact);die;
        $userSavedContactArr = $this->getUserContactDetailTable()->getUserContactDetail($contact_id);
        $i=1;
        foreach($userSavedContactArr as $key=>$number) {
            #echo '<pre>';print_r($number);die;
            $column = "contactNumber-{$i}";
            $userContact->$column = $number->contactNumber;
            $i++;
        }
        $contactCount = ($i >1) ? $i-1 : 1;
        //echo $contactCount;
        //echo '<pre>';var_export($userContact);die;
        
        $statusArr = $this->getLookupStatusTable()->fetchAll(false, array('statusId'=>array(1,2)));
        foreach ($statusArr as $statusArrKey => $statusArrVal) {            
            $userStatusArray[$statusArrVal->statusId] = $statusArrVal->statusCode;
        }
        
         $request = $this->getRequest();
        if ($request->isPost()) {
            $data = $request->getPost()->toArray();
            $contactCount = $data['number_count'];
        }
        
        $form = new UserContactForm($userStatusArray,$contactCount);
         $form->setInputFilter($userContact->getInputFilter($contactCount));
         $form->bind($userContact);
         $form->get('submit')->setAttribute('value', 'Update');
         $request = $this->getRequest();
         
         if ($request->isPost()) {
			$data = $request->getPost()->toArray();
            
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $userContact->exchangeArray($data);
                
                $this->getUserContactTable()->saveUserContact($userContact);
                //$data['contactId'] = $lastInsertedId;
               // $this->updateUserContactDetail($data);
                $message = "Contact Added";
                $this->flashmessenger()->addMessage($message);
                return $this->redirect()->toRoute('admin/child',array('controller'=>'user','action'=>'contacts','id'=>$userContact->userId));
            }
         }
         $viewModel = new ViewModel(array(
             'form' => $form
             ,'errorMessage'=>$errorMessage
             ,'count_number' => $contactCount
         ));
         $viewModel->setTemplate('admin/user-contact/index.phtml');
         return $viewModel;
     }
     
     
     protected function updateUserContactDetail($data) {
        if(!empty($data['number_count'])) {
            $contDetailData = array();
            $checkNumber = array();
            for($i=1;$i<=$data['number_count'];$i++) {
                if(empty($data['contactNumber-'.$i]))
                    continue;
                $cNumber = str_replace(array('(',')',' ','-'),'',$data['contactNumber-'.$i]);
                
                if(!isset($checkNumber[$cNumber])) {
                    $checkNumber[$cNumber] = '';
                    $contDetailData[] = array(
                                        'contactId'=>$data['contactId']
                                        ,'contactNumber'=>$cNumber
                                        ,'defaultContact'=>0
                                    );
                }
                /*$userContactDetail = new UserContactDetail();
                $userContactDetail->exchangeArray($contDetailData);*/
            }
            try {
                $this->getUserContactDetailTable()->saveUserContactDetail($contDetailData,$data['contactId']);
            }
            catch(\Exception $e){}
        }
    }
     
     public function deleteAction()
     {
         $userId = (int) $this->params()->fromRoute('id', 0);
         $cid = (int) $this->params()->fromQuery('cid',0);
         if (!$userId) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'user'
                 ,'action' => 'index'
             ));
         }
         if (!$cid) {
             return $this->redirect()->toRoute('admin/child', array(
                 'controller' => 'user'
                 ,'action' => 'contacts'
                 ,'id' => $userId
             ));
         }
         
        $this->getUserContactTable()->delete($cid);
        //$this->getUserContactDetailTable()->delete($cid);
        // Redirect to list of albums
        
        return $this->redirect()->toRoute('admin/child', array(
         'controller' => 'user'
         ,'action' => 'contacts'
         ,'id' => $userId
        ));
        
     }
}
