<?php

return array(
    'router' => array(
        'routes' => array(
            'api' => array(
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array(
                    'route'    => '/api',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Api\Controller',
                        'controller' => 'Api\Controller\Index',
                    ),
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'child' => array(
                        'type'    => 'Segment',
                        'options' => array(
                            'route'    => '[/][:controller][/][:id]',
                            'constraints' => array(
                                'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'id'     => '[+a-zA-Z0-9_-]+',
                            ),
                            'defaults' => array(
                                /*'controller' => 'user',
                                'action'     => 'index',*/
                            ),
                        ),
                    ),
                ),
            ),
        ),
    ),
    'controllers' => array(
        'invokables' => array(
            'Api\Controller\Index' => 'Api\Controller\IndexController',
            'Api\Controller\Album' => 'Api\Controller\AlbumController',
            'Api\Controller\Register' => 'Api\Controller\RegisterController',
            'Api\Controller\ResendSecurityCode' => 'Api\Controller\ResendSecurityCodeController',
            'Api\Controller\Verify' => 'Api\Controller\VerifyController',
            'Api\Controller\Login' => 'Api\Controller\LoginController',
            'Api\Controller\UserInterest' => 'Api\Controller\UserInterestController',
            'Api\Controller\ForgotPassword' => 'Api\Controller\ForgotPasswordController',
            'Api\Controller\ResetForgotPassword' => 'Api\Controller\ResetForgotPasswordController',
            'Api\Controller\CountryList' => 'Api\Controller\CountryListController',
            'Api\Controller\PhoneCode' => 'Api\Controller\PhoneCodeController',
            'Api\Controller\Search' => 'Api\Controller\SearchController',
            'Api\Controller\Contact' => 'Api\Controller\ContactController',
            'Api\Controller\Profile' => 'Api\Controller\ProfileController',
            'Api\Controller\FbLogin' => 'Api\Controller\FbLoginController',
            'Api\Controller\Project' => 'Api\Controller\ProjectController',
            'Api\Controller\UserSetting' => 'Api\Controller\UserSettingController',
            'Api\Controller\CheckSecurityCode' => 'Api\Controller\CheckSecurityCodeController',
            'Api\Controller\GetSecurityCodeByPhone' => 'Api\Controller\GetSecurityCodeByPhoneController',
            'Api\Controller\TempProjectPic' => 'Api\Controller\TempProjectPicController',
            'Api\Controller\ProjectRequest' => 'Api\Controller\ProjectRequestController',
            'Api\Controller\PrivacySetting' => 'Api\Controller\PrivacySettingController',
            'Api\Controller\Chat' => 'Api\Controller\ChatController',
            'Api\Controller\ContactPrivacySetting' => 'Api\Controller\ContactPrivacySettingController',
            
        ),
    ),
    'view_manager' => array(
        'strategies' => array(
            'ViewJsonStrategy',
        ),
    ),
);
