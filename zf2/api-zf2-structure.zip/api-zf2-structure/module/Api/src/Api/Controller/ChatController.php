<?php

namespace Api\Controller;

use Zend\View\Model\JsonModel;

class ChatController extends AbstractRestfulJsonController {

    /** (Screen No 22)
     * Action used for POST requests 
     * @url - http://<site-name>/api/chat
     * @param mixed $data Array of values to store data
     * @param $data['user_name']
     * @param $data['password_token']
     * @param $data['request_type']
     * @return {
      status: "success"
      message: {
      0: "success"
      }
      }
     * If everything is Ok ,otherwise appropriate error messages are passed
     */
    public function create($data) {
        $request_type = !empty($data['request_type']) ? $data['request_type'] : '';
        try {
            $userData = $this->getUserTable()->verifyPasswordToken($data);
            $userId = $userData->userId;
            switch ($data['request_type']) {
                case "getRequests": {
                        return $this->getChatRequests($userId);
                        break;
                    }
                default: {
                        return new JsonModel(array('status' => 'error', "message" => (object) array('Request Type ' . $formData['request_type'] . ' does not exist')));
                        break;
                    }
            }
        } catch (\Exception $e) {
            return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
        }
    }

    public function getChatRequests($userId) {
        if (isset($userId)) {
            try {
                $userRequests = '';
                $projectRequests = '';
                $userRequests = $this->getUserContactTable()->getChatRequestsForContact($userId);
                $projectRequests = $this->getProjectViewRequestTable()->getChatRequestsForProjects($userId);
                return new JsonModel(array('status' => 'success', "userRequests" => (object) $userRequests, "projectRequests" => (object) $projectRequests));
            } catch (Exception $e) {
                return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
            }
        } else {
            return new JsonModel(array('status' => 'error', "message" => "Error - Invalid User"));
        }
    }

}
