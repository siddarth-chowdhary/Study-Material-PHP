<?php

namespace Api\Controller;

use Zend\View\Model\JsonModel;
use Admin\Service\FileUpload;
use Api\Form\ProjectRequestForm;
use Admin\Model\ProjectViewCount;
use \Admin\Model\projectViewRequest;

class ProjectRequestController extends AbstractRestfulJsonController {

    /**
     * Action used for POST requests 
     * @url - http://<site-name>/api/project-request
     * @param mixed $data Array of values to store data
     * @param $data['user_name']
     * @param $data['password_token']
     * @param $data['request_type']
     * @param $data['projectId']
     * @param $data['userId']
     * @return {
      status: "success"
      message: {
      0: "success"
      }
      }
     * If everything is Ok ,otherwise appropriate error messages are passed
     */
    public function create($data) { 
        $request_type = !empty($data['request_type']) ? $data['request_type'] : '';
        $form = new ProjectRequestForm();
        $form->setData($data);
        if ($form->isValid()) {
            $formData = $form->getData();

            try {
                $userData = $this->getUserTable()->verifyPasswordToken($formData);
                $userId = $userData->userId;
                switch ($formData['request_type']) {
                    case "sendRequest": {
                            if ($userId != $formData['userId'])
                                return new JsonModel(array('status' => 'error', "message" => (object) array('Invalid User')));
                            $arrValues = array('userData' => $userData, 'formData' => $formData);
                            return $this->sendRequestForProject($arrValues);
                            break;
                        }
                    default: {
                            return new JsonModel(array('status' => 'error', "message" => (object) array('Request Type ' . $formData['request_type'] . ' does not exist')));
                            break;
                        }
                }
            } catch (\Exception $e) {
                return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
            }
        } else {
            return new JsonModel(array('status' => 'error', "message" => $form->getMessages()));
        }
    }

    public function sendRequestForProject($arrValues) {
        $userId = $arrValues['userData']->userId;
        $projectId = $arrValues['formData']['projectId'];
        $dateObj = new \DateTime('NOW');
        $createdDate = $dateObj->format('Y-m-d H:i:s');
        $user = $this->getUserTable()->getUser($userId);
        $statusId = $user->statusId;
        $arrProjectViewCountData = array(
            'projectId' => $projectId,
            'userId' => $userId,
            'createdDate' => $createdDate,
        );
        $arrProjectViewRequestData = array(
            'projectId' => $projectId,
            'userId' => $userId,
            'statusId' => $statusId,
            'createdDate' => $createdDate,
        );
        if (($userId != '') && (!empty($userId)) && ($projectId != '') && (!empty($projectId))) {
            $projectViewCount = new ProjectViewCount();
            $projectViewCount->exchangeArray($arrProjectViewCountData);
            $projectViewRequest = new projectViewRequest();
            $projectViewRequest->exchangeArray($arrProjectViewRequestData);
            try {
                $resultCount = $this->getProjectViewCountTable()->save($projectViewCount);
                $resultView = $this->getProjectViewRequestTable()->save($projectViewRequest);
            } catch (\Exception $e) {
                return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
            }
            if (($resultCount === true) && ($resultView === true)) {
                return new JsonModel(array('status' => 'success', "message" =>'success'));
            } else {
                return new JsonModel(array('status' => 'error', "message" => (object) array('failed')));
            }
        } else {
            return new JsonModel(array('status' => 'error', "message" => (object) array('Invalid UserId or Project Id')));
        }
    }

}
