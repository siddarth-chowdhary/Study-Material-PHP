<?php
namespace Api\Controller;


use Zend\View\Model\JsonModel;


use Api\Form\SearchForm;


class SearchController extends AbstractRestfulJsonController
{
    public function create($data)
    {   // Action used for POST requests
        $form = new SearchForm();
        $form->setData($data);
        if ($form->isValid()) {
            $formData = $form->getData();
            try {
                $userDetail = $this->getUserTable()->verifyPasswordToken($formData);
                $formData['notequalto']['userId'] = $userDetail->userId;
                $latitude1 = $formData['latitude'];
                $longitude1 = $formData['longitude'];
                
                $configVars = $this->getServiceLocator()->get('Config');                
                $profile_image_dir = $configVars['profile_image_dir'];
                $kmToMileDiff = $configVars['km_to_mile_difference'];
                $defaultMapSearchDistance = $configVars['default_map_search_distance'];
                
                $searchDistance = !empty($formData['distance_radius']) ? $formData['distance_radius'] : $defaultMapSearchDistance;
                
                
                $searchDistance = $searchDistance * $kmToMileDiff;
                $userArr = array();
                $i=0;
                
                $searchUser = $this->getUserTable()->searchLocationUser($formData);
                $actionHelper = $this->getServiceLocator()->get('Admin\Service\ActionHelper');
                foreach($searchUser as $key=>$user) {
                    $latitude2 = $user->latitude;
                    $longitude2 = $user->longitude;
                    $distance = $actionHelper->greatCircleDistance($latitude1,$longitude1,$latitude2,$longitude2);
                    if($distance <= $searchDistance) {
                        $userArr[$i] = (array) $user;
                        $projects = array();
                        $projectCount = 0;
                        if($user->hideProject == 0) {
                            try {
                                $projectsArr = $this->getProjectTable()->getProjectByUserId($user->userId);
                                $projectCount = $projectsArr->projectCount;
                                $projects = array(
                                                'projectName'=>$projectsArr->projectName
                                                ,'visibility'=>$projectsArr->statusCode
                                                ,'createdDate'=>$projectsArr->createdDate
                                            );

                            }
                            catch(\Exception $e) {
                                //echo $e->getMessage();
                            }
                        }
                        $userArr[$i]['projectCount'] =  $projectCount;
                        $userArr[$i]['projects'] =  $projects;
                        $userArr[$i]['hideProject'] =  $user->hideProject;
                        $userArr[$i]['distance'] =  floor($distance/$kmToMileDiff);
                        $userIds=$userArr[$i]['userId'];
                        $url='http://'.$configVars['http_host'].'/'.$profile_image_dir.'/'.$userIds.'/thumb_';
                        $userArr[$i]['profilePic']=$url.$userArr[$i]['profilePic'];
                        $i++;
                    }
                }
                
                return new JsonModel(array('status'=>'success',"message" => 'Success','users'=>$userArr));
            }
            catch(\Exception $e) {
                $message = $e->getMessage();
                return new JsonModel(array('status'=>'error',"message" => $message));
            }
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => $form->getMessages()));
        }
    }

    public function update($id, $data)
    {   // Action used for PUT requests
        return 'Hello';
    }
}
