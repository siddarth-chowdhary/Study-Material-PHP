<?php
namespace Api\Controller;

use Zend\View\Model\JsonModel;

use Api\Form\CreateProjectForm;
use Api\Form\ListProjectForm;
use Admin\Model\Project;
use Admin\Model\ProjectImage;
use Admin\Model\TempProjectPic;

class ProjectController extends AbstractRestfulJsonController
{
    public function create($data)
    {   // Action used for POST requests
        if(!empty($data['request_type'])) {
            $request_type = $data['request_type'];
            switch($request_type) {
                case "create":
                    return $this->createProject($data);
                    break;
                case "list":
                    return $this->listProjects($data);
                    break;
                case "search":
                    return $this->searchProjects($data);
                    break;
                default:
                    return new JsonModel(array('status'=>'error',"message" => (object) array('Request Type Not Found')));
            }
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => (object) array('Request Type is required')));
        }
    }
    
    private function searchProjects($data)
    {
        $form = new ListProjectForm();
        $form->setData($data);
        if ($form->isValid()) {
            $formData = $form->getData();
            try {
                 $userDetail = $this->getUserTable()->verifyPasswordToken($formData);
                 $listProjects = array();
                 try {
                     $list = $this->getProjectTable()->searchProject($userDetail->userId);
                     
                     foreach($list as $key=>$project) {
                        if (!($project->hideProject == '2'))
                            $listProjects[] = $project;
                     }
                 }
                 catch(\Exception $e) {
                     die($e->getMessage());
                     }
                
                return new JsonModel(array('status'=>'success',"message" => 'Success','projects'=>$listProjects));
            }
            catch(\Exception $e) {
                $message = $e->getMessage();
                return new JsonModel(array('status'=>'error',"message" => (object) array($message)));
            }
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => $form->getMessages()));
        }
    }
    
    private function listProjects($data)
    {
        $form = new ListProjectForm();
        $form->setData($data);
        if ($form->isValid()) {
            $formData = $form->getData();
            try {
                 $userDetail = $this->getUserTable()->verifyPasswordToken($formData);
                 $list = $this->getProjectTable()->getProjectListOfUser($userDetail->userId);
                 $listProjects = array();
                 foreach($list as $key=>$project) {
                    $listProjects[] = $project;
                 }
                 return new JsonModel(array('status'=>'success',"message" => 'Success','projects'=>$listProjects));
            }
            catch(\Exception $e) {
                $message = $e->getMessage();
                return new JsonModel(array('status'=>'error',"message" => (object) array($message)));
            }
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => $form->getMessages()));
        }
    }
    
    private function createProject($data)
    {
        $form = new CreateProjectForm();
        $form->setData($data);
        if ($form->isValid()) {
            $formData = $form->getData();
            try {
                $userDetail = $this->getUserTable()->verifyPasswordToken($formData);
                $userId = $userDetail->userId;                
                $data = array(
                            'projectName'=>$formData['projectName']
                            ,'projectDetail'=>$formData['projectDetail']
                            ,'lockProjectDetail'=>$formData['lockProjectDetail']
                            ,'visibility'=>$formData['projectVisibility']
                            ,'userId'=>$userId
                            ,'tempProjectId'=>$formData['tempProjectId']
                        );
                $projectProtoType = new Project();
                $projectProtoType->exchangeArray($data);
                try {
                    $this->getProjectTable()->saveProject($projectProtoType);
                    $projectId = $this->getProjectTable()->lastInsertedValue();
                    
                    $this->moveTempProjectPicToProjectImageTable($data['tempProjectId'],$projectId);
                }
                catch(\Admin\Service\MyException $e){
                   // echo $e->getMessage();die;
                }
                return new JsonModel(array('status'=>'success',"message" => 'Success'));
            }
            catch(\Exception $e) {
                $message = $e->getMessage();
                return new JsonModel(array('status'=>'error',"message" => (object) array($message)));
            }
            
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => $form->getMessages()));
        }
    }
    public function moveTempProjectPicToProjectImageTable($tempProjectId,$projectId){
        $configVars = $this->getServiceLocator()->get('Config');
        $project_image_dir = $configVars['project_image_dir'];        
        $document_root = $configVars['document_root'];
        $old_folder=$document_root .  $configVars['project_image_dir'] . '/' . $tempProjectId . '_temp';        
        $new_folder=$document_root .  $configVars['project_image_dir'] . '/' . $projectId;
        
        if( is_dir($old_folder) ) {
            #echo "mv {$old_folder} {$new_folder}";die;
            exec("mv {$old_folder} {$new_folder}");
         // or whatever error handling method you prefer
       }
        $search=array('tempProjectId'=>$tempProjectId);
        $data=$this->getTempProjectPicTable()->fetchAll(true,$search);       
        foreach($data as $key=>$val){
        $imageData=array('imageId'=>'','projectId'=>$projectId,'image'=>$val->imageName);
        $projectImageData= new ProjectImage();
        $projectImageData->exchangeArray($imageData);   
        $this->getProjectPicTable()->saveProjectImage($projectImageData);
        }
        try{
        $this->getTempProjectPicTable()->deleteTempProjectPicByTempProjectId($tempProjectId);
        }catch(\Exception $e) {}
        
    }
    
    
}
