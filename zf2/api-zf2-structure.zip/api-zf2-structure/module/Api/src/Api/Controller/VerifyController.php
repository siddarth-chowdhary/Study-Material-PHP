<?php
namespace Api\Controller;

use Api\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Mvc\MvcEvent;

use Api\Form\VerifyForm;
use Api\Model\ApiUser;

class VerifyController extends AbstractRestfulJsonController
{
    public function create($data)
    {   // Action used for POST requests
        $form = new VerifyForm();
        $user= new ApiUser();
        $form->setInputFilter($user->getInputFilter());
        $form->setData($data);
        if ($form->isValid()) {
            $formData = $form->getData();
            try {
                $userDetail = $this->getUserTable()->verifyUserAccount($formData);
                return new JsonModel(array('status'=>'success',"message" => 'Account verify successfully','user_detail'=>$userDetail));
            }
            catch(\Exception $e) {
                $message = $e->getMessage();
                return new JsonModel(array('status'=>'error',"message" => $message));
            }
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => $form->getMessages()));
        }
    }

    public function update($id, $data)
    {   // Action used for PUT requests
        return 'Hello';
    }
    
}
