<?php
namespace Api\Controller;

use Zend\View\Model\JsonModel;
use Zend\Mvc\MvcEvent;
use Services_Twilio;
use Admin\Model\User;

use Api\Form\GetSecurityCodeByPhoneForm;

class GetSecurityCodeByPhoneController extends AbstractRestfulJsonController
{
    /*
     * http_method : POST
     * url : /getsecuritycodebyphone
     * call when value post
     * @param phone :: required     
     * */
    public function create($data)
    {   // Action used for POST requests
        $form = new GetSecurityCodeByPhoneForm();
        $form->setData($data);
        if($form->isValid()) {
            $formData = $form->getData();
            try {                            
                $userDetail = (array) $this->getUserTable()->getDetailByPhone(array('phone'=>$formData['phone']));                                
                return new JsonModel(array('status'=>'success',"message" => 'success','securityCode'=>$userDetail['accessToken']));
            }
            catch(\Exception $e) {
                return new JsonModel(array('status'=>'error',"message" => (object) array('Invalid phone number')));
            }
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => $form->getMessages()));
        }
    }
    
}
