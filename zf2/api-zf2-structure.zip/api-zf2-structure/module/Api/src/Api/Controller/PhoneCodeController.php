<?php
namespace Api\Controller;

use Api\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Mvc\MvcEvent;
use Services_Twilio;
class PhoneCodeController extends AbstractRestfulJsonController
{
    /*
     * http_method : GET
     * url : /phonecode/isocode2
     * 
     * */
    public function get($id)
    {   // Action used for GET requests
        try {
            $countryList = $this->getCountryTable()->getDetailByColumns(array('countryIsoCode'=>$id,1));
            return new JsonModel(array('status'=>'success',"PhoneCode" => '+'.$countryList->countryPhoneCode,"CountryName" => $countryList->countryName));
        }
        catch (\Exception $e) {
            return new JsonModel(array('status'=>'error','message'=>(object) array('Iso Code not exist in database')));
        }
    }
    
}
