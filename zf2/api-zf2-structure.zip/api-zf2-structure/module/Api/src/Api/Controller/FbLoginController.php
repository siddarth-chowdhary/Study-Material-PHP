<?php
namespace Api\Controller;

use Zend\View\Model\JsonModel;
use Api\Form\FbForm;
use Admin\Model\User;
use Admin\Model\UserAddress;
use Admin\Model\PrivacySetting;


class FbLoginController extends AbstractRestfulJsonController
{
    public function create($data)
    {
	$data['email']=urldecode($data['email']);
        $form = new FbForm();
        $form->setData($data);
        if($form->isValid()) {
            $formData = $form->getData();
            $email = $formData['email'];
            $phone = !empty($formData['phone']) ? $formData['phone'] : '';
            $dateObj = new \DateTime('NOW');
            try {
                $userData = $this->getUserTable()->getDetailByColumns(array('email'=>$email));
                if($userData->statusId == 1 || $userData->statusId == 2) {
                    $userData->updatedDate = $dateObj->format('Y-m-d H:i:s');
                    $userData->statusId = 1;
                    //$userData->phone = $phone;
                    /*echo '<pre>';print_r(
                                array(
                                    $userData
                                    ,$data
                                )
                            );//die;*/
                    $this->getUserTable()->saveUser($userData);
                    $userDetail = $this->getUserTable()->verifyPasswordToken(array('user_name'=>$userData->userName,'password_token'=>$userData->password));
                    
                    return new JsonModel(array('status'=>'success',"message" => 'success','userDetail'=>$userDetail,'new_user'=>'no'));
                }
                else {
                    return new JsonModel(array('status'=>'error',"message" => (object) array('Please contact to Venture care')));
                }
            }
            catch(\Exception $e) {
                try {
                    if(empty($phone)) {
                        throw new \Exception('Phone number empty');
                    }
                    $userData = $this->getUserTable()->getDetailByColumns(array('phone'=>$phone));
                    if($userData->statusId == 1 || $userData->statusId == 2) {
                        if(filter_var($userData->email,FILTER_VALIDATE_EMAIL) === false) {
                            $userData->email = $email;
                            $userData->updatedDate = $dateObj->format('Y-m-d H:i:s');
                            $userData->statusId = 1;
                            $this->getUserTable()->saveUser($userData);
                            
                            $userDetail = $this->getUserTable()->verifyPasswordToken(array('user_name'=>$userData->userName,'password_token'=>$userData->password));
                            
                            return new JsonModel(array('status'=>'success',"message" => 'success','userDetail'=>$userDetail,'new_user'=>'no'));
                        }
                        else {
                            return new JsonModel(array('status'=>'error',"message" => (object) array('Phone number is associated with another user')));
                        }
                    }
                    else {
                        return new JsonModel(array('status'=>'error',"message" => (object) array('Please contact to Venture care')));
                    }
                }
                catch(\Exception $e) {
                    if(empty($formData['password'])) {
                        $formData['password'] = mt_rand(123456,9999999);
                    }
                    if(empty($phone)) {
                        $formData['phone'] = time();
                    }
                    $gender = strtolower($formData['gender']);
                    $formData['gender'] = ($gender == 'm') ? 1 : ($gender == 'f') ? 2 : 0 ;
                    if(!empty($formData['countryiso'])) {
                        $lenCountryCode = strlen($formData['countryiso']);
                        if($lenCountryCode == 2) {
                            $countryColumn = 'countryIsoCode';
                        }
                        else if($lenCountryCode == 3) {
                            $countryColumn = 'countryCode';
                        }
                        else {
                            $countryColumn = 'countryName';
                        }
                        try {
                            $country = $this->getCountryTable()->getDetailByColumns(array($countryColumn=>$formData['countryiso']));
                            $formData['countryiso'] = $country->countryId;
                        }
                        catch(\Exception $e) {
                            $formData['countryiso'] = '';
                        }
                    }
                    $user_name = time();
                    $password = sha1($formData['password']);
                    $insData = array(
                                'statusId'=>1
                                ,'loginFrom'=>1
                                ,'userName'=>$user_name
                                ,'email'=>$formData['email']
                                ,'phone'=>$formData['phone']
                                ,'password'=>$password
                                ,'firstName'=>$formData['firstName']
                                ,'lastName'=>$formData['lastName']
                                ,'gender'=>$formData['gender']
                                ,'address'=>$formData['address']
                                ,'countryId'=>$formData['countryiso']
                                ,'latitude'=>$formData['latitude']
                                ,'longitude'=>$formData['longitude']
                            );
                    $userPrototype = new User();
                    $userAddressPrototype = new UserAddress();
                    
                    $userPrototype->exchangeArray($insData);
                    $this->getUserTable()->saveUser($userPrototype);
                    $userId = $this->getUserTable()->lastInsertedValue();
                    $insData['userId'] = $userId;
                    $userAddressPrototype->exchangeArray($insData);
                    try {
                        $this->getUserAddressTable()->saveUserAddress($userAddressPrototype);
                    }
                    catch(\Exception $e){}
                    $userPrivacyPrototype = new PrivacySetting();
                    $userPrivacyPrototype->exchangeArray($insData);
                    $this->getPrivacySettingTable()->savePrivacySetting($userPrivacyPrototype);
                    
                    $userDetail = $this->getUserTable()->verifyPasswordToken(array('user_name'=>$user_name,'password_token'=>$password));
                    return new JsonModel(array('status'=>'success',"message" =>'success','userDetail'=> $userDetail,'new_user'=>'yes'));
                }
            }
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => $form->getMessages()));
        }
    }
}
