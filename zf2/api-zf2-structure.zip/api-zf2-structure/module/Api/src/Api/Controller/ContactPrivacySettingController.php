<?php

namespace Api\Controller;

use Zend\View\Model\JsonModel;
use Api\Form\ContactPrivacySettingForm;
use Admin\Model\User;
use Admin\Model\ContactPrivacySetting;

class ContactPrivacySettingController extends AbstractRestfulJsonController {

    public function create($data) {
        if (!empty($data['request_type'])) {
            $request_type = $data['request_type'];
            $form = new ContactPrivacySettingForm($request_type);
            $form->setData($data);
            if ($form->isValid()) {
                $formData = $form->getData();
                try {
                    $userData = $this->getUserTable()->verifyPasswordToken($formData);
                    $userId = $userData->userId;
                    if (is_array($data) && $userId != '') {
                        $data['userId'] = $userId;
                    }
                    switch ($request_type) {
                        case "insert":
                            return $this->insertContactPrivacySettings($data);
                            break;
                        case "update":
                            return $this->updateContactPrivacySettings($data);
                            break;
                        /* case "list":
                          return $this->listContactPrivacySettings($userId);
                          break;
                          case "deleteAccount":
                          return $this->deleteContactFromList($userId);
                          break; */
                        default:
                            return new JsonModel(array('status' => 'error', "message" => (object) array('Request Type Not Found')));
                    }
                } catch (\Exception $e) {
                    return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
                }
            } else {
                return new JsonModel(array('status' => 'error', "message" => $form->getMessages()));
            }
        } else {
            return new JsonModel(array('status' => 'error', "message" => (object) array('Request Type is required')));
        }
    }

    private function insertContactPrivacySettings($data) {

        $userId = $data['userId'];
        $contactId = $data['contactUserId'];
        $contactPrivacySetting = new ContactPrivacySetting();

        try {
            $settingData = $this->getContactPrivacySettingTable()->getContactPrivacySettingByUidCntId($userId, $contactId);
            return new JsonModel(array('status' => 'success', "message" =>'success', 'data' => $settingData));
        } catch (\Exception $e) {
            $data = array(
                'userId' => $userId,
                'contactUserId' => $contactId,
                'hideLinkedin' => '1',
                'hideProject' => '1',
                'hideProfilePhoto' => '1',
                'block' => '1',
                'report' => '1',
            );
            $contactPrivacySetting->exchangeArray($data);
            $table = $this->getContactPrivacySettingTable();
            $table->saveContactPrivacySetting($contactPrivacySetting);
            $contactSettingId = $this->getContactPrivacySettingTable()->lastInsertedValue();
            $settingData = $this->getContactPrivacySettingTable()->getContactPrivacySetting($contactSettingId);
            return new JsonModel(array('status' => 'success', "message" =>'success', 'data' => $settingData));
        }
    }

    private function updateContactPrivacySettings($data) {
        try {
            $resultUpdate = $this->getContactPrivacySettingTable()->updateContactPrivacySetting($data);
            $settingData = $this->getContactPrivacySettingTable()->getContactPrivacySetting($data['contactSettingId']);
        } catch (\Exception $e) {
            return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
        }
        if ($resultUpdate === true) {
            return new JsonModel(array('status' => 'success', "message" =>'success', 'data' => $settingData));
        } else {
            return new JsonModel(array('status' => 'error', "message" => $resultUpdate));
        }
    }

    /* private function listContactPrivacySettings($userId) {
      try {
      $result = $this->getPrivacySettingTable()->getPrivacySettingsForUser($userId);
      } catch (\Exception $e) {
      return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
      }
      return new JsonModel(array('status' => 'success', 'response' => $result));
      }

      private function deleteContactFromList($contactIdId) {
      try {
      $userDetail = (array) $this->getUserTable()->changeLoginUserStatusToDeleted(array('userId' => $userId));
      return new JsonModel(array('status' => 'success', "message" => 'success'));
      } catch (\Exception $e) {
      return new JsonModel(array('status' => 'error', "message" => (object) array('Invalid userId')));
      }
      } */
}
