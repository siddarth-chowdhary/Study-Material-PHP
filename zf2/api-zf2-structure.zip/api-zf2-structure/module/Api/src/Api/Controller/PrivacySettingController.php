<?php

namespace Api\Controller;

use Zend\View\Model\JsonModel;
use Api\Form\PrivacySettingForm;
use Admin\Model\User;

class PrivacySettingController extends AbstractRestfulJsonController {

    /**
     * @param type $data array
     * @param $data['request_type']
     * @param $data['user_name']
     * @param $data['password_token']
     * @param $data['column_name']
     * @param $data['column_value']
     * @return if $data['request_type'] == list
     * {
      status: "success"
      response: {
      settingId: "10"
      userId: "55"
      findMeByPhone: 1
      findMeByEmail: "1"
      findMeBySearch: "1"
      hideSkill: "1"
      hideLinkedin: "1"
      hideProject: 1
      hideProfilePhoto: "1"
      block: "1"
      report: "1"
      }-
      }
     * @return if $data['request_type'] == update
     * {
      status: "success"
      message: {
      0: "success"
      }
      }
     * Otherwise Appropriate error messages are shown
     */
    public function create($data) {
        if (!empty($data['request_type'])) {
            $request_type = $data['request_type'];
            $form = new PrivacySettingForm($request_type);
            $form->setData($data);
            if ($form->isValid()) {
                $formData = $form->getData();
                try {
                    $userData = $this->getUserTable()->verifyPasswordToken($formData);
                    $userId = $userData->userId;
                    if (is_array($data) && $userId != '') {
                        $data['userId'] = $userId;
                    }
                    switch ($request_type) {
                        case "update":
                            return $this->updateSettings($data);
                            break;
                        case "list":
                            return $this->listSettings($userId);
                            break;
                        case "deleteAccount":
                            return $this->deleteUserAccount($userId);
                            break;
                        default:
                            return new JsonModel(array('status' => 'error', "message" => (object) array('Request Type Not Found')));
                    }
                } catch (\Exception $e) {
                    return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
                }
            } else {
                return new JsonModel(array('status' => 'error', "message" => $form->getMessages()));
            }
        } else {
            return new JsonModel(array('status' => 'error', "message" => (object) array('Request Type is required')));
        }
    }

    private function updateSettings($data) {
        try {
            $resultUpdate = $this->getPrivacySettingTable()->updateUserPrivacySetting($data);
        } catch (\Exception $e) {
            return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
        }
        if ($resultUpdate === true) {
            return new JsonModel(array('status' => 'success', "message" =>'success'));
        } else {
            return new JsonModel(array('status' => 'error', "message" => $resultUpdate));
        }
    }

    private function listSettings($userId) {
        try {
            $result = $this->getPrivacySettingTable()->getPrivacySettingsForUser($userId);
        } catch (\Exception $e) {
            return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
        }
        return new JsonModel(array('status' => 'success', 'response' => $result));
    }

    private function deleteUserAccount($userId) {
        try { 
            $userDetail = (array) $this->getUserTable()->changeLoginUserStatusToDeleted(array('userId' => $userId));
            return new JsonModel(array('status' => 'success', "message" => 'success'));
        } catch (\Exception $e) {
            return new JsonModel(array('status' => 'error', "message" => (object) array('Invalid userId')));
        }
    }

}
