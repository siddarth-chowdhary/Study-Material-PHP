<?php
namespace Api\Controller;

use Api\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Mvc\MvcEvent;
use Services_Twilio;
class ForgotPasswordController extends AbstractRestfulJsonController
{
    private $phone;
    public function create($data)
    {   // Action used for POST requests
        
        if ($this->isValid($data)) {
            try {
                $userData = $this->getUserTable()->getDetailByColumns(array('phone'=>$data['phone'],'userType'=>2));
                if($userData->statusId == 1) {
                    //$accessToken = $this->generateRandomString(6);
                    $accessToken=  mt_rand(111111,999999);
                    $email = filter_var($userData->email,FILTER_VALIDATE_EMAIL) ? $userData->email : '';
                    $phone = $userData->phone;
                    $userData->accessToken = $accessToken;
                    $acceptedVal = array_flip(array('yes','y','1'));
                    $this->getUserTable()->saveUser($userData);
                    if(!empty($data['send_sms']) && isset($acceptedVal[strtolower($data['send_sms'])]) && !empty($phone)) {
                        try {
                            $configVars = $this->getServiceLocator()->get('Config');
                            
                            $twilioSid = $configVars['Twilio']['sid'];
                            $twilioToken = $configVars['Twilio']['auth_token'];
                            $senderNumber = $configVars['Twilio']['senderNumber'];
                            $client = new Services_Twilio($twilioSid, $twilioToken);
                            // send sms with verifcation code 
                            $response = $client->account->sms_messages->create($senderNumber, $phone, 'Forgot password verification code ' . $accessToken);
                        }
                        catch(\Services_Twilio_RestException $e) {}
                    }
                    if(!empty($data['send_mail']) && isset($acceptedVal[strtolower($data['send_mail'])]) && !empty($email)) {
                        try {
                            $emailToken = sha1($email.'#'.$accessToken);
                            $message = <<<HTML
                            <table>
                                <tr>
                                    <td>Forgot password verification code <br /><br />
                                    please input below code to reset your password<br />
                                    {$accessToken}
                                    </td>
                                </tr>
                            </table>
HTML;
                            $my_mailer = $this->getServiceLocator()->get('Admin\Service\MyMailer');
                            $my_mailer->setSubject('Forgot Password')
                                    ->setMessage($message)
                                    ->setToMails($email)
                                    ->sendMail();
                        }
                        catch(\Admin\Service\MyException $e) {
                            return new JsonModel(array('status'=>'success',"message" => $e->getMessage()));
                        }
                    }
                    return new JsonModel(array('status'=>'success',"message" => 'Success'));
                }
                else {
                    return new JsonModel(array('status'=>'error',"message" => (object)array('Please verify your account by entering verification code')));
                }
            }
            catch(\Exception $e) {
                $message = $e->getMessage();
                return new JsonModel(array('status'=>'error',"message" => (object)array('This phone number is not register with us')));
            }
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => $this->getMessages()));
        }
    }
    
    private function getMessages()
    {
        $message = array();
        if(!empty($this->phone)) {
            $message['phone'] = $this->phone;
        }
        return $message;
    }
    
    private function isValid($data)
    {
        $flag = true;
        if(!empty($data)) {
            if(empty($data['phone'])) {
                $this->phone = array('isEmpty'=>'Phone is required and can\'t be empty');
                $flag = false;
            }
        }
        else {
            $this->phone = array('isEmpty'=>'Phone is required and can\'t be empty');
            $flag = false;
        }
        return $flag;
    }
}
