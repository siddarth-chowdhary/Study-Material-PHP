<?php

namespace Api\Controller;

use Zend\View\Model\JsonModel;
use Admin\Service\FileUpload;
use Admin\Model\ProfilePic;
use Api\Form\ProfileForm;

class ProfileController extends AbstractRestfulJsonController {

    public function create($data) { /* Action used for POST requests */
        $request_type = !empty($data['request_type']) ? $data['request_type'] : '';

        $form = new ProfileForm($request_type);
        $form->setData($data);
        if ($form->isValid()) {
            $formData = $form->getData();
            try {
                $userData = $this->getUserTable()->verifyPasswordToken($formData);
                $userId = $userData->userId;
                switch ($formData['request_type']) {
                    case "view": {
                            return $this->getUserDetails($userData);
                            break;
                        }
                    case "updateProfileImage": {
                            return $this->updateProfileImage($userData);
                            break;
                        }
                    case "update": {
                            return $this->addUsersToContact($userData);
                            break;
                        }
                    default: {
                            return new JsonModel(array('status' => 'error', "message" => (object) array('Request Type ' . $formData['request_type'] . ' does not exist')));
                            break;
                        }
                }
            } catch (\Exception $e) {
                return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
            }
        } else {
            return new JsonModel(array('status' => 'error', "message" => $form->getMessages()));
        }
    }

    public function getUserDetails($userData) {
        $profileDetails = array(
            'userId' => $userData->userId
            , 'userName' => $userData->userName
            , 'firstName' => $userData->firstName
            , 'lastName' => $userData->lastName
            , 'gender' => $userData->gender
            //,'profilePicId'=>$userData->profilePicId
            , 'email' => $userData->email
            , 'phone' => $userData->phone
            , 'occupation' => $userData->occupation
            , 'interest1' => $userData->interest1
            , 'interest2' => $userData->interest2
            , 'interest3' => $userData->interest3
            , 'countryId' => $userData->countryId
            , 'stateId' => $userData->stateId
            , 'stateId' => $userData->stateId
            , 'region' => $userData->address
        );
        if (isset($userData->stateName) && $userData->stateName != '') {
            $profileDetails['region'].=' , ' . $userData->stateName;
        }
        if (isset($userData->countryName) && $userData->countryName != '') {
            $profileDetails['region'].=' , ' . $userData->countryName;
        }
        $profileDetails['profileImages'] = array();
        $profileImagesVal = $this->getProfilePicTable()->fetchAll(true, array('userId' => $userData->userId));
        $profileImagesVal->setItemCountPerPage('');
        foreach ($profileImagesVal as $key => $val) {
            $profileDetails['profileImages'][] = array('profilePic'=>$val->profilePic,'defaultPic'=>$val->defaultPic);
        }
        return new JsonModel(array('status' => 'success', "message" => 'Success', 'userProfile' => $profileDetails));
    }

    public function updateProfileImage($profileImageData) {
        $profileImagesArr = array();
        
        $File = $this->params()->fromFiles('profilePic');
        if (!empty($File)) {
            if ($File['type'] == 'image/jpeg' || $File['type'] == 'image/png') {
                $profilePic = new ProfilePic();
                $configVars = $this->getServiceLocator()->get('Config');
                $profile_image_dir = $configVars['profile_image_dir'];
                $uploadObj = new FileUpload(true);

                $uploadObj->resize = true;
                $uploadObj->createThumb = true;
                //$uploadObj->resizeOption = '';
                $uploadObj->document_root = $configVars['document_root'];
                $uploadObj->convert_path = $configVars['convert_path'];

                $fileName = $uploadObj->upload($File, array($profile_image_dir, $profileImageData->userId));
                $dateObj = new \DateTime('NOW');
                $data['profilePic'] = $fileName;
                $data['profilePicId'] = '';
                $data['userId'] = $profileImageData->userId;
                $data['defaultPic'] = '';
                $data['createdDate'] = $dateObj->format('Y-m-d H:i:s');
                $data['updatedDate'] = $dateObj->format('Y-m-d H:i:s');
                $profilePic->exchangeArray($data);
                try {
                    $this->getProfilePicTable()->saveProfilePic($profilePic);
                    $profileImagesVal = $this->getProfilePicTable()->fetchAll(true, array('userId' => $profileImageData->userId));
                    $profileImagesVal->setItemCountPerPage('');
                    foreach ($profileImagesVal as $key => $val) {
                        $profileImagesArr[] = array('profilePic'=>$val->profilePic,'defaultPic'=>$val->defaultPic);
                    }
                } catch (Exception $e) {
                    $this->flashmessenger()->addMessage($e->getMessage());
                }



                $profileImage = array(
                    'imageName' => $profilePic->profilePic
                );

                return new JsonModel(array('status' => 'success', "message" => 'Success', 'profileImagesArr' => $profileImagesArr));
            } else {
                return new JsonModel(array('status' => 'error', "message" => (object) array('Please select only jpg/png image to upload')));
            }
        } else {
            return new JsonModel(array('status' => 'error', "profilePic" => (object) array('profilePic is required'), "message" => (object) array('Please select Profile Image')));
        }
    }

}
