<?php

namespace Api\Controller;

use Zend\View\Model\JsonModel;
use Zend\Mvc\MvcEvent;
use Services_Twilio;
use Admin\Model\User;
use Admin\Model\TempProjectPic;
use Api\Form\TempProjectPicForm;
use Admin\Service\FileUpload;

class TempProjectPicController extends AbstractRestfulJsonController {
    /*
     * http_method : POST
     * url : /tempprojectpic
     * call when value post
     * @param phone :: required
     * @param security_code :: required
     * */

    public function create($data) {   // Action used for POST requests
        $form = new TempProjectPicForm();
        $form->setData($data);
        if ($form->isValid()) {
            $formData = $form->getData();
            try {
                $tempProjectPicProtoType = new TempProjectPic();
                $tempProjectPicProtoType->exchangeArray($data);

                //print_r($data);exit;

                $configVars = $this->getServiceLocator()->get('Config');
                $project_image_dir = $configVars['project_image_dir'];
                $request = $this->getRequest();
                $msg = "Please select file";
                $File = $this->params()->fromFiles('imageName');
                $uploadObj = new FileUpload(true);
                $uploadObj->resize = true;
                $uploadObj->createThumb = true;
                //$uploadObj->resizeOption = ''; 
                $uploadObj->document_root = $configVars['document_root'];
                $uploadObj->convert_path = $configVars['convert_path'];

                if ($data['tempProjectId'] == 'first') {
                    $tempProjectPicProtoType->tempProjectId = 0;
                    $tempProjectPicProtoType->imageName = '';
                    $userData = $this->getTempProjectPicTable()->saveTempProjectPic($tempProjectPicProtoType);
                    $idInserted = $this->getTempProjectPicTable()->lastInsertedValue();
                    $tempProjectPicProtoType->tempProjectId = $idInserted;
                    $tempProjectPicProtoType->tempId = $idInserted;
                    $tempProjectId = $idInserted;
                    $fileName = $uploadObj->upload($File, array($project_image_dir, $tempProjectId . '_temp'));
                    $tempProjectPicProtoType->imageName = $fileName;
                    $userData = $this->getTempProjectPicTable()->updateTempProjectPic($tempProjectPicProtoType);
                } else {
                    $tempProjectId = $tempProjectPicProtoType->tempProjectId;
                    $fileName = $uploadObj->upload($File, array($project_image_dir, $tempProjectId . '_temp'));
                    $tempProjectPicProtoType->imageName = $fileName;
                    $userData = $this->getTempProjectPicTable()->saveTempProjectPic($tempProjectPicProtoType);
                    $lastInserted = $this->getTempProjectPicTable()->lastInsertedValue();
                    $tempProjectPicProtoType->tempId = $lastInserted;
                }
                
                $tempProjectPicProtoType = $this->getTempProjectPicTable()->fetchAll(true,array('tempProjectId'=>$tempProjectId));                
                $tempProjectPicProtoTypeArr=array();
                $url='http://'.$configVars['http_host'].'/projectImage/'.$tempProjectId.'_temp/thumb_';
                foreach($tempProjectPicProtoType as $key=>$val){
                   $tempProjectPicProtoTypeArr[]=array('tempId'=>$val['tempId'],'tempProjectId'=>$val['tempProjectId'],'imageName'=>$val['imageName'],'url'=>$url.$val['imageName']);
                   
                }

                return new JsonModel(array('status' => 'success', "message" => 'success', 'data' =>$tempProjectPicProtoTypeArr));
            } catch (\Exception $e) {
                return new JsonModel(array('status' => 'error', "message" => (object) array('Wrong Security code or userName')));
            }
        } else {
            return new JsonModel(array('status' => 'error', "message" => $form->getMessages()));
        }
    }

    public function delete($tempId) {
        try {
            $row = $this->getTempProjectPicTable()->getTempProjectId($tempId);
            $tempProjectId = $row->tempProjectId;
            $imageName = $row->imageName;
            $configVars = $this->getServiceLocator()->get('Config');
            $document_root = $configVars['document_root'];
            $this->getTempProjectPicTable()->deleteTempProjectPic($tempId);
            @unlink($document_root . '/' . $configVars['project_image_dir'] . '/' . $tempProjectId . '_temp/' . $imageName);
            return new JsonModel(array('status' => 'success', "message" => 'Image deleted sucessfully'));
        } catch (\Exception $e) {
            //die($e->getMessage());
            return new JsonModel(array('status' => 'error', "message" => (object) array('Invalid imageId')));
        }
    }

}