<?php
namespace Api\Controller;

use Zend\View\Model\JsonModel;
use Zend\Mvc\MvcEvent;
use Services_Twilio;
use Admin\Model\User;

use Api\Form\CheckSecurityCodeForm;

class CheckSecurityCodeController extends AbstractRestfulJsonController
{
    /*
     * http_method : POST
     * url : /checksecuritycode
     * call when value post
     * @param phone :: required
     * @param security_code :: required     
     * */
    public function create($data)
    {   // Action used for POST requests
        $form = new CheckSecurityCodeForm();
        $form->setData($data);
        if($form->isValid()) {
            $formData = $form->getData();
            try {
                $strpos = strpos($formData['phone'], '-');
            if (empty($strpos)) {                
                $userDetail = (array) $this->getUserTable()->getDetailByPhone(array('phone'=>$formData['phone'],'accessToken'=>$formData['security_code']));               
                
                $userData = new User();
                $userData->exchangeArray($userDetail);
                
            } else {
                $userData = $this->getUserTable()->getDetailByColumns(array('phone'=>$formData['phone'],'accessToken'=>$formData['security_code']));
            }
                return new JsonModel(array('status'=>'success',"message" => 'success'));
            }
            catch(\Exception $e) {
                return new JsonModel(array('status'=>'error',"message" => (object) array('Wrong Security code or phone number')));
            }
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => $form->getMessages()));
        }
    }
    
}
