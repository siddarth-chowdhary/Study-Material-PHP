<?php
namespace Api\Controller;

use Api\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Mvc\MvcEvent;

use Api\Form\InterestForm;
use Api\Form\CommonElementForm;
use Api\Model\CommonInput;
use Admin\Model\UserInterest;

class UserInterestController extends AbstractRestfulJsonController
{
    public function create($data)
    {   // Action used for POST requests
        if(empty($data['type']))
            return $this->getInterest($data);
        else if(!empty($data['type']) && $data['type'] == 'add_update') {
            unset($data['type']);
            return $this->addUpdateInterest($data);
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => (object) array('Given type not exist.')));
        }
    }
    
    protected function addUpdateInterest($data)
    {
        $form = new InterestForm();
        $form->setData($data);
        if ($form->isValid()) {
            $formData = $form->getData();
            try {
                $userData = $this->getUserTable()->verifyPasswordToken($formData);
                $data['userId'] = $userData->userId;
                $interest = $data['interests'];
                $expInt = explode(',',$interest);
                foreach($expInt as $key=>$value) {
                    $data['interest'.($key+1)] = $value;
                }
                $userInterest = new UserInterest();
                $userInterest->exchangeArray($data);
                $this->getUserInterestTable()->saveUserInterest($userInterest);
                $interest = array();
                try {
                    $interestArr = $this->getUserInterestTable()->getInterests($data['userId']);
                    
                    if(!empty($interestArr['interest1'])) {
                        $interest[] = $interestArr['interest1'];
                    }
                    if(!empty($interestArr['interest2'])) {
                        $interest[] = $interestArr['interest2'];
                    }
                    if(!empty($interestArr['interest3'])) {
                        $interest[] = $interestArr['interest3'];
                    }
                }
                catch(Exception $e) {}
                return new JsonModel(array('status'=>'success',"message" => 'Success','interest'=>$interest));
            }
            catch(\Exception $e) {
                $message = $e->getMessage();
                return new JsonModel(array('status'=>'error',"message" => $message));
            }
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => $form->getMessages()));
        }
    }
    
    protected function getInterest($data)
    {
        $form = new CommonElementForm();
        $commonInput= new CommonInput();
        $form->setInputFilter($commonInput->getInputFilter());
        $form->setData($data);
        if ($form->isValid()) {
            $formData = $form->getData();
            try {
                $userData = $this->getUserTable()->verifyPasswordToken($formData);
                $interest = array();
                if(!empty($userData['interest1'])) {
                    $interest[] = $userData['interest1'];
                }
                if(!empty($userData['interest2'])) {
                    $interest[] = $userData['interest2'];
                }
                if(!empty($userData['interest3'])) {
                    $interest[] = $userData['interest3'];
                }
                return new JsonModel(array('status'=>'success',"message" => 'Success','interest'=>$interest));
            }
            catch(\Exception $e) {
                $message = $e->getMessage();
                return new JsonModel(array('status'=>'error',"message" => $message));
            }
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => $form->getMessages()));
        }
    }
    
}
