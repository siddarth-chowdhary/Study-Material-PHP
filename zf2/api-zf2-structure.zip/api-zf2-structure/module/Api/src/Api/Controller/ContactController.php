<?php

namespace Api\Controller;

use Api\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Mvc\MvcEvent;
use Api\Form\ContactForm;

class ContactController extends AbstractRestfulJsonController {

    private $page, $itemPerPage, $searchText, $userIds;

    private function setSearchText($value) {
        $this->searchText = $value;
        return $this;
    }

    private function setUserIds($value) {
        $this->userIds = $value;
        return $this;
    }

    private function setPage($value) {
        $this->page = $value;
        return $this;
    }

    private function setItemPerPage($value) {
        $this->itemPerPage = $value;
        return $this;
    }

    /*
     * @param user_name -- required
     * @param password_token -- required
     * @param request_type -- required //[list,add,search]
     * @param search_txt -- optional
     * @param page -- optional
     * @param limit_per_page -- optional
     * @param userIds -- optional, //required in case when request type will be add
     * */

    public function create($data) {   // Action used for POST requests
        $form = new ContactForm();
        $form->setData($data);
        if ($form->isValid()) {
            $formData = $form->getData();
            try {
                $userData = $this->getUserTable()->verifyPasswordToken($formData);
                $userId = $userData->userId;
                $page = !empty($formData['page']) ? $formData['page'] : 1;
                $limit_per_page = !empty($formData['limit_per_page']) ? $formData['limit_per_page'] : 10;
                $search_txt = !empty($formData['search_txt']) ? $formData['search_txt'] : '';
                $userIds = !empty($formData['userIds']) ? $formData['userIds'] : '';
                $this->setSearchText($search_txt)->setUserIds($userIds)->setPage($page)->setItemPerPage($limit_per_page);
                switch ($formData['request_type']) {
                    case "list": {
                            return $this->getContactLists($userId);
                            break;
                        }
                    case "search": {
                            return $this->getSearchUserList($userId);
                            break;
                        }
                    case "add": {
                            return $this->addUsersToContact($userId);
                            break;
                        }
                    default: {
                            return new JsonModel(array('status' => 'error', "message" => (object) array('Request Type ' . $formData['request_type'] . ' does not exist')));
                            break;
                        }
                }
            } catch (\Exception $e) {
                return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
            }
        } else {
            return new JsonModel(array('status' => 'error', "message" => $form->getMessages()));
        }
    }

    
    private function getAddedContactListsOfUser($userId) {
        $result = $this->getUserContactTable()->fetchAllUserContact(array('userId' => $userId, 'search_text' => $this->searchText));
        $configVars = $this->getServiceLocator()->get('Config');
        $profile_image_dir = $configVars['profile_image_dir'];
        $contacts = array();
        foreach ($result as $key => $user) {
            $contacts[]=$user->receiverId;
        }
        return $contacts;
    }
    private function getContactLists($userId) {
        $result = $this->getUserContactTable()->fetchAllUserContact(array('userId' => $userId, 'search_text' => $this->searchText));
        $configVars = $this->getServiceLocator()->get('Config');
        $profile_image_dir = $configVars['profile_image_dir'];
        $contacts = array();
        foreach ($result as $key => $user) {
            $url = 'http://' . $configVars['http_host'] . '/profilePic/' . $user->receiverId . '/thumb_';
            $contacts[] = array(
                'contactId' => $user->contactId
                , 'createdDate' => $user->createdDate
                , 'statusCode' => $user->statusCode
                , 'firstName' => $user->firstName
                , 'lastName' => $user->lastName
                , 'email' => $user->email
                , 'phone' => $user->phone
                , 'profilePic' => $url . $user->profilePic
                , 'defaultPic' => $user->defaultPic
                , 'address' => $user->address
                , 'occupation' => $user->occupation
                , 'state' => $user->stateName
                , 'country' => $user->countryName
                , 'contactUserId'=>$user->receiverId   
            );
        }
        return new JsonModel(array('status' => 'success', "message" => 'Success', 'contacts' => $contacts));
    }

    private function getSearchUserList($userId) {
        if (!empty($this->searchText)) {
            /*
             * To hide/show user please follow below steps
             * 1. check find me by search is on or not
             *  if<not>
             *      then don't display them
             * 2. check search_text is an email id or not
             *  if<valid_email>
             *      check "findMeByEmail" is 1
             *          if<not 1>
             *              then don't show it
             *  else if <contain + at zero index and '-' and all other is integers>
             *      check "findMeByPhone" is 1
             *          if<not 1>
             *              then don't show it
             * */
            $isContact=$this->getAddedContactListsOfUser($userId); //get user contact from userContact table           
            $configVars = $this->getServiceLocator()->get('Config');
            $profile_image_dir = $configVars['profile_image_dir'];
            $text = (int) str_replace(array('+', '-'), '', $this->searchText);
            $hideMeByEmail = (filter_var($this->searchText, FILTER_VALIDATE_EMAIL)) ? 1 : 0;
            $hideMeByPhone = (!empty($text)) ? 1 : 0;

            $params = array(
                'userType' => 2
                , 'statusId' => 1
                , 'notequalto' => array('userId' => $userId)
                , 'search_text' => $this->searchText
                //, 'excludeUser' => true
                , 'excludeUser' => false
            );
            $params['privacySetting']['search'] = 1;
            if (!empty($hideMeByEmail)) {
                $params['privacySetting']['email'] = $hideMeByEmail;
            }
            if (!empty($hideMeByPhone)) {
                $params['privacySetting']['phone'] = $hideMeByPhone;
            }

            $userSearch = $this->getUserTable()->getUserList($params);
            $userArr = array();

            foreach ($userSearch as $key => $user) {                
                $url = 'http://' . $configVars['http_host'] . '/profilePic/' . $user->userId . '/thumb_';
                if ($user->firstName != '') {
                    if(in_array($user->userId, $isContact)){
                      $iscnt=1;  
                    }else{
                        $iscnt=0;
                    }
                    //add isContact key to get its added to contact or not as requirement
                    $userArr[] = array(
                        'userId' => $user->userId
                        , 'firstName' => $user->firstName
                        , 'lastName' => $user->lastName
                        , 'gender' => $user->gender
                        , 'profilePicId' => $user->profilePicId
                        , 'email' => $user->email
                        , 'phone' => $user->phone
                        , 'profilePic' => $url . $user->profilePic
                        , 'defaultPic' => $user->defaultPic
                        , 'address' => $user->address
                        , 'occupation' => $user->occupation
                        , 'state' => $user->stateName
                        , 'country' => $user->countryName
                        , 'isContact'=>$iscnt      
                    );
                }
            }
            return new JsonModel(array('status' => 'success', "message" => 'Success', 'users' => $userArr));
        } else {
            return new JsonModel(array('status' => 'error', "message" => (object) array('search_txt' => array('isEmpty' => 'Search Text is required'))));
        }
    }

    /*
     * @param userId integer
     * add contact to userid
     * */

    private function addUsersToContact($userId) {
        if (!empty($this->userIds)) {
            try {
                $validIds = $this->getUserTable()->getValidUserIdsFromStringList($this->userIds, 'userIds', $userId);
                if (!empty($validIds)) {
                    $ids = explode(',', $validIds);
                    $formData = array();
                    $dateObj = new \DateTime('NOW');
                    foreach ($ids as $key => $val) {
                        try {
                            $this->getUserContactTable()->getDetailByColumns(array('senderId' => $userId, 'receiverId' => $val), 1);
                        } catch (\Exception $e) { // add ids in array if they are not exist
                            $formData[] = array(
                                'senderId' => $userId
                                , 'receiverId' => $val
                                , 'statusId' => 8
                                , 'createdDate' => $dateObj->format('Y-m-d H:i:s')
                                , 'updatedDate' => $dateObj->format('Y-m-d H:i:s')
                            );
                        }
                    }
                    if (!empty($formData)) {
                        $this->getUserContactTable()->saveMultipleContact('userContact', $formData);
                    }

                    return new JsonModel(array('status' => 'success', "message" => 'Success'));
                } else {
                    return new JsonModel(array('status' => 'error', "message" => (object) array('Please provide Valid user Ids')));
                }
            } catch (\Exception $e) {
                return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
            }
        } else {
            return new JsonModel(array('status' => 'error', "message" => (object) array('userIds' => array('isEmpty' => 'User Ids is required'))));
        }
    }

}
