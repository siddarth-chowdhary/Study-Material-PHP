<?php
namespace Api\Controller;

use Api\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Mvc\MvcEvent;

use Api\Form\RegisterForm;
use Admin\Model\User;
use Admin\Model\PrivacySetting;
use Admin\Model\UserAddress;
use Services_Twilio;
class RegisterController extends AbstractRestfulJsonController
{
    public function create($data)
    {   // Action used for POST requests
        
        $form = new RegisterForm();
        $request = $this->getRequest();
        $user= new User();
        $form->setInputFilter($user->getApiInputFilter());
        $form->setData($data);
        #echo "<pre>";print_r($data);die;
        if ($form->isValid()) {
            $data = $form->getData();
            
            $data['password'] = SHA1($data['password']);
            $data['email'] = time(); // because we need to check if email field contain int value then it will be treated as blank
            $data['userName'] = mt_rand(9999999,999999999);
            $data['accessToken'] = mt_rand(1000,9999);
            $user->exchangeArray($data);
            try {
                $this->getUserTable()->saveUser($user);
                $idInserted = $this->getUserTable()->lastInsertedValue();
                $data['userId'] = $idInserted;
                
                if(!empty($data['latitude']) && !empty($data['longitude'])) {
                    $userAddress=new UserAddress();
                    $userAddress->exchangeArray($data);
                    $this->getUserAddressTable()->saveUserAddress($userAddress);
                }
                
                //Insert data in privacySetting Table
                $privacySetting=new PrivacySetting();
                $privacySetting->exchangeArray($data);
                //echo "<pre>";print_r($privacySetting);exit;
                $pvcSetting=$this->getPrivacySettingTable()->savePrivacySetting($privacySetting);
                if(!empty($data['phone'])) {
                    try {
                        $configVars = $this->getServiceLocator()->get('Config');
                        
                        $twilioSid = $configVars['Twilio']['sid'];
                        $twilioToken = $configVars['Twilio']['auth_token'];
                        $senderNumber = $configVars['Twilio']['senderNumber'];
                        $client = new Services_Twilio($twilioSid, $twilioToken);
                        // send sms with verifcation code 
                        $response = $client->account->sms_messages->create($senderNumber, $data['phone'], 'Verification code ' . $data['accessToken']);
                    }
                    catch(\Services_Twilio_RestException $e) {
                        //$message = $e->getMessage();
                        //return new JsonModel(array('status'=>'ok',"message" => 'User created but sms not send','twilioMessage'=>$e->getMessage()));
                    }
                }
                return new JsonModel(array("status" =>'success','message'=>'User Created','password_token'=>$data['password']));
            }
            catch(\Admin\Service\MyException $e) {
                $message = $e->getMessage();
                return new JsonModel(array('status'=>'error',"message" => (object) array($e->getMessage())));
            }
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => $form->getMessages()));
        }
    }

    public function update($id, $data)
    {   // Action used for PUT requests
        throw new \Exception('this method is not allow');
        if(!empty($id)) {
            
            $form = new RegisterForm(true);
            $request = $this->getRequest();
            $user= new User();
            $form->setInputFilter($user->getApiInputFilter(true));
            $form->setData($data);
            if ($form->isValid()) {
                $data = $form->getData();
                try {
                    $userData = $this->getUserTable()->getDetailByColumns(array('userName'=>$data['user_name'],'password'=>$data['password_token']));
                    $data['userId'] = $userData->userId;
                    $data['password'] = $userData->password;
                    $data['userType'] = $userData->userType;
                    $data['profilePicId'] = $userData->profilePicId;
                    $data['statusId'] = $userData->statusId;
                    $data['createdDate'] = $userData->createdDate;
                    
                    if(empty($data['userName']))
                        $data['userName'] = $userData->userName;
                    if(empty($data['gender']))
                        $data['gender'] = $userData->gender;
                    if(empty($data['occupation']))
                        $data['occupation'] = $userData->occupation;
                    if(empty($data['skill']))
                        $data['skill'] = $userData->skill;
                    if(empty($data['phone']))
                        $data['phone'] = $userData->phone;
                    if(empty($data['email']))
                        $data['email'] = $userData->email;
                    
                    $user->exchangeArray($data);
                    try {
                        $this->getUserTable()->saveUser($user);
                    }
                    catch(\Admin\Service\MyException $e) {
                        $message = $e->getMessage();
                        return new JsonModel(array('status'=>'error',"message" => $e->getMessage()));
                    }
                    return new JsonModel(array('status'=>'success',"message" => 'User updated'));
                }
                catch(\Exception $e) {
                    return new JsonModel(array('status'=>'error',"message" => 'User name or password token mismatch.'));
                }
            }
            else {
                return new JsonModel(array('status'=>'error',"message" => $form->getMessages()));
            }
        }
        else 
            return new JsonModel(array('status'=>'error',"message" => 'User id/name Should be any valid identifier'));
    }
    
    public function get($id) {
        try {
            $userData = $this->getUserTable()->getDetailByColumns(array('phone'=>$id));
            $userId = $userData->userId; 
            $this->getUserTable()->deleteUser($userId);
            $this->getPrivacySettingTable()->deletePrivacySettingByUserId($userId);
            $this->getUserAddressTable()->deleteAddressByUserId($userId);
            return new JsonModel(array('status'=>'success',"message" => 'User deleted'));
        }
        catch(\Exception $e) {
            return new JsonModel(array('status'=>'error',"message" => $e->getMessage()));
        }
    }
    
}
