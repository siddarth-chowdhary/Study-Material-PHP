<?php

namespace Api\Controller;

use Zend\View\Model\JsonModel;
use Zend\Mvc\MvcEvent;
use Api\Form\VerifyForm;
use Api\Model\ApiUser;
use Services_Twilio;

class ResendSecurityCodeController extends AbstractRestfulJsonController {

    public function get($id) {   // Action used for POST requests
        try {
            $strpos = strpos($id, '-');
            if (empty($strpos)) {                
                $userData = $this->getUserTable()->getDetailByPhone(array('phone' => $id, 'userType' => 2));               
            } else {
                $userData = $this->getUserTable()->getDetailByColumns(array('phone' => $id, 'userType' => 2));
            }
            
            if ($userData->statusId != 1) {
                if (!empty($userData->accessToken)) {
                    $accessToken = $userData->accessToken;

                    try {
                        $configVars = $this->getServiceLocator()->get('Config');

                        $twilioSid = $configVars['Twilio']['sid'];
                        $twilioToken = $configVars['Twilio']['auth_token'];
                        $senderNumber = $configVars['Twilio']['senderNumber'];
                        $client = new Services_Twilio($twilioSid, $twilioToken);
                        // send sms with verifcation code 
                        $response = $client->account->sms_messages->create($senderNumber, $id, 'Verification code ' . $accessToken);
                    } catch (\Services_Twilio_RestException $e) {
                        $message = $e->getMessage();
                        #return new JsonModel(array('status'=>'error',"message" => (object) array($e->getMessage())));
                    }

                    return new JsonModel(array('status' => 'success', "message" => 'Success'));
                } else {
                    return new JsonModel(array('status' => 'error', "message" => (object) array('Please contact to Venture care')));
                }
            } else {
                return new JsonModel(array('status' => 'error', "message" => (object) array('Account Already Verified')));
            }
        } catch (\Exception $e) {
            $message = $e->getMessage();
            return new JsonModel(array('status' => 'error', "message" => $message));
        }
    }

}
