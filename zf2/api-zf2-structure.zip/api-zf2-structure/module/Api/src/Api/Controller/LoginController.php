<?php
namespace Api\Controller;

use Api\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Mvc\MvcEvent;

use Api\Form\LoginForm;
use Api\Model\Login;

class LoginController extends AbstractRestfulJsonController
{
    public function create($data)
    {   // Action used for POST requests
        $form = new LoginForm();
        $loginModel= new Login();
        $form->setInputFilter($loginModel->getInputFilter());
        $form->setData($data);
        if ($form->isValid()) {
            $formData = $form->getData();
            try {
                $formData['password'] = SHA1($formData['password']);
                $userData = $this->getUserTable()->apiUserLogin($formData);
                return new JsonModel(array('status'=>'success',"message" =>'success','userDetail'=> $userData));
            }
            catch(\Exception $e) {
                return new JsonModel(array('status'=>'error',"message" => 'Either user name or password is wrong'));
                //return new JsonModel(array('status'=>'error',"message" => (object) array('Either user name or password is wrong')));
            }
        }
        else {
            return new JsonModel(array('status'=>'error',"message" => $form->getMessages()));
        }
    }

    public function update($id, $data)
    {   // Action used for PUT requests
        return 'Hello';
    }
    
}
