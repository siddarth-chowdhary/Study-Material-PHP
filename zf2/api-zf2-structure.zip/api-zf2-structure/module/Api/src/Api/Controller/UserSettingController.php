<?php

namespace Api\Controller;

use Zend\View\Model\JsonModel;
use Admin\Service\FileUpload;
use Admin\Model\User;
use Api\Form\UserSettingForm;
use Api\Form\UserSettingInputFilter;
use Zend\Validator;

class UserSettingController extends AbstractRestfulJsonController {

    public function create($data) { /* Action used for POST requests */       
        $request_type = !empty($data['request_type']) ? $data['request_type'] : '';
        $form = new UserSettingForm($request_type);
        $form->setData($data);
        if ($form->isValid()) {
            $formData = $form->getData();
            try {
                $userData = $this->getUserTable()->verifyPasswordToken($formData);
                $userId = $userData->userId;

                switch ($formData['request_type']) {
                    case "updateEmail": {
                            return $this->updateUserEmail($userData, $formData);
                            break;
                        }
                    case "updateVentureId": {
                            return $this->updateVentureId($userData, $formData);
                            break;
                        }
                    case "changeEmail": {
                            return $this->changeUserEmail($userData, $formData);
                            break;
                        }
                    case "updatePhone": {
                            return $this->updateUserPhone($userData, $formData);
                            break;
                        }
                    case "changePassword": {
                            return $this->changeUserPassword($userData, $formData);
                            break;
                        }
                    default: {
                            return new JsonModel(array('status' => 'error', "message" => (object) array('Request Type ' . $formData['request_type'] . ' does not exist')));
                            break;
                        }
                }
            } catch (\Exception $e) {
                return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
            }
        } else {
            return new JsonModel(array('status' => 'error', "message" => $form->getMessages()));
        }
    }

    public function updateVentureId($userData, $formData) {

        $string = $formData['ventureId'];
        $userName = $userData->userName;
        $pattern = '/^[a-z]+([a-z0-9._]*)?[a-z0-9]+$/i';
        if (!preg_match($pattern, $string) && is_numeric($string) && is_numeric($userName)) {
            return new JsonModel(array('status' => 'error', "message" => (object) array('Venture Id should be alpha numeric')));
        } else {

            if (is_numeric($userName)) {
                $userData->userName = $formData['ventureId'];
                try {
                    $this->getUserTable()->updateUserSettings(array('userName' => $formData['ventureId']), $userData->userId);
                    return new JsonModel(array('status' => 'success', "message" => 'Success', 'userName' => $formData['ventureId']));
                } catch (\Exception $e) {
                    return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
                }
            } else {
                return new JsonModel(array('status' => 'error', "message" => (object) array('Venture Id Can\'t be change')));
            }
        }
    }
    
    public function updateUserEmail($userData, $formData) {
        //insert email if it is blank or contain integer value 
        
        /*
          is_numeric($userData->email)
          filter_var($userData->email,FILTER_VALIDATE_EMAIL);
         */
        if (isset($userData->email) && is_numeric($userData->email)) {
            if ($userData->password_token == sha1($formData['password'])) {
                try {
                    $this->getUserTable()->updateUserSettings(array('email' => $formData['email']), $userData->userId);
                    return new JsonModel(array('status' => 'success', "message" => 'Success', 'email' => $formData['email']));
                } catch (\Exception $e) {
                    return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
                }
            } else {
                return new JsonModel(array('status' => 'error', "message" => (object) array('Invalid Password')));
            }
        } else {
            return new JsonModel(array('status' => 'error', "message" => (object) array('Email Canot be changed. please update it')));
        }
    }

    public function changeUserEmail($userData, $formData) {
        //change email      
        if (isset($userData->email) && $userData->email == $formData['email']) {
            if ($userData->password_token == sha1($formData['password'])) {
                try {
                    $this->getUserTable()->updateUserSettings(array('email' => $formData['newemail']), $userData->userId);
                    return new JsonModel(array('status' => 'success', "message" => 'Success', 'email' => $formData['newemail']));
                } catch (\Exception $e) {
                    return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
                }
            } else {
                return new JsonModel(array('status' => 'error', "message" => (object) array('Invalid email or password')));
            }
        } else {
            return new JsonModel(array('status' => 'error', "message" => (object) array('Invalid email or password')));
        }
    }

    public function updateUserPhone($userData, $formData) {
        if (isset($userData->phone) && $userData->phone == $formData['phone']) {
            try {
                $this->getUserTable()->updateUserSettings(array('phone' => $formData['newphone']), $userData->userId);
                return new JsonModel(array('status' => 'success', "message" => 'Success', 'phone' => $formData['newphone']));
            } catch (\Exception $e) {
                return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
            }
        } else {
            return new JsonModel(array('status' => 'error', "message" => (object) array('Current phone does not match in out database.')));
        }
    }

    public function changeUserPassword($userData, $formData) {        
        if (isset($userData->password_token) && $userData->password_token == sha1($formData['oldpassword'])) {
            try {
                $this->getUserTable()->updateUserSettings(array('password' => sha1($formData['newpassword'])), $userData->userId);
                return new JsonModel(array('status' => 'success','new_password_token'=>sha1($formData['newpassword']), "message" => 'Success'));
            } catch (\Exception $e) {
                return new JsonModel(array('status' => 'error', "message" => (object) array($e->getMessage())));
            }
        } else {
            return new JsonModel(array('status' => 'error', "message" => (object) array('Old password does not match in out database.')));
        }
    }

}
