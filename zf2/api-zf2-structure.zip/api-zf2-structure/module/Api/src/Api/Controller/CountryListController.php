<?php
namespace Api\Controller;

use Api\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Mvc\MvcEvent;
use Services_Twilio;
class CountryListController extends AbstractRestfulJsonController
{
    /*
     * http_method : GET
     * url : /countrylist
     * 
     * */
    public function getList()
    {   // Action used for GET requests
        $countryList = $this->getCountryTable()->fetchAll(false,array('countryCode','countryName','countryPhoneCode','countryIsoCode'));
        $list = array();
        foreach($countryList as $key=>$detail) {
            $list[] = array(
                        'countryCode'=>$detail->countryCode
                        ,'countryName'=>$detail->countryName
                        ,'countryPhoneCode'=>$detail->countryPhoneCode
                        ,'countryIsoCode'=>$detail->countryIsoCode
                        );
        }
        return new JsonModel(array('status'=>'success',"countries" => $list));
    }
    
}
