<?php

namespace Api\Controller;

use Zend\View\Model\JsonModel;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\Http\Response;

class AbstractRestfulJsonController extends AbstractRestfulController {

    protected $userTable
            , $countryTable
            , $UserInterestTable
            , $privacySettingTable
            , $userAddressTable
            , $userContactTable
            , $projectTable
            , $projectPicTable
            , $tempProjectPicTable
            , $projectImageTable
            , $profilePicTable
            , $projectViewCountTable
            , $projectViewRequestTable
            , $contactPrivacySettingTable

    ;
    
    public function getUserTable() {
        if (!$this->userTable) {
            $sm = $this->getServiceLocator();
            $this->userTable = $sm->get('Admin\Model\UserTable');
        }
        return $this->userTable;
    }

    public function getUserAddressTable() {
        if (!$this->userAddressTable) {
            $sm = $this->getServiceLocator();
            $this->userAddressTable = $sm->get('Admin\Model\UserAddressTable');
        }
        return $this->userAddressTable;
    }

    public function getUserContactTable() {
        if (!$this->userContactTable) {
            $sm = $this->getServiceLocator();
            $this->userContactTable = $sm->get('Admin\Model\UserContactTable');
        }
        return $this->userContactTable;
    }

    public function getProjectTable() {
        if (!$this->projectTable) {
            $sm = $this->getServiceLocator();
            $this->projectTable = $sm->get('Admin\Model\ProjectTable');
        }
        return $this->projectTable;
    }

    public function getPrivacySettingTable() {
        if (!$this->privacySettingTable) {
            $sm = $this->getServiceLocator();
            $this->privacySettingTable = $sm->get('Admin\Model\PrivacySettingTable');
        }
        return $this->privacySettingTable;
    }

    public function getUserInterestTable() {
        if (!$this->UserInterestTable) {
            $sm = $this->getServiceLocator();
            $this->UserInterestTable = $sm->get('Admin\Model\UserInterestTable');
        }
        return $this->UserInterestTable;
    }

    public function getCountryTable() {
        if (!$this->countryTable) {
            $sm = $this->getServiceLocator();
            $this->countryTable = $sm->get('Admin\Model\CountryTable');
        }
        return $this->countryTable;
    }

    public function getProfilePicTable() {
        if (!$this->profilePicTable) {
            $sm = $this->getServiceLocator();
            $this->profilePicTable = $sm->get('Admin\Model\ProfilePicTable');
        }
        return $this->profilePicTable;
    }

    public function getTempProjectPicTable() {
        if (!$this->tempProjectPicTable) {
            $sm = $this->getServiceLocator();
            $this->tempProjectPicTable = $sm->get('Admin\Model\TempProjectPicTable');
        }
        return $this->tempProjectPicTable;
    }
    public function getProjectPicTable() {
        if (!$this->projectImageTable) {
            $sm = $this->getServiceLocator();
            $this->projectImageTable = $sm->get('Admin\Model\ProjectImageTable');
        }
        return $this->projectImageTable;
    }
    
    public function getProjectViewCountTable(){
        if (!$this->projectViewCountTable) {
            $sm = $this->getServiceLocator();
            $this->projectViewCountTable = $sm->get('Admin\Model\ProjectViewCountTable');
        }
        return $this->projectViewCountTable;
    }
    
    public function getProjectViewRequestTable(){
        if (!$this->projectViewRequestTable) {
            $sm = $this->getServiceLocator();
            $this->projectViewRequestTable = $sm->get('Admin\Model\projectViewRequestTable');
        }
        return $this->projectViewRequestTable;
    }
    public function getContactPrivacySettingTable() {
        if (!$this->contactPrivacySettingTable) {
            $sm = $this->getServiceLocator();
            $this->contactPrivacySettingTable = $sm->get('Admin\Model\ContactPrivacySettingTable');
        }
        return $this->contactPrivacySettingTable;
    }

    public function generateRandomString($length = 10) {
        return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
    }

    protected function methodNotAllowed() {
        $this->response->setStatusCode(405);
        return new JsonModel(array(
            'status' => 'error'
            , 'message' => 'Method Not Allowed'
        ));
        //throw new \Exception('Method Not Allowed');
    }

    # Override default actions as they do not return valid JsonModels

    public function create($data) {
        return $this->methodNotAllowed();
    }

    public function delete($id) {
        return $this->methodNotAllowed();
    }

    public function deleteList() {
        return $this->methodNotAllowed();
    }

    public function get($id) {
        return $this->methodNotAllowed();
    }

    public function getList() {
        return $this->methodNotAllowed();
    }

    public function head($id = null) {
        return $this->methodNotAllowed();
    }

    public function options() {
        return $this->methodNotAllowed();
    }

    public function patch($id, $data) {
        return $this->methodNotAllowed();
    }

    public function replaceList($data) {
        return $this->methodNotAllowed();
    }

    public function patchList($data) {
        return $this->methodNotAllowed();
    }

    public function update($id, $data) {
        return $this->methodNotAllowed();
    }

}
