<?php
namespace Api\Model;

use Zend\InputFilter\InputFilter;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class Login implements InputFilterAwareInterface
{
    protected $inputFilter;
    
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }
    
    // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
     
     public function getInputFilter() {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $inputFilter->add(array(
                    'name' => 'user_name',
                    'required' => true,
                    'filters' => array(
                        array('name' => 'StripTags'),
                        array('name' => 'StringTrim'),
                    ),
                    'options' => array(
                        'label' => 'user Name',
                    ),
                    'validators' => array(
                        array(
                            'name'=>'NotEmpty',
                            'break_chain_on_failure' => true,
                            'options'=>array(
                                'message' => 'User Name is required',
                            ),
                        ),
                    ),
            ));
            $inputFilter->add(array(
                    'name' => 'password',
                    'required' => true,
                     'filters'  => array(
                        array('name' => 'StripTags'),
                        array('name' => 'StringTrim'),
                    ),
                    'options' => array(
                        'label' => 'Password',
                    ),
                    'validators' => array(
                        array(
                            'name'=>'NotEmpty',
                            'break_chain_on_failure' => true,
                            'options'=>array(
                                'message' => 'Password is required',
                            ),
                        ),
                    )
            ));
            $this->inputFilter = $inputFilter;
        }
        
        return $this->inputFilter;
     }
}
