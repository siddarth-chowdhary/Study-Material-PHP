<?php
namespace Api\Model;

use Zend\InputFilter\InputFilter;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class ApiUser implements InputFilterAwareInterface
{
    protected $inputFilter;
    
    public function exchangeArray($data)
    {
    }
    
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }
    
    // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
     
     public function getInputFilter() {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $inputFilter->add(array(
                    'name' => 'phone',
                    'required' => true,
                    'filters' => array(
                        array('name' => 'StripTags'),
                        array('name' => 'StringTrim'),
                    ),
                    'options' => array(
                        'label' => 'Phone',
                    ),
                    'validators' => array(
                        array(
                            'name'=>'NotEmpty',
                            'break_chain_on_failure' => true,
                            'options'=>array(
                                'message' => 'Phone is required',
                            ),
                        ),
                        array(
                            'name' => 'StringLength',
                            'options' => array(
                                'encoding' => 'UTF-8',
                                'min' => 8,
                                'max' => 15,
                                'message' => 'Phone number must be min 10 characters long',
                            ),
                        ),
                    ),
            ));
            $inputFilter->add(array(
                        'name' => 'securityCode',
                        'required' => true,
                         'filters'  => array(
                            array('name' => 'int'),
						),
                        'options' => array(
                            'label' => 'Security Code',
                        ),
                'validators' => array(
                    array(
                            'name'=>'NotEmpty',
                            'break_chain_on_failure' => true,
                            'options'=>array(
                                'message' => 'Security Code is required',
                            ),
                        ),
                    array(
                        'name' => 'int',
                        'options' => array(
                            'min' => 3, // its min size of sha1 hash string. actually sha1 will create hash string of length 40
                            'max' => 5, // but for precaution we are taking 10 more length
                            'message' => 'Security Code should be 3-5 characters long',
                        ),
                    ),
                ),
            ));
            $this->inputFilter = $inputFilter;
        }
        
        return $this->inputFilter;
     }
}
