<?php
namespace Api\Model;

use Zend\InputFilter\InputFilter;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;


class CommonInput implements InputFilterAwareInterface
{
    protected $inputFilter;
    
    public function getArrayCopy()
    {
        return get_object_vars($this);
    }
    
    // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
     
     public function getInputFilter() {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $inputFilter->add(array(
                    'name' => 'user_name',
                    'required' => true,
                    'filters' => array(
                        array('name' => 'StripTags'),
                        array('name' => 'StringTrim'),
                    ),
                    'options' => array(
                        'label' => 'user Name',
                    ),
                    'validators' => array(
                        array(
                            'name'=>'NotEmpty',
                            'break_chain_on_failure' => true,
                            'options'=>array(
                                'message' => 'User Name is required',
                            ),
                        ),
                        array(
                            'name' => 'StringLength',
                            'options' => array(
                                'encoding' => 'UTF-8',
                                'min' => 6,
                                'max' => 20,
                                'message' => 'User Name should be 6-20 characters long',
                            ),
                        ),
                    ),
            ));
            $inputFilter->add(array(
                        'name' => 'password_token',
                        'required' => true,
                         'filters'  => array(
                            array('name' => 'StringTrim'),
						),
                        'options' => array(
                            'label' => 'Password Token',
                        ),
                'validators' => array(
                    array(
                            'name'=>'NotEmpty',
                            'break_chain_on_failure' => true,
                            'options'=>array(
                                'message' => 'Password Token is required',
                            ),
                        ),
                    array(
                        'name' => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min' => 40, // its min size of sha1 hash string. actually sha1 will create hash string of length 40
                            'max' => 50, // but for precaution we are taking 10 more length
                            'message' => 'Password Token should be 40-50 characters long',
                        ),
                    ),
                ),
            ));
            $this->inputFilter = $inputFilter;
        }
        
        return $this->inputFilter;
     }
}
