<?php

namespace Api\Form;

class ContactPrivacySettingFilter extends CommonInputFilter {

    public function __construct($request_type = null) {
        parent::__construct();

        $this->add(array(
            'name' => 'request_type',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Request Type',
            ),
            'validators' => array(
                array(
                    'name' => 'NotEmpty',
                    'break_chain_on_failure' => true,
                    'options' => array(
                        'message' => 'Request Type is required',
                    ),
                ),
            ),
        ));
        
        /**
         * @desc - Added the below 2 filters only when the case is update
         * They are not required in the list case
         */
        if ($request_type == "update") {
            $this->add(array(
                'name' => 'colName',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Column Name',
                ),
                'validators' => array(
                    array(
                        'name' => 'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'message' => 'Column Name is required',
                        ),
                    ),
                    array(
                        'name' => 'alpha',
                        'options' => array(
                            'message' => 'Column Name Should be Alphabetic',
                        ),
                    ),
                ),
            ));

            $this->add(array(
                'name' => 'colValue',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Column Value',
                ),
                'validators' => array(
                    array(
                        'name' => 'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'message' => 'Column Value is required',
                        ),
                    ),
                    array(
                        'name' => 'digits',
                        'options' => array(
                            'message' => 'Column Value Should be numeric',
                        ),
                    ),
                    array(
                        'name' => 'between',
                        'options' => array(
                            'min' => 1,
                            'max' => 2,
                            'message' => 'Column Value Should Be either 2(No) or 1(Yes)',
                        ),
                    ),
                ),
            ));
        }
    }

}
