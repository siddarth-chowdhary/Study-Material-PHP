<?php

namespace Api\Form;

class ProjectRequestFilter extends CommonInputFilter {

    public function __construct($request_type = null) {
        parent::__construct();

        $this->add(array(
            'name' => 'request_type',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Request Type',
            ),
            'validators' => array(
                array(
                    'name' => 'NotEmpty',
                    'break_chain_on_failure' => true,
                    'options' => array(
                        'message' => 'Request Type is required',
                    ),
                ),
            ),
        ));
        
        $this->add(array(
            'name' => 'projectId',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Project Id',
            ),
            'validators' => array(
                array(
                    'name' => 'NotEmpty',
                    'break_chain_on_failure' => true,
                    'options' => array(
                        'message' => 'Project Id is required',
                    ),
                ),
                array( 
                    'name' => 'digits',
                    'options' => array(
                        'message' => 'Project Id Should be numeric',
                    ),
                ),
            ),
        ));
        
        $this->add(array(
            'name' => 'userId',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'User Id',
            ),
            'validators' => array(
                array(
                    'name' => 'NotEmpty',
                    'break_chain_on_failure' => true,
                    'options' => array(
                        'message' => 'User Id is required',
                    ),
                ),
            ),
        ));
        
        

    }

}
