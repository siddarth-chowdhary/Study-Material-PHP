<?php
namespace Api\Form;

use Zend\InputFilter\InputFilter;
use Zend\InputFilter\Factory as InputFactory;
class FbFormInputFilter extends InputFilter
{
    public function __construct() {
        $this->add(array(
            'name' => 'email',
            'required' => true,
            'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
            'options' => array(
                'label' => 'Email',
            ),
            'validators' => array(
                array(
                    'name'=>'NotEmpty',
                    'break_chain_on_failure' => true,
                    'options'=>array(
                        'message' => 'Email is required',
                    ),
                ),
               array(
                    'name'=>'EmailAddress'
                    ,'break_chain_on_failure' => true
                    ,'options'=>array(
                        'domain' => false
                        ,'useMxCheck'  => false
                        ,'message'=>'Email is not valid. please input valid email'
                    ),
                ),
            ),
        ));
        $this->add(array(
            'name' => 'phone',
            'required' => false,
            'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
            'options' => array(
                'label' => 'Phone',
            ),
            'validators' => array(
                array(
                    'name'=>'NotEmpty',
                    'break_chain_on_failure' => true,
                    'options'=>array(
                        'message' => 'Phone is required',
                    ),
                ),
                array(
                    'name'=>'regex'
                    ,'options'=>array(
                        'pattern'=>'/\+(9[976]\d|8[987530]\d|6[987]\d|5[90]\d|42\d|3[875]\d|2[98654321]\d|9[8543210]|8[6421]|6[6543210]|5[87654321]|4[987654310]|3[9643210]|2[70]|7|1)-\d{1,11}$/'
                        ,'message' => 'Phone is not valid please input correct format ( like +1-1111111111)',
                    ),
                ),
            ),
        ));
        $this->add(array(
            'name' => 'password',
            'required' => false,
            'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
            'options' => array(
                'label' => 'Password',
            )
        ));
        $this->add(array(
            'name' => 'firstName',
            'required' => false,
            'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
            'options' => array(
                'label' => 'First Name',
            )
        ));
        $this->add(array(
            'name' => 'lastName',
            'required' => false,
            'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
            'options' => array(
                'label' => 'Lirst Name',
            )
        ));
        $this->add(array(
            'name' => 'gender',
            'required' => false,
            'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
            'options' => array(
                'label' => 'Gender',
            )
        ));
        $this->add(array(
            'name' => 'address',
            'required' => false,
            'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
            'options' => array(
                'label' => 'Address',
            )
        ));
        $this->add(array(
            'name' => 'state',
            'required' => false,
            'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
            'options' => array(
                'label' => 'State',
            )
        ));
        $this->add(array(
            'name' => 'countryiso',
            'required' => false,
            'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
            'options' => array(
                'label' => 'Country',
            )
        ));
        $this->add(array(
            'name' => 'latitude',
            'required' => false,
            'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
            'options' => array(
                'label' => 'Latitude',
            ),
            'validators'=>array(
                array(
                    'name'=>'Float',
                    'options'=>array(
                        'message'=>'Latitude should be float/real value'
                    ),
                ),
            )
        ));
        
        $this->add(array(
                        'name' => 'longitude',
                        'required' => false,
                        'options' => array(
                            'label' => 'Longitude',
                        ),
                        'validators' => array(
                            array(
                                'name'=>'Float',
                                'options'=>array(
                                    'message'=>'Longitude should be float/real value'
                                ),
                            ),
                        )
            ));
    }
}
