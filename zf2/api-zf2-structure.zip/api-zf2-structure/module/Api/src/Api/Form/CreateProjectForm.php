<?php

namespace Api\Form;

class CreateProjectForm extends CommonElementForm
{
    public function __construct() {
        parent::__construct('project_form',true,true);
        $this->setAttribute('enctype','multipart/form-data'); 
        $this->setInputFilter(new CreateProjectInputFilter());
       
        $this->add(array(
            'name'     => 'projectName'
            ,'type'=>'Text'
            ,'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            )
            ,'options' => array(
                'label' => 'Project Name',
            ),
         ));
        $this->add(array(
            'name'     => 'projectDetail'
            ,'type'=>'textarea'
            ,'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            )
             ,'options' => array(
                'label' => 'Project Detail',
            ),
         ));
        $this->add(array(
            'name'     => 'projectVisibility'
            ,'type'=>'Text'
            ,'options' => array(
                'label' => 'Project Visibility',
            ),
         ));
        $this->add(array(
            'name'     => 'lockProjectDetail'
            ,'type'=>'Text'
            ,'options' => array(
                'label' => 'Lock Project Detail',
            ),
         ));
        $this->add(array(
            'name'     => 'tempProjectId'
            ,'type'=>'Text'
            ,'options' => array(
                'label' => 'Temp Project Id',
            ),
         ));
    }
}
