<?php

namespace Api\Form;

class SearchForm extends CommonElementForm
{
    public function __construct() {
        parent::__construct('interest_form',true,true);
        $this->setInputFilter(new SearchInputFilter());

        $this->add(array(
            'name' => 'search_txt',
            'type' => 'Text',
            'options' => array(
                'label' => 'Search Text',
            ),
            'attributes' => array(
                'placeholder' => 'Search Text',
                'class'=>'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'latitude',
            'type' => 'Text',
            'options' => array(
                'label' => 'Latitude',
            ),
            'attributes' => array(
                'placeholder' => 'Latitude',
                'class'=>'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'longitude',
            'type' => 'Text',
            'options' => array(
                'label' => 'Longitude',
            ),
            'attributes' => array(
                'placeholder' => 'Longitude',
                'class'=>'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'distance_radius',
            'type' => 'Text',
            'options' => array(
                'label' => 'Distance Radius',
            ),
            'attributes' => array(
                'placeholder' => 'Distance Radius',
                'class'=>'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'page',
            'type' => 'Text',
            'options' => array(
                'label' => 'Page',
            ),
            'attributes' => array(
                'placeholder' => 'Page',
                'class'=>'form-control',
            ),
        ));
    }
}
