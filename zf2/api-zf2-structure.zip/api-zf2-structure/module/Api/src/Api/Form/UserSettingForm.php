<?php

namespace Api\Form;

class UserSettingForm extends CommonElementForm {

    public function __construct($request_type = '') {
        parent::__construct('usersetting_form', true, true);
        $this->setAttribute('enctype', 'multipart/form-data');
        $this->setInputFilter(new UserSettingInputFilter($request_type));
        $this->add(array(
            'name' => 'request_type',
            'type' => 'Text',
            'options' => array(
                'label' => 'Request Type',
            ),
            'attributes' => array(
                'placeholder' => 'Request Type',
                'class' => 'form-control',
            ),
        ));

        if ($request_type == 'update') {
            
        }

        if ($request_type == 'updateVentureId') {
            $this->add(array(
                'name' => 'ventureId'
                , 'type' => 'Text'
                , 'options' => array(
                    'label' => 'Venture Id',
                )
            ));
        }
        if ($request_type == 'updateEmail' || $request_type == 'changeEmail') {
            $this->add(array(
                'name' => 'email'
                , 'type' => 'Text'
                , 'options' => array(
                    'label' => 'email',
                )
            ));
            $this->add(array(
                'name' => 'password'
                , 'type' => 'Text'
                , 'options' => array(
                    'label' => 'Password',
                )
            ));
        }
        
        if($request_type == 'changeEmail'){
            $this->add(array(
                'name' => 'newemail'
                , 'type' => 'Text'
                , 'options' => array(
                    'label' => 'newemail',
                )
            ));
            
        }
        if ($request_type == 'updatePhone') {
            $this->add(array(
                'name' => 'phone'
                , 'type' => 'Text'
                , 'options' => array(
                    'label' => 'phone',
                )
            ));
            $this->add(array(
                'name' => 'newphone'
                , 'type' => 'Text'
                , 'options' => array(
                    'label' => 'phone',
                )
            ));
        }
        if ($request_type == 'changePassword') {
            $this->add(array(
                'name' => 'oldpassword'
                , 'type' => 'Text'
                , 'options' => array(
                    'label' => 'Old Password',
                )
            ));
            $this->add(array(
                'name' => 'newpassword'
                , 'type' => 'Text'
                , 'options' => array(
                    'label' => 'New Password',
                )
            ));
            $this->add(array(
                'name' => 'confirmpassword'
                , 'type' => 'Text'
                , 'options' => array(
                    'label' => 'Confirm Password',
                )
            ));
        }
    }

}
