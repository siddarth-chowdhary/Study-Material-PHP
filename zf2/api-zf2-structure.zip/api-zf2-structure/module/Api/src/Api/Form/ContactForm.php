<?php

namespace Api\Form;

class ContactForm extends CommonElementForm
{
    public function __construct() {
        parent::__construct('contact_form',true,true);
        $this->setInputFilter(new ContactInputFilter());

        $this->add(array(
            'name' => 'search_txt',
            'type' => 'Text',
            'options' => array(
                'label' => 'Search Text',
            ),
            'attributes' => array(
                'placeholder' => 'Search Text',
                'class'=>'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'request_type',
            'type' => 'Text',
            'options' => array(
                'label' => 'Request Type',
            ),
            'attributes' => array(
                'placeholder' => 'Request Type',
                'class'=>'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'limit_per_page',
            'type' => 'Text',
            'options' => array(
                'label' => 'Limit Per Page',
            ),
            'attributes' => array(
                'placeholder' => 'Limit Per Page',
                'class'=>'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'userIds',
            'type' => 'Text',
            'options' => array(
                'label' => 'User Ids',
            ),
            'attributes' => array(
                'placeholder' => 'User Ids',
                'class'=>'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'page',
            'type' => 'Text',
            'options' => array(
                'label' => 'Page',
            ),
            'attributes' => array(
                'placeholder' => 'Page',
                'class'=>'form-control',
            ),
        ));
    }
}
