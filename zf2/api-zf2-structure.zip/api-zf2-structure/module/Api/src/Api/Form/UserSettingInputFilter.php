<?php

namespace Api\Form;

class UserSettingInputFilter extends CommonInputFilter {

    public function __construct($request_type) {
        parent::__construct();

        $this->add(array(
            'name' => 'request_type',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Request Type',
            ),
            'validators' => array(
                array(
                    'name' => 'NotEmpty',
                    'break_chain_on_failure' => true,
                    'options' => array(
                        'message' => 'Request Type is required',
                    ),
                ),
            ),
        ));
        // var_dump(($request_type == 'updateVentureId'));die;
        if ($request_type == 'updateVentureId') {
            $this->add(array(
                'name' => 'ventureId',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Venture Id',
                ),
                'validators' => array(
                    array(
                        'name' => 'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'message' => 'Venture Id is required',
                        ),
                    ),
                    array(
                        'name' => 'StringLength'
                        , 'break_chain_on_failure' => true
                        , 'options' => array(
                            'min' => 6
                            , 'max' => 20
                            , 'message' => 'Venture Id should contains 6-20 charactors long'
                        )
                    ),
                ),
            ));
        }
        if ($request_type == 'updateEmail' || $request_type == 'changeEmail') {
            $this->add(array(
                'name' => 'email',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Email',
                ),
                'validators' => array(
                    array(
                        'name' => 'EmailAddress'
                        , 'break_chain_on_failure' => true
                        , 'options' => array(
                            'message' => 'Please Enter Valid Email Id'
                        )
                    ),
                ),
            ));

            $this->add(array(
                'name' => 'password',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Password',
                ),
            ));
        }

        if ($request_type == 'changeEmail') {
            $this->add(array(
                'name' => 'newemail',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'New Email',
                ),
                'validators' => array(
                    array(
                        'name' => 'EmailAddress'
                        , 'break_chain_on_failure' => true
                        , 'options' => array(
                            'message' => 'Please Enter Valid New Email Id'
                        )
                    ),
                /* array(
                  'name' => 'Identical',
                  'options' => array(
                  'token' => 'email', // name of first email field
                  'message' => 'Current email and new email should be same'
                  ),
                  ), */
                ),
            ));
        }
        if ($request_type == 'updatePhone') {
            $this->add(array(
                'name' => 'phone',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'phone',
                ),
                'validators' => array(
                    array(
                        'name' => 'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'message' => 'Phone is required',
                        ),
                    ),
                    array(
                        'name' => 'regex'
                        , 'options' => array(
                            'pattern' => '/\+(9[976]\d|8[987530]\d|6[987]\d|5[90]\d|42\d|3[875]\d|2[98654321]\d|9[8543210]|8[6421]|6[6543210]|5[87654321]|4[987654310]|3[9643210]|2[70]|7|1)-\d{1,11}$/'
                            , 'message' => 'Phone is not valid please input correct format ( like +1-1111111111)',
                        ),
                    ),
                ),
            ));
            $this->add(array(
                'name' => 'newphone',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'New Phone',
                ),
                'validators' => array(
                    array(
                        'name' => 'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'message' => 'New Phone is required',
                        ),
                    ),
                    array(
                        'name' => 'regex'
                        , 'options' => array(
                            'pattern' => '/\+(9[976]\d|8[987530]\d|6[987]\d|5[90]\d|42\d|3[875]\d|2[98654321]\d|9[8543210]|8[6421]|6[6543210]|5[87654321]|4[987654310]|3[9643210]|2[70]|7|1)-\d{1,11}$/'
                            , 'message' => 'Phone is not valid please input correct format ( like +1-1111111111)',
                        ),
                    ),
                ),
            ));
        }

        if ($request_type == 'changePassword') {
            $this->add(array(
                'name' => 'oldpassword',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Old Password',
                ),
                'validators' => array(
                    array(
                        'name' => 'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'message' => 'Old password is required',
                        ),
                    ),
                    array(
                        'name' => 'StringLength'
                        , 'break_chain_on_failure' => true
                        , 'options' => array(
                            'min' => 6
                            , 'max' => 50
                            , 'message' => 'Password should contains 6-50 charactors long'
                        )
                    ),
                ),
            ));
            $this->add(array(
                'name' => 'newpassword',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'New Password',
                ),
                'validators' => array(
                    array(
                        'name' => 'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'message' => 'New password is required',
                        ),
                    ),
                    array(
                        'name' => 'StringLength'
                        , 'break_chain_on_failure' => true
                        , 'options' => array(
                            'min' => 6
                            , 'max' => 50
                            , 'message' => 'Password should contains 6-50 charactors long'
                        )
                    ),
                ),
            ));
            $this->add(array(
                'name' => 'confirmpassword',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Confirm Password',
                ),
                'validators' => array(
                    array(
                        'name' => 'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'message' => 'Confirm password is required',
                        ),
                    ),
                    array(
                        'name' => 'StringLength'
                        , 'break_chain_on_failure' => true
                        , 'options' => array(
                            'min' => 6
                            , 'max' => 50
                            , 'message' => 'Password should contains 6-50 charactors long'
                        )
                    ),
                    array(
                        'name' => 'Identical',
                        'options' => array(
                            'token' => 'newpassword' // name of first password field
                            , 'message' => 'New password and confirm password should be same'
                        ),
                    ),
                ),
            ));
        }
    }

}
