<?php
namespace Api\Form;

use Zend\InputFilter\InputFilter;

class ResetForgotPasswordInputFilter extends InputFilter {
    public function __construct() {

         $this->add(array(
                'name' => 'phone',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Phone',
                ),
                'validators' => array(
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'Phone is required',
                        ),
                    ),
                    array(
                        'name' => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min' => 8,
                            'max' => 15,
                            'message' => 'Phone must be min 8 characters long',
                        ),
                    ),
                ),
        ));
         $this->add(array(
                'name' => 'security_code',
                'required' => true,
                'filters' => array(
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Security Code',
                ),
                'validators' => array(
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'Security Code is required',
                        ),
                    ),
                    array(
                        'name' => 'StringLength',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min' => 6,
                            'max' => 6,
                            'message' => 'Security Code must be 6 characters long',
                        ),
                    ),
                ),
        ));
         $this->add(array(
                'name' => 'new_password',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'New Password',
                ),
                'validators' => array(
                    array(
                        'name' => 'StringLength',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min' => 5,
                            'max' => 20,
                            'message' => 'Password length should be between 5-20 charactor long',
                        ),
                    ),
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'New Password is required',
                        ),
                    ),
                ),
        ));
         $this->add(array(
                'name' => 'confirm_password',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Confirm Password',
                ),
                'validators' => array(
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'Confirm Password is required',
                        ),
                    ),
                    array(
                        'name' => 'Identical',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'token' => 'new_password', // name of first password field
                            'message'=>'new password and confirm password should be same'
                        ),
                    ),
                ),
        ));
    }
}
