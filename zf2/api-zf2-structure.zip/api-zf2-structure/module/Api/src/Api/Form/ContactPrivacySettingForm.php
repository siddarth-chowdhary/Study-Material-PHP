<?php

namespace Api\Form;

class ContactPrivacySettingForm extends CommonElementForm
{
    public function __construct($request_type = '') {
        parent::__construct('contact_privacy_setting_form',true,true);
        $this->setAttribute('enctype','multipart/form-data'); 
        $this->setInputFilter(new ContactPrivacySettingFilter($request_type));
        $this->add(array(
            'name' => 'request_type',
            'type' => 'Text',
            'options' => array(
                'label' => 'Request Type',
            ),
            'attributes' => array(
                'placeholder' => 'Request Type',
                'class'=>'form-control',
            ),
        ));
        
        $this->add(array( 
            'name' => 'colName', 
            'type' => 'Zend\Form\Element\Text', 
            'options' => array( 
                'label' => 'Column Name',
            ),
        ));
        
        $this->add(array( 
            'name' => 'colValue', 
            'type' => 'Zend\Form\Element\Text', 
            'options' => array( 
                'label' => 'Column Value',
            ),
        ));
        
    }
}
