<?php
namespace Api\Form;

use Zend\InputFilter\InputFilter;

class CommonInputFilter extends InputFilter
{
    public function __construct() {
        $this->add(array(
                'name' => 'user_name',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'user Name',
                ),
                'validators' => array(
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'User Name is required',
                        ),
                    ),
                    array(
                        'name' => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min' => 6,
                            'max' => 20,
                            'message' => 'The input should be 6-20 characters long',
                        ),
                    ),
                ),
        ));
        $this->add(array(
                    'name' => 'password_token',
                    'required' => true,
                     'filters'  => array(
                        array('name' => 'StringTrim'),
                    ),
                    'options' => array(
                        'label' => 'Password Token',
                    ),
            'validators' => array(
                array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'Password Token is required',
                        ),
                    ),
                array(
                    'name' => 'StringLength',
                    'options' => array(
                        'encoding' => 'UTF-8',
                        'min' => 40, // its min size of sha1 hash string. actually sha1 will create hash string of length 40
                        'max' => 50, // but for precaution we are taking 10 more length
                        'message' => 'The input should be 40-50 characters long',
                    ),
                ),
            ),
        ));
     }
}
