<?php
namespace Api\Form;

class SearchInputFilter extends CommonInputFilter
{
    public function __construct() {
        parent::__construct();
        $this->add(array(
                'name' => 'search_txt',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Search Text',
                ),
                'validators' => array(
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'Search Text is required',
                        ),
                    ),
                ),
        ));
        $this->add(array(
                'name' => 'latitude',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Latitude',
                ),
                'validators' => array(
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'Latitude is required',
                        ),
                    ),
                    array(
                        'name'=>'Float',
                        'options'=>array(
                            'message'=>'Latitude should contains float/real values'
                        )
                    )
                ),
        ));
        $this->add(array(
                'name' => 'longitude',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Longitude',
                ),
                'validators' => array(
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'Longitude is required',
                        ),
                    ),
                    array(
                        'name'=>'Float',
                        'options'=>array(
                            'message'=>'Longitude should contains float/real values'
                        )
                    )
                ),
        ));
        $this->add(array(
                'name' => 'distance_radius',
                'required' => false,
                'filters' => array(
                    array('name' => 'int'),
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Longitude',
                ),
                'validators' => array(
                    array(
                        'name'=>'Int',
                        'options'=>array(
                            'message'=>'Distance should contains integer values only'
                        )
                    )
                ),
        ));
        $this->add(array(
                'name' => 'page',
                'required' => false,
                'filters' => array(
                    array('name' => 'int'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Page',
                ),
                'validators' => array(
                    array(
                        'name'=>'Int',
                        'options'=>array(
                            'message'=>'Page should contains integer values only'
                        )
                    )
                ),
        ));
     }
}
