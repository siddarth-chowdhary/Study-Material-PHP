<?php
namespace Api\Form;

class InterestInputFilter extends CommonInputFilter
{
    public function __construct() {
        parent::__construct();
        $this->add(array(
                'name' => 'interests',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'interest',
                ),
                'validators' => array(
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'Interest is required',
                        ),
                    ),
                ),
        ));
     }
}
