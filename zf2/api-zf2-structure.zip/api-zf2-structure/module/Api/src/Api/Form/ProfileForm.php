<?php

namespace Api\Form;

class ProfileForm extends CommonElementForm
{
    public function __construct($request_type = '') {
        parent::__construct('profile_form',true,true);
        $this->setAttribute('enctype','multipart/form-data'); 
        $this->setInputFilter(new ProfileInputFilter($request_type));
        $this->add(array(
            'name' => 'request_type',
            'type' => 'Text',
            'options' => array(
                'label' => 'Request Type',
            ),
            'attributes' => array(
                'placeholder' => 'Request Type',
                'class'=>'form-control',
            ),
        ));
        
        if($request_type == 'update') {
            
        }
        if($request_type=='updateProfileImage'){
            $this->add(array(
                'name'     => 'profilePic'
                ,'type'=>'file'
                ,'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                )
                 ,'options' => array(
                    'label' => 'profilePic Name',
                ),
                'validators'=>array()
             ));
        }
    }
}
