<?php
namespace Api\Form;
use Zend\Form\Form;
class ResetForgotPasswordForm extends Form {
    public function __construct($updateForm = false) {

        parent::__construct("reset_forgot_password_Form");
        $this->setAttribute('method', 'post');
        $this->setInputFilter(new ResetForgotPasswordInputFilter());
        $this->add(array(
            'name' => 'phone',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Phone',
            ),
            'attributes' => array(
                'placeholder' => 'Phone',
                'class' => 'form-control',
            ),
        ));

        $this->add(array(
            'name' => 'security_code',
            'filters' => array(
                array('name' => 'int')
            ),
            'options' => array(
                'label' => 'Security Code',
            ),
            'attributes' => array(
                'placeholder' => 'Security Code',
                'class' => 'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'new_password',
            'type' => 'Zend\Form\Element\Password',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'New Password',
            ),
            'attributes' => array(
                'placeholder' => 'New Password',
                'class' => 'form-control',
            ),
        ));
        $this->add(array(
            'name' => 'confirm_password',
            'type' => 'Zend\Form\Element\Password',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Confirm Password',
            ),
            'attributes' => array(
                'placeholder' => 'Confirm Password',
                'class' => 'form-control',
            ),
        ));
    }
}
