<?php

namespace Api\Form;

class ListProjectForm extends CommonElementForm
{
    public function __construct() {
        parent::__construct('list_profile_form',true,true);
        $this->setAttribute('enctype','multipart/form-data'); 
        $this->setInputFilter(new ListProjectInputFilter());
    }
}
