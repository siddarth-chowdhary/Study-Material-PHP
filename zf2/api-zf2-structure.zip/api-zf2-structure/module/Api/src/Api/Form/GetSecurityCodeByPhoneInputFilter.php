<?php
namespace Api\Form;

use Zend\InputFilter\InputFilter;

class GetSecurityCodeByPhoneInputFilter extends InputFilter {
    public function __construct() {

         $this->add(array(
                'name' => 'phone',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Phone',
                )
        ));
        
    }
}
