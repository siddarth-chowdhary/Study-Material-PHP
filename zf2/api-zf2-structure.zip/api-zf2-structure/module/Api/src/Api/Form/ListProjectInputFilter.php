<?php

namespace Api\Form;

class ListProjectInputFilter extends CommonInputFilter {

    public function __construct() {
        parent::__construct();
    }
}
