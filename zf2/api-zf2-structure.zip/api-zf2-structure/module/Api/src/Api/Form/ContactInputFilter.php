<?php
namespace Api\Form;

class ContactInputFilter extends CommonInputFilter
{
    public function __construct($userIds = false) {
        parent::__construct();
        
        $this->add(array(
                'name' => 'request_type',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Request Type',
                ),
                'validators' => array(
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'Request Type is required',
                        ),
                    ),
                ),
        ));
        
        
        $this->add(array(
                'name' => 'search_txt',
                'required' => false,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Search Text',
                ),
                'validators' => array(),
        ));
        $this->add(array(
                'name' => 'limit_per_page',
                'required' => false,
                'filters' => array(
                    array('name' => 'int'),
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Limit Per Page',
                ),
                'validators' => array(
                    array(
                        'name'=>'Int',
                        'options'=>array(
                            'message'=>'Limit Per Page should contains only digits'
                        )
                    )
                ),
        ));
        $this->add(array(
                'name' => 'userIds',
                'required' => $userIds,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'User Ids',
                ),
                'validators' => array(
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'User Ids is required',
                        ),
                    ),
                ),
        ));
        $this->add(array(
                'name' => 'page',
                'required' => false,
                'filters' => array(
                    array('name' => 'int'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Page',
                ),
                'validators' => array(
                    array(
                        'name'=>'Int',
                        'options'=>array(
                            'message'=>'Page should contains integer values only'
                        )
                    )
                ),
        ));
     }
}
