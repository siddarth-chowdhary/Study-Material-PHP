<?php
namespace Api\Form;

use Zend\Form\Form;

class ForgotPasswordForm extends CommonElementForm {
    public function __construct($updateForm = false) {

        parent::__construct('forgot_password',true,true);
        $this->setAttribute('method', 'post');
        
        $this->add(array(
            'name' => 'phone',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Phone',
            ),
            'attributes' => array(
                'placeholder' => 'Phone',
                'class' => 'form-control',
            ),
        ));

        $this->add(array(
            'name' => 'securityCode',
            'type' => 'Zend\Form\Element\Password',
            'required' => true,
            'filters' => array(
                array('name' => 'int')
            ),
            'options' => array(
                'label' => 'Security Code',
            ),
            'attributes' => array(
                'placeholder' => 'Security Code',
                'class' => 'form-control',
            ),
        ));
    }
}
