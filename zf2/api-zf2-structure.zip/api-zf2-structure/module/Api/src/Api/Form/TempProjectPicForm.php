<?php
namespace Api\Form;
use Zend\Form\Form;
class TempProjectPicForm extends CommonElementForm {
    public function __construct() {
        parent::__construct("temp_project_pic_Form",true,true);
        $this->setAttribute('method', 'post');        
        $this->setAttribute('class', 'form-inline');
        $this->setAttribute('role', 'form');
        $this->setAttribute('enctype','multipart/form-data'); 
        $this->setInputFilter(new TempProjectPicInputFilter());       
        
        
        $this->add(array(
            'name' => 'tempId',
            'type' => 'Zend\Form\Element\Text',
            'required' => false,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Temp Id',
                'id' => 'tempId',
                'class'=>'form-control',
            ),
            'options' => array(
                'label' => 'Temp Id',
            ),
        ));
        
        $this->add(array(
            'name' => 'tempProjectId',
            'type' => 'Zend\Form\Element\Hidden',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'Temp Project Id',
                'id' => 'tempProjectId',
                'class'=>'form-control',
            ),
            'options' => array(
                'label' => 'Temp Project Id',
            ),
        ));
        
        $this->add(array(
            'name' => 'imageName',
            'type' => 'Zend\Form\Element\File',
            'required' => true,
            'options' => array(
                'label' => 'Upload Project Image',
            ),
            'attributes' => array(                
                'id' => 'imageName',
                //'class'=>'form-control',                
            ),
            
        ));
    }
}
