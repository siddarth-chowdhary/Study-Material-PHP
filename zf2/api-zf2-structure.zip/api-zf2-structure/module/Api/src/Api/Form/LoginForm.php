<?php
namespace Api\Form;

use Zend\Form\Form;

class LoginForm extends Form {
    public function __construct($updateForm = false) {

        parent::__construct("verify_Form");
        $this->setAttribute('method', 'post');
        
        $this->add(array(
            'name' => 'user_name',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'User Name',
            ),
        ));

        $this->add(array(
            'name' => 'password',
            'type' => 'Zend\Form\Element\Password',
            'required' => true,
            'filters' => array(
                array('name' => 'int')
            ),
            'options' => array(
                'label' => 'Password',
            ),
        ));
    }
}
