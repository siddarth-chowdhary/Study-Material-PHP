<?php

namespace Api\Form;

class ProjectRequestForm extends CommonElementForm
{
    public function __construct($request_type = '') {
        parent::__construct('project_request_form',true,true);
        $this->setAttribute('enctype','multipart/form-data'); 
        $this->setInputFilter(new ProjectRequestFilter($request_type));
        $this->add(array(
            'name' => 'request_type',
            'type' => 'Text',
            'options' => array(
                'label' => 'Request Type',
            ),
            'attributes' => array(
                'placeholder' => 'Request Type',
                'class'=>'form-control',
            ),
        ));
        
        $this->add(array( 
            'name' => 'projectId', 
            'type' => 'Zend\Form\Element\Text', 
            'options' => array( 
                'label' => 'Project Id',
            ),
        ));
        
        $this->add(array( 
            'name' => 'userId', 
            'type' => 'Zend\Form\Element\Text', 
            'options' => array( 
                'label' => 'User Id',
            ),
        ));
        
    }
}
