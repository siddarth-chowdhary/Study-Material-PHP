<?php
namespace Api\Form;

use Zend\Form\Form;

class FbForm extends Form
{
    public function __construct() {
        parent::__construct('fb_form');
        $this->setAttribute('enctype','multipart/form-data'); 
        $this->setInputFilter(new FbFormInputFilter());
        $this->add(array(
            'name' => 'email',
            'type' => 'Text',
            'options' => array(
                'label' => 'Email',
            )
        ));
        $this->add(array(
            'name' => 'phone',
            'type' => 'Text',
            'options' => array(
                'label' => 'Phone',
            )
        ));
        $this->add(array(
            'name' => 'password',
            'type' => 'Text',
            'options' => array(
                'label' => 'Password',
            )
        ));
        $this->add(array(
            'name' => 'firstName',
            'type' => 'Text',
            'options' => array(
                'label' => 'First Name',
            )
        ));
        $this->add(array(
            'name' => 'lastName',
            'type' => 'Text',
            'options' => array(
                'label' => 'Lirst Name',
            )
        ));
        $this->add(array(
            'name' => 'gender',
            'type' => 'Text',
            'options' => array(
                'label' => 'Gender',
            )
        ));
        $this->add(array(
            'name' => 'address',
            'type' => 'Text',
            'options' => array(
                'label' => 'Address',
            )
        ));
        $this->add(array(
            'name' => 'state',
            'type' => 'Text',
            'options' => array(
                'label' => 'State',
            )
        ));
        $this->add(array(
            'name' => 'countryiso',
            'type' => 'Text',
            'options' => array(
                'label' => 'Country',
            )
        ));
        $this->add(array(
            'name' => 'latitude',
            'type' => 'Text',
            'options' => array(
                'label' => 'Latitude',
            )
        ));
        $this->add(array(
            'name' => 'longitude',
            'type' => 'Text',
            'options' => array(
                'label' => 'Longitude',
            )
        ));
    }
}
