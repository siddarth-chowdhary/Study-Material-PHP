<?php
namespace Api\Form;

use Zend\Form\Form;

class CommonElementForm extends Form
{
    public function __construct($formName='my_form',$user_name=false,$password_token=false) {

        parent::__construct($formName);
        $this->add(array(
            'name' => 'user_name',
            'type' => 'Zend\Form\Element\Text',
            'required' => $user_name,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'User Name',
            )
        ));
        
        $this->add(array(
            'name' => 'password_token',
            'type' => 'Zend\Form\Element\Text',
            'required' => $password_token,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Password Token',
            ),
            'attributes' => array(
                'placeholder' => 'Password Token',
            )
        ));
    }
}
