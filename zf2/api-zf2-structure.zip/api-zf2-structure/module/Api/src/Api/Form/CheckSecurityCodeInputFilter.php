<?php
namespace Api\Form;

use Zend\InputFilter\InputFilter;

class CheckSecurityCodeInputFilter extends InputFilter {
    public function __construct() {

         $this->add(array(
                'name' => 'phone',
                'required' => true,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Phone',
                ),
                'validators' => array(
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'Phone is required',
                        ),
                    ),
                    array(
                        'name' => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min' => 8,
                            'max' => 15,
                            'message' => 'Phone must be min 8 characters long',
                        ),
                    ),
                ),
        ));
         $this->add(array(
                'name' => 'security_code',
                'required' => true,
                'filters' => array(
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Security Code',
                ),
                'validators' => array(
                    array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options'=>array(
                            'message' => 'Security Code is required',
                        ),
                    ),
                    array(
                        'name' => 'StringLength',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min' => 6,
                            'max' => 6,
                            'message' => 'Security Code must be 6 characters long',
                        ),
                    ),
                ),
        ));
    }
}
