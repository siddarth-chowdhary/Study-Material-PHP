<?php

namespace Api\Form;

class InterestForm extends CommonElementForm
{
    public function __construct() {
        parent::__construct('interest_form',true,true);
        $this->setInputFilter(new InterestInputFilter());

        $this->add(array(
            'name' => 'interests',
            'type' => 'Text',
            'options' => array(
                'label' => 'Interest',
            ),
            'attributes' => array(
                'placeholder' => 'Interest',
                'class'=>'form-control',
            ),
        ));
    }
}
