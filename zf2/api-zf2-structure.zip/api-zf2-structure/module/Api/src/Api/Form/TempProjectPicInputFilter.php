<?php
namespace Api\Form;

use Zend\InputFilter\InputFilter;

class TempProjectPicInputFilter extends CommonInputFilter {
    public function __construct() {
        parent::__construct();
        $this->add(array(
                 'name'     => 'tempId',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'Int'),
                 ),
             ));
             $this->add(array(
                'name'     => 'tempProjectId',
                'required' => true,
                'filters'  => array(
                    array('name' => 'Int'),
                ),
                'options' => array(
                    'label' => 'Temp Project Id',
                ),
             ));

             $this->add(array(
                 'name'     => 'imageName',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'options' => array(
                    'label' => 'Image Name',
                ),
             ));
        
    }
}
