<?php

namespace Api\Form;

class CreateProjectInputFilter extends CommonInputFilter {

    public function __construct() {
        parent::__construct();

        $this->add(array(
            'name' => 'projectName',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Project Name',
            ),
            'validators' => array(
                array(
                    'name' => 'NotEmpty',
                    'break_chain_on_failure' => true,
                    'options' => array(
                        'message' => 'Project Name is required',
                    ),
                ),
                array(
                    'name'=>'StringLength'
                    ,'options'=>array(
                        'encoding' => 'UTF-8'
                        ,'min'=>3
                        ,'max'=>50
                        ,'message'=>'Project name must be of 3-50 charactor long'
                    )
                )
            ),
        ));
        $this->add(array(
            'name' => 'projectDetail',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Project Detail',
            ),
            'validators' => array(
                array(
                    'name' => 'NotEmpty',
                    'break_chain_on_failure' => true,
                    'options' => array(
                        'message' => 'Project Detail is required',
                    ),
                ),
            ),
        ));
        $this->add(array(
            'name' => 'projectVisibility',
            'required' => true,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'options' => array(
                'label' => 'Project Visibility',
            ),
            'validators' => array(
                array(
                    'name' => 'NotEmpty',
                    'break_chain_on_failure' => true,
                    'options' => array(
                        'message' => 'Project Visibility is required',
                    ),
                ),
                array(
                    'name'=>'Zend\Validator\Digits'
                    ,'break_chain_on_failure' => true
                    ,'options'=>array(
                        'message'=>'Project Visibility must contains digits'
                    )
                )
            ),
        ));
        $this->add(array(
            'name' => 'lockProjectDetail',
            'required' => true,
            'filters' => array(
                array('name' => 'Int')
            ),
            'options' => array(
                'label' => 'Lock Project Detail',
            ),
            'validators' => array(
                array(
                    'name' => 'NotEmpty',
                    'break_chain_on_failure' => true,
                    'options' => array(
                        'message' => 'Lock Project Detail is required',
                    ),
                ),
                array(
                    'name'=>'Zend\Validator\Digits'
                    ,'options'=>array(
                        'message'=>'Lock Project Detail must contains digits'
                    )
                )
            ),
        ));
        $this->add(array(
            'name' => 'tempProjectId',
            'required' => false,
            'filters' => array(
                array('name' => 'Int')
            ),
            'options' => array(
                'label' => 'Temp Project Id',
            ),
            /*'validators' => array(
                array(
                    'name' => 'NotEmpty',
                    'break_chain_on_failure' => true,
                    'options' => array(
                        'message' => 'Lock Project Detail is required',
                    ),
                ),
                array(
                    'name'=>'Zend\Validator\Digits'
                    ,'options'=>array(
                        'message'=>'Lock Project Detail must contains digits'
                    )
                )
            ),*/
        ));
    }

}
