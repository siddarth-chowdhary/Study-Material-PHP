<?php

namespace Api\Form;

class ProfileInputFilter extends CommonInputFilter {

    public function __construct($request_type = null) {
        parent::__construct();

        $this->add(array(
            'name' => 'request_type',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Request Type',
            ),
            'validators' => array(
                array(
                    'name' => 'NotEmpty',
                    'break_chain_on_failure' => true,
                    'options' => array(
                        'message' => 'Request Type is required',
                    ),
                ),
            ),
        ));

        if ($request_type == 'update') {
            
        }
        if ($request_type == 'updateProfileImage') {
            $this->add(array(
                'name' => 'profilePic',
                'required' => false,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'profilePic Name',
                )
                ,'validators' => array(
                     array(
                        'name'=>'NotEmpty',
                        'break_chain_on_failure' => true,
                        'options' => array(
                            'message' => 'Profile pic is required',
                        ),
                     )
                     ,array(
                        'name'=>'Zend\Validator\File\UploadFile'
                        ,'break_chain_on_failure' => true
                        ,'options'=>array(
                            'message'=>'Pfofile Pic is required'
                        )
                     ),
                )
            ));
        }
    }

}
