<?php
namespace Api\Form;

use Zend\Form\Form;

class RegisterForm extends Form {
    public function __construct($updateForm = false) {

        parent::__construct("User_Form");
        $this->setAttribute('method', 'post');
        
        $this->add(array(
            'name' => 'userId',
            'type' => 'Zend\Form\Element\Hidden',
            'required' => false,
            'filters' => array(
                array('name' => 'Int'),
            ),
            'attributes' => array(
                'placeholder' => 'User Id',
                'id' => 'userId',
                'class' => 'form-control',
            ),
            'options' => array(
                'label' => 'User Id',
            ),
        ));

        $this->add(array(
            'name' => 'user_name',
            'type' => 'Zend\Form\Element\Text',
            'required' => ($updateForm === true) ? true : false,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'User Name',
            )
        ));
        
        $this->add(array(
            'name' => 'password_token',
            'type' => 'Zend\Form\Element\Text',
            'required' => ($updateForm === true) ? true : false,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Password Token',
            ),
            'attributes' => array(
                'placeholder' => 'Password Token',
            )
        ));

        $this->add(array(
            'name' => 'firstName',
            'type' => 'Zend\Form\Element\Text',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
                array('name' => 'alpha')
            ),
            'options' => array(
                'label' => 'First Name',
            ),
            'attributes' => array(
                'placeholder' => 'First Name',
                'id' => 'firstName',
                'class' => 'form-control',
            ),
        ));
        
        $this->add(array(
            'name' => 'lastName',
            'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Last Name',
            ),
            'attributes' => array(
                'placeholder' => 'Last Name',
                'id' => 'lastName',
                'class' => 'form-control',
            ),
        ));
        
        $this->add(array(
            'name' => 'phone',
            'required' => false,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Phone',
            ),
            'attributes' => array(
                'placeholder' => 'Phone',
                'class' => 'form-control',
            ),
        ));
        
        $this->add(array(
                'name' => 'latitude',
                'required' => false,
                'filters' => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'options' => array(
                    'label' => 'Latitude',
                ),
            ));
        $this->add(array(
            'name' => 'longitude',
            //'required' => true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Longitude',
            ),
        ));
        
        
        $this->add(array(
            'name' => 'password',
            'type' => 'Zend\Form\Element\Password',
            'required' => ($updateForm === true) ? false : true,
            'filters' => array(
                array('name' => 'StripTags'),
                array('name' => 'StringTrim'),
            ),
            'options' => array(
                'label' => 'Password',
            ),
            'attributes' => array(
                'placeholder' => 'Password',
                'id' => 'password',
                'autocomplete' => 'off',
                'value' => "",
                'class' => 'form-control',
            ),
        ));
    }
}
