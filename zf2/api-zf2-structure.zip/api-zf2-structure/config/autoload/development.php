<?php

/**
 * Local Configuration Override
 *
 * This configuration override file is for overriding environment-specific and
 * security-sensitive configuration information. Copy this file without the
 * .dist extension at the end and populate values as needed.
 *
 * @NOTE: This file is ignored from Git by default with the .gitignore included
 * in ZendSkeletonApplication. This is a good practice, as it prevents sensitive
 * credentials from accidentally being committed into version control.
 */
return array(
    'db' => array(
        'username' => 'clavax',
        'password' => 'tech',
        'dsn' => 'mysql:dbname=storyBoard;host=192.168.2.129',
    ),
    'convert_path' => 'convert',
    'document_root' => $_SERVER['DOCUMENT_ROOT'],
    'http_host' => $_SERVER['HTTP_HOST'],
    'Twilio' => array(
        'sid' => 'ACeb9c02ed91778472cbd55de1f340d69b'
        , 'auth_token' => 'f5a982795495e6e0869383260b0e432c'
        , 'senderNumber' => '(240)575-2043'
    ),
);
