<?php
/**
 * Global Configuration Override
 *
 * You can use this file for overriding configuration values from modules, etc.
 * You would place values in here that are agnostic to the environment and not
 * sensitive to security.
 *
 * @NOTE: In practice, this file will typically be INCLUDED in your source
 * control, so do not include passwords or other sensitive information in this
 * file.
 */

return array(
     'db' => array(
         'driver'         => 'Pdo',
         'driver_options' => array(
             PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
         ),
     ),
     'service_manager' => array(
         'factories' => array(
             //'Zend\Db\Adapter\Adapter'=> 'Zend\Db\Adapter\AdapterServiceFactory',
             'Zend\Db\Adapter\Adapter' => function ($serviceManager) {
                    $adapterFactory = new Zend\Db\Adapter\AdapterServiceFactory();
                    $adapter = $adapterFactory->createService($serviceManager);
                   \Zend\Db\TableGateway\Feature\GlobalAdapterFeature::setStaticAdapter($adapter);
                   return $adapter;
             }
             //'Zend\Db\Adapter\Adapter'   => 'Zend\Db\Adapter\AdapterServiceFactory',
             
         ),
     ),
     'URL' => array(
		'FRONT_URL' =>'//venture-app.in', 
		'API_URL'=> 'http://venture-app.in',
		'FRONT_IMAGE_URL'=> '//venture-app.loc/userImages/',
		
	),
    'project_image_dir'=>'projectImage',
    'earth_radius_miles'=>'3959',
    'earth_radius_km'=>'6371',
    'km_to_mile_difference'=>'0.62',
    'default_map_search_distance'=>'3', // its in km
    'profile_image_dir'=>'profilePic',
    'module_layouts' => array(
        'Admin' => 'layout/layout-admin',
    ),
 );
