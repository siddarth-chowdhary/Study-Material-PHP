<?php
/**
 * Local Configuration Override
 *
 * This configuration override file is for overriding environment-specific and
 * security-sensitive configuration information. Copy this file without the
 * .dist extension at the end and populate values as needed.
 *
 * @NOTE: This file is ignored from Git by default with the .gitignore included
 * in ZendSkeletonApplication. This is a good practice, as it prevents sensitive
 * credentials from accidentally being committed into version control.
 */

return array(
     'db' => array(
         'username' => 'venture',
         'password' => '3dfbYeturymbX8PY',
         'dsn'            => 'mysql:dbname=ventureapp_dev;host=localhost',
     ),
     'convert_path' => '/usr/bin/convert',
     'document_root' => $_SERVER['DOCUMENT_ROOT'].'/ventureapp/public',
     'http_host' => $_SERVER['HTTP_HOST'].'/ventureapp/public',
     'Twilio' => array(
        'sid'=>'AC0921a22bb80b3115680611725b2e3ace'
        ,'auth_token'=>'d9f3a8eb4af21cc5dc334131c71d5030'
        ,'senderNumber'=>'(484) 240-2742'
    ),
 );
