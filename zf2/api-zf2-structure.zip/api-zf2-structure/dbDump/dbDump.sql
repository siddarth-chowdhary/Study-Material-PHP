-- MySQL dump 10.13  Distrib 5.5.38, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.2.129    Database: storyBoard
-- ------------------------------------------------------
-- Server version	5.5.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `album`
--

DROP TABLE IF EXISTS `album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `album` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artist` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album`
--

LOCK TABLES `album` WRITE;
/*!40000 ALTER TABLE `album` DISABLE KEYS */;
INSERT INTO `album` VALUES (1,'sadsa','asddsaere'),(2,'sadsa','sadsa111');
/*!40000 ALTER TABLE `album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat`
--

DROP TABLE IF EXISTS `chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat` (
  `chatId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdDate` datetime NOT NULL,
  PRIMARY KEY (`chatId`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat`
--

LOCK TABLES `chat` WRITE;
/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
INSERT INTO `chat` VALUES (1,'2014-09-01 19:00:31'),(2,'2014-09-01 19:15:50'),(3,'2014-09-01 19:16:48'),(4,'2014-09-02 11:26:39'),(5,'2014-09-02 16:00:56'),(6,'2014-09-02 16:09:22'),(7,'2014-09-02 17:15:15'),(8,'2014-09-25 10:47:40'),(9,'0000-00-00 00:00:00'),(10,'0000-00-00 00:00:00'),(11,'0000-00-00 00:00:00'),(12,'0000-00-00 00:00:00'),(13,'0000-00-00 00:00:00'),(14,'0000-00-00 00:00:00'),(15,'0000-00-00 00:00:00'),(16,'0000-00-00 00:00:00'),(17,'0000-00-00 00:00:00'),(18,'0000-00-00 00:00:00'),(19,'0000-00-00 00:00:00'),(20,'0000-00-00 00:00:00'),(21,'0000-00-00 00:00:00'),(22,'0000-00-00 00:00:00'),(23,'0000-00-00 00:00:00'),(24,'0000-00-00 00:00:00'),(25,'0000-00-00 00:00:00'),(26,'0000-00-00 00:00:00'),(27,'0000-00-00 00:00:00'),(28,'0000-00-00 00:00:00'),(29,'0000-00-00 00:00:00'),(30,'0000-00-00 00:00:00'),(31,'0000-00-00 00:00:00'),(32,'0000-00-00 00:00:00'),(33,'0000-00-00 00:00:00'),(34,'0000-00-00 00:00:00'),(35,'0000-00-00 00:00:00'),(36,'0000-00-00 00:00:00'),(37,'0000-00-00 00:00:00'),(38,'0000-00-00 00:00:00'),(39,'0000-00-00 00:00:00'),(40,'0000-00-00 00:00:00'),(41,'0000-00-00 00:00:00'),(42,'0000-00-00 00:00:00'),(43,'0000-00-00 00:00:00'),(44,'0000-00-00 00:00:00'),(45,'0000-00-00 00:00:00'),(46,'0000-00-00 00:00:00'),(47,'0000-00-00 00:00:00'),(48,'0000-00-00 00:00:00'),(49,'2014-10-06 16:18:51'),(50,'0000-00-00 00:00:00'),(51,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chatUser`
--

DROP TABLE IF EXISTS `chatUser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chatUser` (
  `chatId` int(10) unsigned NOT NULL,
  `userId` int(10) unsigned NOT NULL COMMENT 'Those users which are included in chat including sender',
  `visibility` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Public,2=Private',
  `password` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`chatId`,`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chatUser`
--

LOCK TABLES `chatUser` WRITE;
/*!40000 ALTER TABLE `chatUser` DISABLE KEYS */;
INSERT INTO `chatUser` VALUES (8,130,1,NULL),(8,136,1,NULL),(9,130,1,NULL),(10,130,1,NULL),(11,130,1,NULL),(12,130,1,NULL),(13,130,1,NULL),(14,130,1,NULL),(15,130,1,NULL),(16,130,1,NULL),(17,130,1,NULL),(18,130,1,NULL),(19,130,1,NULL),(20,130,1,NULL),(21,130,1,NULL),(22,130,1,NULL),(23,130,1,NULL),(24,130,1,NULL),(25,130,1,NULL),(26,136,1,NULL),(27,130,1,NULL),(28,136,1,NULL),(29,144,1,NULL),(30,143,1,NULL),(31,130,1,NULL),(32,130,1,NULL),(32,142,1,NULL),(32,143,1,NULL),(32,144,1,NULL),(33,130,1,NULL),(33,142,1,NULL),(33,143,1,NULL),(33,144,1,NULL),(34,130,1,NULL),(34,144,1,NULL),(35,130,1,NULL),(35,142,1,NULL),(35,143,1,NULL),(35,144,1,NULL),(36,130,1,NULL),(36,142,1,NULL),(36,143,1,NULL),(36,144,1,NULL),(37,130,1,NULL),(37,142,1,NULL),(37,143,1,NULL),(37,144,1,NULL),(38,142,1,NULL),(38,143,1,NULL),(39,130,1,NULL),(39,142,1,NULL),(40,130,1,NULL),(40,139,1,NULL),(41,130,1,NULL),(41,136,1,NULL),(41,141,1,NULL),(42,136,1,NULL),(42,137,1,NULL),(42,139,1,NULL),(43,136,1,NULL),(43,139,1,NULL),(44,130,1,NULL),(45,130,1,NULL),(46,130,1,NULL),(47,136,1,NULL),(48,130,1,NULL),(48,136,1,NULL),(48,137,1,NULL),(48,139,1,NULL),(49,47,4,''),(49,50,4,''),(49,55,4,''),(49,58,4,''),(49,60,4,''),(49,83,4,''),(49,86,4,''),(49,106,4,''),(49,121,4,''),(49,129,4,''),(49,130,4,''),(49,144,4,''),(49,151,4,NULL),(50,136,1,NULL),(51,136,1,NULL),(51,137,1,NULL);
/*!40000 ALTER TABLE `chatUser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clearChat`
--

DROP TABLE IF EXISTS `clearChat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clearChat` (
  `userId` int(10) unsigned NOT NULL,
  `chatId` int(10) unsigned NOT NULL,
  `statusId` tinyint(4) NOT NULL DEFAULT '2' COMMENT 'Default clear chat will disable',
  PRIMARY KEY (`userId`,`chatId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clearChat`
--

LOCK TABLES `clearChat` WRITE;
/*!40000 ALTER TABLE `clearChat` DISABLE KEYS */;
/*!40000 ALTER TABLE `clearChat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contactPrivacySetting`
--

DROP TABLE IF EXISTS `contactPrivacySetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contactPrivacySetting` (
  `contactSettingId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userId` int(10) unsigned NOT NULL,
  `contactUserId` int(10) unsigned NOT NULL,
  `hideLinkedin` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes,2=No',
  `hideProject` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes,2=No',
  `hideProfilePhoto` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes,2=No',
  `block` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes,2=No',
  `report` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes,2=No',
  PRIMARY KEY (`contactSettingId`),
  KEY `idx_userId` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactPrivacySetting`
--

LOCK TABLES `contactPrivacySetting` WRITE;
/*!40000 ALTER TABLE `contactPrivacySetting` DISABLE KEYS */;
INSERT INTO `contactPrivacySetting` VALUES (1,151,145,1,1,2,1,1),(9,151,50,1,1,2,1,1),(10,150,129,1,1,2,1,1),(11,130,50,1,1,1,1,1),(12,130,3,1,1,1,1,1),(13,130,126,1,1,1,1,1);
/*!40000 ALTER TABLE `contactPrivacySetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `countryId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `countryCode` varchar(3) DEFAULT NULL,
  `countryIsoCode` varchar(2) DEFAULT NULL,
  `countryName` varchar(60) NOT NULL,
  `countryPhoneCode` int(4) DEFAULT NULL,
  `CapitalCity` varchar(200) NOT NULL,
  `ContinentCode` varchar(20) NOT NULL,
  `CurrencyISOCode` varchar(15) NOT NULL,
  `CountryFlag` varchar(200) NOT NULL,
  `Languages` varchar(20) NOT NULL,
  PRIMARY KEY (`countryId`)
) ENGINE=InnoDB AUTO_INCREMENT=236 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'AND','AD','Andorraa',371,'Andorra La Ville','EU','EUR','Andorra.jpg','cat'),(2,'ARE','AE','United Arab Emirates',971,'Abu Dhabi','AS','AED','United_Arab_Emirates.jpg','ara'),(3,'AFG','AF','Afghanistan',93,'Kabul','AS','AFA','Afghanistan.jpg','pus'),(4,'AIA','AI','Anguilla',264,'The Valley','AM','CAD','Anguilla.jpg',''),(5,'ALB','AL','Albania',355,'Tirana','EU','ALL','Albania.jpg','sq'),(6,'ARM','AM','Armenia',374,'Yerevan','AS','AMD','Armenia.jpg','hy'),(7,'ANT','AN','Netherlands Antilles',599,'Willemstad','AM','ANG','Netherlands_Antilles.jpg',''),(8,'AGO','AO','Angola',244,'Luanda','AF','AOA','Angola.jpg','bnt'),(9,'ATA','AQ','Antarctica',0,'None','AN','Array','Antartica.jpg',''),(10,'ARG','AR','Argentina',54,'Buenos Aires','AM','ARS','Argentina.jpg','es'),(11,'ASM','AS','American Samoa',684,'Pago Pago','OC','USD','American_Samoa.jpg','eng'),(12,'AUT','AT','Austria',43,'Vienna','EU','EUR','Austria.jpg','de'),(13,'AUS','AU','Australia',61,'Canberra','OC','AUD','Australia.jpg','eng'),(14,'ABW','AW','Aruba',297,'Oranjestad','AM','AWG','Aruba.jpg',''),(15,NULL,'AX','Åland Islands',358,'Mariehamn','EU','EUR','Åland_Islands.jpg','sv'),(16,'AZE','AZ','Azerbaijan',994,'Baku','AS','AZM','Azerbaijan.jpg','aze'),(17,'BIH','BA','Bosnia & Herzegovina',387,'Sarajevo','EU','BAM','Bosnia_Herzegovina.jpg','scr'),(18,'BRB','BB','Barbados',1,'Bridgetown','AM','BBD','Barbados.jpg','eng'),(19,'BGD','BD','Bangladesh',880,'Dhaka','AS','BDT','Bangladesh.jpg','ben'),(20,'BEL','BE','Belgium',32,'Brussels','EU','EUR','Belgium.jpg','nl'),(21,'BFA','BF','Burkina Faso',226,'Ouagadougou','AF','XOF','Burkina.jpg','fr'),(22,'BGR','BG','Bulgaria',359,'Sofia','EU','BGN','Bulgaria.jpg','bul'),(23,'BHR','BH','Bahrain',973,'Manama','AS','BHD','Bahrain.jpg','ara'),(24,'BDI','BI','Burundi',257,'Bujumbura','AF','BIF','Burundi.jpg','rn'),(25,'BEN','BJ','Benin',229,'Porto-Novo','AF','XOF','Benin.jpg','fr'),(26,'BMU','BM','Bermuda',441,'Hamilton','AM','BMD','Bermuda.jpg',''),(27,NULL,'BN','Brunei-Darussalam',673,'Bandar Seri Begawan','AS','BND','Brunei-Darussalam.jpg','ms'),(28,'BOL','BO','Bolivia',591,'La Paz','AM','BOB','Bolivia.jpg','es'),(29,'BRA','BR','Brazil',55,'Brasilia','AM','BRL','Brazil.jpg','por'),(30,'BHS','BS','Bahamas',1,'Nassau','AM','BSD','Bahamas.jpg','eng'),(31,'BTN','BT','Bhutan',975,'Timphu','AS','BTN','Bhutan.jpg','dzo'),(32,'BVT','BV','Bouvet Island',578,'None','AN','NOK','Norway.jpg',''),(33,'BWA','BW','Botswana',267,'Gaborone','AF','BWP','Botswana.jpg','eng'),(34,'BLR','BY','Belarus',375,'Minsk','EU','BYR','Belarus.jpg','bel'),(35,'BLZ','BZ','Belize',501,'Belmopan','AM','BZD','Belize.jpg','eng'),(36,'CAN','CA','Canada',1,'Ottawa','AM','CAD','Canada.jpg','eng'),(37,'CCK','CC','Cocos (Keeling) Islands',287,'West Island','OC','AUD','Cocos_Keeling_Islands.jpg',''),(38,NULL,'CD','Congo, Democratic Republic',243,'Kinshasha','AF','XAF','Congo.jpg','fr'),(39,'CAF','CF','Central African Republic',236,'Bangui','AF','XAF','Central.jpg','fr'),(40,'COG','CG','Congo',242,'Brazzerville','AF','CDF','Congo.jpg','fr'),(41,'CHE','CH','Switzerland',41,'Bern','EU','CHF','Switzerl.jpg','de'),(42,'COK','CK','Cook Islands',682,'Avarua','OC','NZD','Cook_Islands.jpg',''),(43,'CHL','CL','Chile',56,'Santiago','AM','CLP','Chile.jpg','es'),(44,'CMR','CM','Cameroon',237,'Yaounde','AF','XAF','Cameroon.jpg','fr'),(45,'CHN','CN','China',86,'Beijing','AS','CNY','China.jpg','zh'),(46,'COL','CO','Colombia',57,'Bogota','AM','COP','Colombia.jpg','es'),(47,'CRI','CR','Costa Rica',506,'San Jose','AM','CRC','Costa_Rica.jpg','es'),(48,NULL,'CS','Serbia & Montenegro',381,'Belgrade','EU','CSD','Serbia_Montenegro.jpg','scr'),(49,'CUB','CU','Cuba',53,'Havana','AM','CUP','Cuba.jpg','es'),(50,'CPV','CV','Cape Verde',238,'Cidade de Praia','AF','CVE','Cape_Verde.jpg','por'),(51,'CXR','CX','Chrismas Island',672,'Flying Fish Cove','OC','AUD','Christmas_Island.jpg',''),(52,'CYP','CY','Cyprus',357,'Nicosia','AS','CYP','Cyprus.jpg','el'),(53,'CZE','CZ','Czech Republic',420,'Prague','EU','CZK','Czech_Republic.jpg','cs'),(54,'DEU','DE','Germany',49,'Berlin','EU','EUR','Germany.jpg','de'),(55,'DJI','DJ','Djibouti',253,'Djibouti','AF','DJF','Djibouti.jpg','ara'),(56,'DNK','DK','Denmark',45,'Copenhagen','EU','DKK','Denmark.jpg','dan'),(57,'DMA','DM','Dominica',1,'Roseau','AM','XCD','Dominica.jpg','eng'),(58,'DOM','DO','Dominican Republic',1,'Santo Domingo','AM','DOP','Dominica.jpg','es'),(59,'DZA','DZ','Algeria',213,'Algiers','AF','DZD','Algeria.jpg','ara'),(60,'ECU','EC','Ecuador',593,'Quito','AM','USD','Ecuador.jpg','es'),(61,'EST','EE','Estonia',372,'Tallinn','EU','EEK','Estonia.jpg','est'),(62,'EGY','EG','Egypt',20,'Cairo','AF','EGP','Egypt.jpg','ara'),(63,'ESH','EH','Western Sahara',212,'Laâyoune','AF','AED','Western_Sahara.jpg',''),(64,'ERI','ER','Eritrea',291,'Asmara','AF','ERN','Eritrea.jpg','tir'),(65,'ESP','ES','Spain',34,'Madrid','EU','EUR','Spain.jpg','es'),(66,'ETH','ET','Ethiopia',251,'Addis Ababa','AF','ETB','Ethiopia.jpg','amh'),(67,'FIN','FI','Finland',358,'Helsinki','EU','EUR','Finland.jpg','fin'),(68,NULL,'FJ','Fiji',679,'Suva','OC','FJD','Fiji.jpg','fij'),(69,NULL,'FK','Falkand Islands (Malvinas)',500,'Port Stanley','AM','FKP','Falkland_Islands.Jpg',''),(70,NULL,'FM','Micronesia  (Federa States of)',691,'Kolonia','OC','USD','Micrones.jpg','eng'),(71,'FRO','FO','Faroe Islands',298,'Torshavn','EU','DKK','Faroe_Islands.jpg',''),(72,'FRA','FR','France',33,'Paris','EU','EUR','France.jpg','fr'),(73,'GAB','GA','Gabon',241,'Libreville','AF','XAF','Gabon.jpg','fr'),(74,'GBR','GB','United Kingdom',44,'London','EU','GBP','United_Kingdom.jpg','eng'),(75,'GEO','GE','Georgia',995,'Tbilisi','AS','GEL','Georgia.jpg','ka'),(76,'GUF','GF','French Guiana',594,'Cayenne','AM','EUR','French_Guiana.jpg',''),(77,'GHA','GH','Ghana',233,'Accra','AF','GHC','Ghana.jpg','eng'),(78,'GIB','GI','Gibraltar',350,'Gibraltar','EU','GIP','Gibraltar.jpg',''),(79,'GRL','GL','Greenland',299,'Nuuk','EU','DKK','Greenland.jpg',''),(80,'GMB','GM','Gambia',220,'Banjul','AF','GMD','Gambia.jpg','eng'),(81,'GIN','GN','Guinea',224,'Conakry','AF','GNF','Guinea.jpg','fr'),(82,'GLP','GP','Guadeloupe',590,'Basse-Terre','AM','EUR','Guadeloupe.jpg',''),(83,'GNQ','GQ','Equatorial Guinea',240,'Bata','AF','XAF','Equatorial_Guinea.jpg',''),(84,'GRC','GR','Greece',30,'Athens','EU','EUR','Greece.jpg','el'),(85,NULL,'GS','South Georgia & South Sandwich Islands',0,'Grytviken','AM','GBP','South_Georgia_And_South_Sandwich_Islands.jpg',''),(86,'GTM','GT','Guatemala',502,'Guatemala','AM','GTQ','Guatemal.jpg','es'),(87,'GUM','GU','Guam',671,'Hagatna (Agana)','OC','USD','Guam.jpg',''),(88,'GNB','GW','Guinea-Bissau',225,'Bissau','AF','XOF','Guinea-B.jpg','por'),(89,'GUY','GY','Guyana',592,'Georgetown','AM','GYD','Guyana.jpg','eng'),(90,'HKG','HK','Hong Kong',852,'Hong Kong','AS','HKD','Hong_Kong.jpg',''),(91,'HMD','HM','Heard Island And McDonald Islands',0,'-','OC','Array','Heard_Island_And_McDonald_Islands.jpg',''),(92,'HND','HN','Honduras',504,'Tegucigalpa','AM','HNL','Honduras.jpg','es'),(93,'HRV','HR','Croatia',385,'Zagreb','EU','HRK','Croatia.jpg','scr'),(94,'HTI','HT','Haiti',509,'Port-Au-Prince','AM','HTG','Haiti.jpg','fr'),(95,'HUN','HU','Hungary',36,'Budapest','EU','HUF','Hungary.jpg','hun'),(96,'IDN','ID','Indonesia',62,'Jakarta','AS','IDR','Indonesi.jpg','ind'),(97,'IRL','IE','Ireland',353,'Dublin','EU','EUR','Ireland.jpg','ga'),(98,'ISR','IL','Israel',972,'Jerusalem','AS','ILS','Israel.jpg','heb'),(99,'IND','IN','India',91,'New Delhi','AS','INR','India.jpg','hin'),(100,'IOT','IO','British Indian Ocean Territory',246,'Diego Garcia','AS','GBP','British_Indian_Ocean_Territory.jpg',''),(101,'IRQ','IQ','Iraq',964,'Baghdad','AS','IQD','Iraq.jpg','ara'),(102,'IRN','IR','Iran',98,'Tehran','AS','IRR','Iran.jpg','fa'),(103,'ISL','IS','Iceland',354,'Reykjavik','EU','ISK','Iceland.jpg','is'),(104,'ITA','IT','Italy',39,'Rome','EU','EUR','Italy.jpg','ita'),(105,'JAM','JM','Jamaica',1,'Kingston','AM','JMD','Jamaica.jpg','eng'),(106,'JOR','JO','Jordan',962,'Amman','AS','JOD','Jordan.jpg','ara'),(107,'JPN','JP','Japan',81,'Tokyo','AS','JPY','Japan.jpg','jpn'),(108,'KEN','KE','Kenya',254,'Nairobi','AF','KES','Kenya.jpg','swa'),(109,'KGZ','KG','Kyrgyzstan',996,'Bishkek','AS','KGS','Kyrgyzst.jpg','kir'),(110,'KHM','KH','Cambodia',855,'Phnom Penh','AS','KHR','Cambodia.jpg','khm'),(111,'KIR','KI','Kiribati',686,'Tarawa','OC','AUD','Kiribati.jpg','eng'),(112,'COM','KM','Comoros',269,'Moroni','AF','KMF','Comoros.jpg','swa'),(113,NULL,'KN','St. Kitts & Nevis',1,'Basseterre','AM','XCD','St._Kitts_Nevis.jpg','eng'),(114,'PRK','KP','North Korea',850,'Pyongyang','AS','KPW','North_Korea.jpg','kor'),(115,'KOR','KR','South Korea',82,'Seoul','AS','KRW','South_Korea.jpg','kor'),(116,'KWT','KW','Kuwait',965,'Kuwait','AS','KWD','Kuwait.jpg','ara'),(117,'CYM','KY','Cayman Islands',345,'George Town','AM','KYD','Cayman_Islands.jpg',''),(118,NULL,'KZ','Kazakhstan',7,'Almaty','AS','KZT','Kazakhst.jpg','kaz'),(119,'LAO','LA','Laos',856,'Vientiane','AS','LAK','Laos.jpg','lao'),(120,'LBN','LB','Lebanon',961,'Beirut','AS','LBP','Lebanon.jpg','ara'),(121,NULL,'LC','St. Lucia',1,'Castries','AM','XCD','St._Lucia.jpg','eng'),(122,'LIE','LI','Liechtenstein',423,'Vaduz','EU','CHF','Liechten.jpg','de'),(123,'LKA','LK','Sri Lanka',94,'Colombo','AS','LKR','Sri_Lanka.jpg','sin'),(124,'LBR','LR','Liberia',231,'Monrovia','AF','LRD','Liberia.jpg','eng'),(125,'LSO','LS','Lesotho',266,'Masera','AF','LSL','Lesotho.jpg','st'),(126,'LTU','LT','Lithuania',370,'Vilnius','EU','LTL','Lithuania.jpg','lit'),(127,'LUX','LU','Luxembourg',352,'Luxembourg','EU','EUR','Luxembourg.jpg','ltz'),(128,'LVA','LV','Latvia',371,'Riga','EU','LVL','Latvia.jpg','lav'),(129,'LBY','LY','Libyan Arab Jamahiriya',218,'Tripoli','AF','LYD','Libyan.jpg','ara'),(130,'MAR','MA','Morocco',212,'Rabat','AF','MAD','Morocco.jpg','ara'),(131,'MCO','MC','Monaco',377,'Monaco','EU','EUR','Monaco.jpg','fr'),(132,NULL,'MD','Moldova, Republic of',373,'Kishinev','EU','MDL','Moldova,.jpg','ro'),(133,'MDG','MG','Madagascar',261,'Antananarivo','AF','MGA','Madagascar.jpg','mlg'),(134,'MHL','MH','Marshall Islands',692,'Majuro','OC','USD','Marshall.jpg','eng'),(135,'VCT','MK','Macedonia  (former YR)',389,'Skopje','EU','MKD','Macedoni.jpg','mk'),(136,'MLI','ML','Mali',223,'Bamako','AF','XOF','Mali.jpg','fr'),(137,'MMR','MM','Myanmar (Burma)',95,'Rangoon','AS','MMK','Myanmar.jpg','my'),(138,'MNG','MN','Mongolia',976,'Ulan Bator','AS','MNT','Mongolia.jpg','mon'),(139,'MAC','MO','Macao',853,'Macao','AS','MOP','Macao.jpg',''),(140,'MNP','MP','Northern Mariana Islands',670,'Saipan','OC','USD','Northern_Mariana_Islands.jpg',''),(141,'MTQ','MQ','Martinique',596,'Fort-de-France','AM','EUR','Martinique.jpg',''),(142,'MRT','MR','Mauritania',222,'Novakchott','AF','MRO','Mauritan.jpg','fr'),(143,'MSR','MS','Montserrat',664,'Plymouth','AM','XCD','Montserrat.jpg',''),(144,'MLT','MT','Malta',356,'Valetta','EU','MTL','Malta.jpg','mlt'),(145,'MUS','MU','Mauritius',230,'Port Louis','AF','MUR','Mauritiu.jpg','eng'),(146,NULL,'MV','Maldives (Maladive Ilands)',960,'Male','AS','MVR','Maldives.jpg','div'),(147,'MWI','MW','Malawi',265,'Lilongwe','AF','MWK','Malawi.jpg','eng'),(148,'MEX','MX','Mexico',52,'Mexico City','AM','MXN','Mexico.jpg','es'),(149,'MYS','MY','Malaysia',60,'Kuala Lumpur','AS','MYR','Malaysia.jpg','ms'),(150,'MOZ','MZ','Mozambique',258,'Maputo','AF','MZM','Mozambiq.jpg','por'),(151,'NAM','NA','Namibia',264,'Windhoek','AF','NAD','Namibia.jpg','afr'),(152,'NCL','NC','New Caledonia',687,'Nouméa','OC','XPF','New_Caledonia.jpg',''),(153,'NER','NE','Niger',227,'Niamey','AF','XOF','Niger.jpg','fr'),(154,'NFK','NF','Norfolk Island',672,'Kingston','OC','AUD','Norfolk_Island.jpg',''),(155,'NGA','NG','Nigeria',234,'Abuja','AF','NGN','Nigeria.jpg',''),(156,'NIC','NI','Nicaragua',234,'Managua','AM','NIO','Nicaragua.jpg','es'),(157,'NLD','NL','Netherlands',31,'Amsterdam','EU','EUR','Netherlands.jpg',''),(158,'NOR','NO','Norway',47,'Oslo','EU','NOK','Norway.jpg','nor'),(159,'NPL','NP','Nepal',977,'Katmandu','AS','NPR','Nepal.jpg','nep'),(160,'NRU','NR','Nauru',674,'Nauru','OC','AUD','Nauru.jpg','nau'),(161,'NIU','NU','Niue',683,'Alofi','OC','NZD','Niue.jpg',''),(162,'NZL','NZ','New Zealand',64,'Wellington','OC','NZD','New_Zealand.jpg','eng'),(163,'OMN','OM','Oman',968,'Muscat','AS','OMR','Oman.jpg','ara'),(164,'PAN','PA','Panama',507,'Panama','AM','PAB','Panama.jpg','es'),(165,'PER','PE','Peru',51,'Lima','AM','PEN','Peru.jpg','es'),(166,'PYF','PF','French Polynesia',687,'Papeete','OC','XPF','French_Polynesia.jpg',''),(167,NULL,'PG','Papua-New Guinea',675,'Port Moresby','OC','PGK','Papua-New_Guinea.jpg','fr'),(168,'PHL','PH','Philippines',63,'Manila','AS','PHP','Philippi.jpg','fil'),(169,'PAK','PK','Pakistan',92,'Islamabad','AS','PKR','Pakistan.jpg','urd'),(170,'POL','PL','Poland',48,'Warsaw','EU','PLN','Poland.jpg','pol'),(171,NULL,'PM','Saint Pierre And Micquelon',508,'Saint Pierre','AM','EUR','Saint_Pierre_And_Micquelon.jpg','fr'),(172,'PCN','PN','Pitcairn',672,'Adamstown','OC','NZD','Pitcairn.jpg',''),(173,'PRI','PR','Puerto Rico',787,'San Juan','AM','USD','Puerto_Rico.jpg','es'),(174,NULL,'PS','Palestinian Territory, Occupied',970,'East Jerusalem','AS','JMD','Palestinian_Territory.jpg','ara'),(175,'PRT','PT','Portugal',351,'Lisbon','EU','EUR','Portugal.jpg','por'),(176,'PLW','PW','Palau',680,'Koror','OC','USD','Palau.jpg','eng'),(177,'PRY','PY','Paraguay',595,'Asuncion','AM','PYG','Paraguay.jpg','es'),(178,NULL,'QA','Quatar',974,'Doha','AS','QAR','Quatar.jpg','ara'),(179,'REU','RE','Reunion',262,'Saint-Denis','AF','EUR','Reunion.jpg',''),(180,'ROM','RO','Romania',40,'Bucharest','EU','RON','Romania.jpg','ro'),(181,'RUS','RU','Russian Federation',7,'Moscow','AS','RUB','Russian.jpg','rus'),(182,'RWA','RW','Rwanda',250,'Kigali','AF','RWF','Rwanda.jpg','kin'),(183,'SAU','SA','Saudi Arabia',966,'Riyadh','AS','SAR','Saudia_Arabiajpg','ara'),(184,'SLB','SB','Solomon Islands',677,'Honiara','OC','SBD','Solomon.jpg','eng'),(185,'SYC','SC','Seychelles',248,'Victoria','AF','SCR','Seychell.jpg','eng'),(186,'SDN','SD','Sudan',249,'Khartoum','AF','SDD','Sudan.jpg','ara'),(187,'SWE','SE','Sweden',46,'Stockholm','EU','SEK','Sweden.jpg','sv'),(188,'SGP','SG','Singapore',65,'Singapore','AS','SGD','Singapore.jpg','ms'),(189,'SHN','SH','Saint Helena',503,'Jamestown','AM','SHP','Saint_Helena.jpg','eng'),(190,'SVN','SI','Slovenia',386,'Ljubljana','EU','SIT','Slovenia.jpg','sk'),(191,'SJM','SJ','Svalbard And Jan Mayen',790,'Svalbard And Jan Mayen','EU','NOK','Svalbard_And_Jan_Mayen.jpg',''),(192,'SVK','SK','Slovakia',421,'Bratislava','EU','SKK','Slovakia.jpg','sk'),(193,'SLE','SL','Sierra Leone',232,'Freetown','AF','SLL','Sierra_Leone.jpg','eng'),(194,'SMR','SM','San Marino',378,'San Marino','EU','EUR','San_Marino.jpg','ita'),(195,'SEN','SN','Senegal',221,'Dakar','AF','XOF','Senegal.jpg','fr'),(196,'SOM','SO','Somalia',252,'Mogadishu','AF','SOS','Somalia.jpg','som'),(197,'SUR','SR','Suriname',597,'Paramaribo','AM','SRD','Suriname.jpg','nl'),(198,NULL,'ST','Sao Tome & Principe',239,'Sao Tome','AF','STD','Sao_Tome.jpg','por'),(199,'SLV','SV','El Salvador',503,'San Salvador','AM','SVC','El_Salvador.jpg','es'),(200,'SYR','SY','Syrian Arab Republic',963,'Damascus','AS','SYP','Syria.jpg','ara'),(201,'SWZ','SZ','Swaziland',269,'Mbabane','AF','SZL','Swazilan.jpg','eng'),(202,'TCA','TC','Turks And Caicos Islands',649,'Cockburn Town, Grand Turk','AM','USD','Turks_And_Caicos_Islands.jpg','eng'),(203,'ATF','TF','French Southern Territories',0,'-','AN','EUR','French_Southern_Territories.jpg','fr'),(204,'TGO','TG','Togo',228,'Lome','AF','XOF','Togo.jpg','ewe'),(205,'THA','TH','Thailand',66,'Bangkok','AS','THB','Thailand.jpg','tha'),(206,'TJK','TJ','Tajikistan',992,'Dushanbe','AS','RUB','Tajikistan.jpg','tgk'),(207,'TKL','TK','Tokelau',690,'-','OC','NZD','Tokelau.jpg','tok'),(208,NULL,'TL','Timor-Leste',670,'Dili','AS','USD','Timor-Leste.jpg','por'),(209,'TKM','TM','Turkmenistan',993,'Ashkhabad','AS','TMM','Turkmeni.jpg','tuk'),(210,'TUN','TN','Tunisia',216,'Tunis','AF','TND','Tunisia.jpg','ara'),(211,'TUR','TR','Turkey',90,'Ankara','AS','TRY','Turkey.jpg','tur'),(212,NULL,'TT','Trinidad & Tobago',1,'Port of Spain','AM','TTD','Trinidad.jpg','eng'),(213,'TUV','TV','Tuvalu',688,'Funafuti','OC','TVD','Tuvalu.jpg','tyv'),(214,'TWN','TW','Taiwan',886,'Taipei','AS','TWD','Taiwan.jpg','zh'),(215,'TZA','TZ','Tanzania',255,'Dar es Salaam','AF','TZS','Tanzania.jpg','swa'),(216,'UKR','UA','Ukraine',380,'Kiev','EU','UAH','Ukraine.jpg','ukr'),(217,'UGA','UG','Uganda',256,'Kampala','AF','UGX','Uganda.jpg','eng'),(218,'UMI','UM','United States Minor Outlying Islands',808,'-','OC','USD','United_States_Minor_Outlying_Islands.jpg',''),(219,'USA','US','United States',1,'Washington','AM','USD','USA.jpg','eng'),(220,'URY','UY','Uruguay',598,'Montevideo','AM','UYU','Uruguay.jpg','es'),(221,'UZB','UZ','Uzbekistan',998,'Tashkent','AS','UZS','Uzbekistan.jpg','uzb'),(222,NULL,'VA','Vatican City',39,'Vatican City','EU','EUR','Vatican.jpg','ita'),(223,NULL,'VC','St. Vincent & Grenadines',1,'Kingstown','AM','XCD','St._Vincent-Grenadines.jpg','eng'),(224,'VEN','VE','Venezuela',58,'Caracas','AM','VEB','Venezuela.jpg','es'),(225,'VGB','VG','Virgin Islands, British',1284,'Road Town','AM','USD','Virgin_Islands_British.jpg',''),(226,'VIR','VI','Virgin Islands, U.S.',340,'Charlotte Amalie','AM','USD','Virgin_Islands_U.S.jpg',''),(227,'VNM','VN','Vietnam',84,'Hanoi','AS','VND','Vietnam.jpg','vie'),(228,'VUT','VU','Vanuatu',678,'Port Vila','OC','VUV','Vanuatu.jpg','eng'),(229,'WLF','WF','Wallis And Futuna',685,'Mata-Utu','OC','XPF','Wallis_And_Futuna.jpg','fr'),(230,NULL,'WS','Western Samoa',685,'Apia','OC','WST','Western.jpg','ara'),(231,'YEM','YE','Yemen',967,'Sanaa','AS','YER','Yemen.jpg','ara'),(232,'MYT','YT','Mayotte',269,'Mamoudzou','AF','EUR','Mayotte.jpg','fr'),(233,'ZAF','ZA','South Africa',27,'Cape Town','AF','ZAR','South_Africa.jpg','eng'),(234,'ZMB','ZM','Zambia',260,'Lusaka','AF','ZMK','Zambia.jpg','eng'),(235,'ZWE','ZW','Zimbabwe',263,'Harare','AF','ZWD','Zimbabwe.jpg','eng');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country_old`
--

DROP TABLE IF EXISTS `country_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country_old` (
  `countryId` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `countryCode` char(3) DEFAULT NULL,
  `countryName` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`countryId`),
  UNIQUE KEY `countryCode` (`countryCode`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country_old`
--

LOCK TABLES `country_old` WRITE;
/*!40000 ALTER TABLE `country_old` DISABLE KEYS */;
INSERT INTO `country_old` VALUES (1,'ind','India'),(2,'USA','United states'),(3,'SNG','Singapore');
/*!40000 ALTER TABLE `country_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lookup_status`
--

DROP TABLE IF EXISTS `lookup_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lookup_status` (
  `statusId` tinyint(4) NOT NULL AUTO_INCREMENT,
  `statusCode` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`statusId`),
  UNIQUE KEY `statusCode` (`statusCode`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lookup_status`
--

LOCK TABLES `lookup_status` WRITE;
/*!40000 ALTER TABLE `lookup_status` DISABLE KEYS */;
INSERT INTO `lookup_status` VALUES (1,'Active'),(2,'In Active'),(3,'Private'),(4,'Public'),(5,'Accept'),(6,'Blocked'),(7,'Pending'),(8,'Request'),(9,'Deleted');
/*!40000 ALTER TABLE `lookup_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `messageId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chatId` int(10) unsigned NOT NULL,
  `message` text,
  `userId` int(10) unsigned NOT NULL COMMENT 'sender userId',
  `createdDate` datetime NOT NULL,
  PRIMARY KEY (`messageId`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` VALUES (1,1,'hello india',44,'2014-09-01 19:00:31'),(2,4,'hii',58,'2014-09-01 19:15:50'),(3,4,'dsfsdfasd',55,'2014-09-01 19:16:48'),(4,4,'hi',65,'2014-09-02 11:26:39'),(5,5,'Hello Tech',60,'2014-09-02 16:00:56'),(6,6,'hello venture app',65,'2014-09-02 16:09:22'),(7,7,'Hello',80,'2014-09-02 17:15:15'),(8,8,'hii..message inserted into db directly for testing',130,'2014-09-25 10:53:57'),(9,8,'hii..message inserted into db directly for testing again...',130,'2014-09-25 10:54:07'),(10,8,'hii..message inserted into db directly for testing another...',136,'2014-09-25 10:54:21'),(11,8,'hii..message inserted into db directly for testing yet another...',136,'2014-09-25 10:54:26'),(12,9,'hiii sid..',130,'0000-00-00 00:00:00'),(13,10,'hiii sid...',130,'0000-00-00 00:00:00'),(14,11,'hii sidarth...',130,'0000-00-00 00:00:00'),(15,12,'hey john...',130,'0000-00-00 00:00:00'),(16,13,'hey sonu..',130,'0000-00-00 00:00:00'),(17,14,'hey mike',130,'0000-00-00 00:00:00'),(18,15,'hiii',130,'0000-00-00 00:00:00'),(19,16,'test',130,'0000-00-00 00:00:00'),(20,17,'hey',130,'0000-00-00 00:00:00'),(21,18,'heyy',130,'0000-00-00 00:00:00'),(22,19,'test',130,'0000-00-00 00:00:00'),(23,20,'heyyy',130,'0000-00-00 00:00:00'),(24,21,'heyy ajay...',130,'0000-00-00 00:00:00'),(25,22,'heyyy ajay...',130,'0000-00-00 00:00:00'),(26,22,'hiiii ajay...again....',130,'0000-00-00 00:00:00'),(27,22,'third time..',130,'0000-00-00 00:00:00'),(28,23,'testing for 4...',130,'0000-00-00 00:00:00'),(29,24,'hii john........................',130,'0000-00-00 00:00:00'),(30,25,'hi both of u.....',130,'0000-00-00 00:00:00'),(31,26,'hiii both of u....this is mike.....',136,'0000-00-00 00:00:00'),(32,27,'hiiiii.................................................',130,'0000-00-00 00:00:00'),(33,28,'hi..siddarth..this is mike..today is : fri sep 26 2014..',136,'0000-00-00 00:00:00'),(34,29,'hii how are u..',144,'0000-00-00 00:00:00'),(35,30,'hii nitin..i am fine...',143,'0000-00-00 00:00:00'),(36,31,'welcome..all of u all..',130,'0000-00-00 00:00:00'),(37,32,'hi..all of u..again...',130,'0000-00-00 00:00:00'),(38,33,'hi...to all...',142,'0000-00-00 00:00:00'),(39,33,'hi..again...',142,'0000-00-00 00:00:00'),(40,34,'hii nitin....',130,'0000-00-00 00:00:00'),(41,35,'hi every one...again...',130,'0000-00-00 00:00:00'),(42,35,'hiiiiii',130,'0000-00-00 00:00:00'),(43,36,'hiiiii',142,'0000-00-00 00:00:00'),(44,37,'hiiiii',143,'0000-00-00 00:00:00'),(45,32,'i am testing now..hi ol...',143,'0000-00-00 00:00:00'),(46,38,'hii.. testing...',143,'0000-00-00 00:00:00'),(47,39,'hello.',142,'0000-00-00 00:00:00'),(48,40,'http://localhost:5555/',130,'0000-00-00 00:00:00'),(49,34,'http://localhost:5555/',130,'0000-00-00 00:00:00'),(50,8,'29 sep 11.33 am',136,'0000-00-00 00:00:00'),(51,8,'29 sep 11.40 am',136,'0000-00-00 00:00:00'),(52,8,'29 sep 11.49 am',136,'0000-00-00 00:00:00'),(53,8,'sep 29 , testing',136,'0000-00-00 00:00:00'),(54,8,'29 sep again and again',136,'0000-00-00 00:00:00'),(55,8,'hiiii 29 sep ',136,'0000-00-00 00:00:00'),(56,8,'hiiii',136,'0000-00-00 00:00:00'),(57,8,'qwertyuiop',136,'0000-00-00 00:00:00'),(58,8,'shoul work fine now....',136,'0000-00-00 00:00:00'),(59,8,'testing now,,,,',136,'0000-00-00 00:00:00'),(60,8,'ang again',136,'0000-00-00 00:00:00'),(61,8,'i dont know why this works',136,'0000-00-00 00:00:00'),(62,8,'12.12 pm',136,'0000-00-00 00:00:00'),(63,41,'test',136,'0000-00-00 00:00:00'),(64,42,'test again',136,'0000-00-00 00:00:00'),(65,42,'length test',136,'0000-00-00 00:00:00'),(66,43,'test',136,'0000-00-00 00:00:00'),(67,8,'test @ 12..22 pm',136,'0000-00-00 00:00:00'),(68,8,'test @ 12.23 pm',136,'0000-00-00 00:00:00'),(69,8,'test @ 12.24 pm',136,'0000-00-00 00:00:00'),(70,8,'hii..now it works fine...',136,'0000-00-00 00:00:00'),(71,8,'first message',136,'0000-00-00 00:00:00'),(72,8,'second message',136,'0000-00-00 00:00:00'),(73,8,'hiii third message',136,'0000-00-00 00:00:00'),(74,8,'fourth',136,'0000-00-00 00:00:00'),(75,8,'fifth',136,'0000-00-00 00:00:00'),(76,8,'tested again...',136,'0000-00-00 00:00:00'),(77,8,'hiii',136,'0000-00-00 00:00:00'),(78,8,'hiii again...',136,'0000-00-00 00:00:00'),(79,8,'and again..',136,'0000-00-00 00:00:00'),(80,8,'and again and again',136,'0000-00-00 00:00:00'),(81,8,'test @ 12.42 pm',136,'0000-00-00 00:00:00'),(82,8,'hi siddarth',136,'0000-00-00 00:00:00'),(83,8,'hi siddarth,',136,'0000-00-00 00:00:00'),(84,8,'hey sidarth',136,'0000-00-00 00:00:00'),(85,44,'sent at 12.51 pm',130,'0000-00-00 00:00:00'),(86,45,'hi ajay..u there..',130,'0000-00-00 00:00:00'),(87,46,'hey nitin...',130,'0000-00-00 00:00:00'),(88,47,'hey siddarth',136,'0000-00-00 00:00:00'),(89,47,'@12.58 pm',136,'0000-00-00 00:00:00'),(90,40,'test @ 1.12 pm',130,'0000-00-00 00:00:00'),(91,8,'test @ 1',136,'0000-00-00 00:00:00'),(92,8,'test @ 1.20pm',136,'0000-00-00 00:00:00'),(93,8,'test @ 1.25 pm',136,'0000-00-00 00:00:00'),(94,40,'hey ajay..',130,'0000-00-00 00:00:00'),(95,8,'testing',136,'0000-00-00 00:00:00'),(96,8,'Testing @ 2.55 pm',136,'0000-00-00 00:00:00'),(97,8,'Testing @ 2.58 pm,by mike',136,'0000-00-00 00:00:00'),(98,8,'hey siddarth..its 3 pm now,,,,,',136,'0000-00-00 00:00:00'),(99,8,'hi mike..its 3.06 now,,,,,,',130,'0000-00-00 00:00:00'),(100,48,'HI..ol 3 of u..its 3.45 pm now,,,,,,',136,'0000-00-00 00:00:00'),(101,8,'hi sid..4.14 pm...',136,'0000-00-00 00:00:00'),(102,8,'hey mike...4.28 pm now,,,,,,',130,'0000-00-00 00:00:00'),(103,8,'hii mike......',130,'0000-00-00 00:00:00'),(104,8,'hey mike,,,,,,4.31 pm now,,,,,,,',130,'0000-00-00 00:00:00'),(105,49,'Hello',151,'2014-10-06 16:18:51'),(106,50,'hi john',136,'0000-00-00 00:00:00'),(107,51,'hiiii john,,,,,,,,,,,,,,,,,,,',136,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messageReceiver`
--

DROP TABLE IF EXISTS `messageReceiver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messageReceiver` (
  `messageId` int(10) unsigned NOT NULL,
  `userId` int(10) unsigned NOT NULL COMMENT 'UserId of all users included in a given chat including sender',
  `receivedDate` datetime NOT NULL,
  `statusId` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'statusId from lookup_status table'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messageReceiver`
--

LOCK TABLES `messageReceiver` WRITE;
/*!40000 ALTER TABLE `messageReceiver` DISABLE KEYS */;
INSERT INTO `messageReceiver` VALUES (1,44,'2014-09-01 19:00:31',3),(1,44,'2014-09-01 19:00:31',3),(1,47,'2014-09-01 19:00:31',3),(2,58,'2014-09-01 19:15:50',4),(2,47,'2014-09-01 19:15:50',4),(2,44,'2014-09-01 19:15:50',4),(3,58,'2014-09-01 19:16:48',4),(3,47,'2014-09-01 19:16:48',4),(3,44,'2014-09-01 19:16:48',4),(4,47,'2014-09-02 11:26:39',4),(4,44,'2014-09-02 11:26:39',4),(5,44,'2014-09-02 16:00:56',3),(6,47,'2014-09-02 16:09:22',4),(7,44,'2014-09-02 17:15:15',4),(7,47,'2014-09-02 17:15:15',4),(8,136,'2014-09-25 10:59:13',2),(9,136,'2014-09-25 10:59:13',2),(10,130,'2014-09-25 10:59:13',2),(11,130,'2014-09-25 10:59:13',2),(12,141,'0000-00-00 00:00:00',1),(13,141,'0000-00-00 00:00:00',1),(14,141,'0000-00-00 00:00:00',1),(15,137,'0000-00-00 00:00:00',2),(16,138,'0000-00-00 00:00:00',1),(17,136,'0000-00-00 00:00:00',2),(18,137,'0000-00-00 00:00:00',2),(19,139,'0000-00-00 00:00:00',1),(20,139,'0000-00-00 00:00:00',1),(21,139,'0000-00-00 00:00:00',1),(22,141,'0000-00-00 00:00:00',1),(23,136,'0000-00-00 00:00:00',2),(24,139,'0000-00-00 00:00:00',1),(25,139,'0000-00-00 00:00:00',1),(26,139,'0000-00-00 00:00:00',1),(27,139,'0000-00-00 00:00:00',1),(28,137,'0000-00-00 00:00:00',2),(28,136,'0000-00-00 00:00:00',2),(28,141,'0000-00-00 00:00:00',1),(28,138,'0000-00-00 00:00:00',1),(29,137,'0000-00-00 00:00:00',2),(30,139,'0000-00-00 00:00:00',1),(30,138,'0000-00-00 00:00:00',1),(31,130,'0000-00-00 00:00:00',2),(31,138,'0000-00-00 00:00:00',1),(32,136,'0000-00-00 00:00:00',2),(33,130,'0000-00-00 00:00:00',2),(34,143,'0000-00-00 00:00:00',1),(35,144,'0000-00-00 00:00:00',1),(36,144,'0000-00-00 00:00:00',1),(36,142,'0000-00-00 00:00:00',1),(36,143,'0000-00-00 00:00:00',1),(37,144,'0000-00-00 00:00:00',1),(37,142,'0000-00-00 00:00:00',1),(37,143,'0000-00-00 00:00:00',1),(38,144,'0000-00-00 00:00:00',1),(38,130,'0000-00-00 00:00:00',2),(38,143,'0000-00-00 00:00:00',1),(39,144,'0000-00-00 00:00:00',1),(39,130,'0000-00-00 00:00:00',2),(39,143,'0000-00-00 00:00:00',1),(40,144,'0000-00-00 00:00:00',1),(41,144,'0000-00-00 00:00:00',1),(41,142,'0000-00-00 00:00:00',1),(41,143,'0000-00-00 00:00:00',1),(42,144,'0000-00-00 00:00:00',1),(42,142,'0000-00-00 00:00:00',1),(42,143,'0000-00-00 00:00:00',1),(43,144,'0000-00-00 00:00:00',1),(43,130,'0000-00-00 00:00:00',2),(43,143,'0000-00-00 00:00:00',1),(44,144,'0000-00-00 00:00:00',1),(44,142,'0000-00-00 00:00:00',1),(44,130,'0000-00-00 00:00:00',2),(45,144,'0000-00-00 00:00:00',1),(45,142,'0000-00-00 00:00:00',1),(45,130,'0000-00-00 00:00:00',2),(46,142,'0000-00-00 00:00:00',1),(47,130,'0000-00-00 00:00:00',2),(48,139,'0000-00-00 00:00:00',1),(49,144,'0000-00-00 00:00:00',1),(50,130,'0000-00-00 00:00:00',2),(51,130,'0000-00-00 00:00:00',2),(52,130,'0000-00-00 00:00:00',2),(53,130,'0000-00-00 00:00:00',2),(54,130,'0000-00-00 00:00:00',2),(55,130,'0000-00-00 00:00:00',2),(56,130,'0000-00-00 00:00:00',2),(57,130,'0000-00-00 00:00:00',2),(58,130,'0000-00-00 00:00:00',2),(59,130,'0000-00-00 00:00:00',2),(60,130,'0000-00-00 00:00:00',2),(61,130,'0000-00-00 00:00:00',2),(62,130,'0000-00-00 00:00:00',2),(63,141,'0000-00-00 00:00:00',1),(63,130,'0000-00-00 00:00:00',2),(64,139,'0000-00-00 00:00:00',1),(64,137,'0000-00-00 00:00:00',2),(65,139,'0000-00-00 00:00:00',1),(65,137,'0000-00-00 00:00:00',2),(66,139,'0000-00-00 00:00:00',1),(67,130,'0000-00-00 00:00:00',2),(68,130,'0000-00-00 00:00:00',2),(69,130,'0000-00-00 00:00:00',2),(70,130,'0000-00-00 00:00:00',2),(71,130,'0000-00-00 00:00:00',2),(72,130,'0000-00-00 00:00:00',2),(73,130,'0000-00-00 00:00:00',2),(74,130,'0000-00-00 00:00:00',2),(75,130,'0000-00-00 00:00:00',2),(76,130,'0000-00-00 00:00:00',2),(77,130,'0000-00-00 00:00:00',2),(78,130,'0000-00-00 00:00:00',2),(79,130,'0000-00-00 00:00:00',2),(80,130,'0000-00-00 00:00:00',2),(81,130,'0000-00-00 00:00:00',2),(82,130,'0000-00-00 00:00:00',2),(83,130,'0000-00-00 00:00:00',2),(85,141,'0000-00-00 00:00:00',1),(86,139,'0000-00-00 00:00:00',1),(87,144,'0000-00-00 00:00:00',1),(88,130,'0000-00-00 00:00:00',2),(89,130,'0000-00-00 00:00:00',2),(90,139,'0000-00-00 00:00:00',1),(91,130,'0000-00-00 00:00:00',2),(92,130,'0000-00-00 00:00:00',2),(93,130,'0000-00-00 00:00:00',2),(94,139,'0000-00-00 00:00:00',1),(95,130,'0000-00-00 00:00:00',2),(96,130,'0000-00-00 00:00:00',2),(97,130,'0000-00-00 00:00:00',2),(98,130,'0000-00-00 00:00:00',2),(99,136,'0000-00-00 00:00:00',2),(100,139,'0000-00-00 00:00:00',1),(100,137,'0000-00-00 00:00:00',2),(100,130,'0000-00-00 00:00:00',2),(101,130,'0000-00-00 00:00:00',2),(102,136,'0000-00-00 00:00:00',2),(103,136,'0000-00-00 00:00:00',2),(104,136,'0000-00-00 00:00:00',2),(105,86,'2014-10-06 16:18:51',7),(105,83,'2014-10-06 16:18:51',7),(105,58,'2014-10-06 16:18:51',7),(105,144,'2014-10-06 16:18:51',7),(105,129,'2014-10-06 16:18:51',7),(105,106,'2014-10-06 16:18:51',7),(105,55,'2014-10-06 16:18:51',7),(105,60,'2014-10-06 16:18:51',7),(105,121,'2014-10-06 16:18:51',7),(105,50,'2014-10-06 16:18:51',7),(105,130,'2014-10-06 16:18:51',7),(105,47,'2014-10-06 16:18:51',7),(106,137,'0000-00-00 00:00:00',2),(107,137,'0000-00-00 00:00:00',2);
/*!40000 ALTER TABLE `messageReceiver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `privacySetting`
--

DROP TABLE IF EXISTS `privacySetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privacySetting` (
  `settingId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userId` int(10) unsigned NOT NULL,
  `findMeByPhone` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes,2=No',
  `findMeByEmail` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes,2=No',
  `findMeBySearch` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes,2=No',
  `hideSkill` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes,2=No',
  `hideLinkedin` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes,2=No',
  `hideProject` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes,2=No',
  `hideProfilePhoto` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes,2=No',
  `block` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes,2=No',
  `report` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes,2=No',
  PRIMARY KEY (`settingId`),
  KEY `idx_userId` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `privacySetting`
--

LOCK TABLES `privacySetting` WRITE;
/*!40000 ALTER TABLE `privacySetting` DISABLE KEYS */;
INSERT INTO `privacySetting` VALUES (1,17,1,1,1,1,1,2,1,1,1),(2,44,1,1,1,1,1,1,1,1,1),(3,86,1,1,1,1,1,1,1,1,1),(4,55,1,1,1,1,1,1,1,2,1),(5,56,1,1,1,1,1,1,1,1,1),(6,57,1,1,1,1,1,1,1,1,1),(7,58,1,1,1,1,1,1,1,1,1),(8,59,1,1,1,1,1,1,1,1,1),(9,60,1,1,2,2,2,2,1,1,1),(10,65,1,1,1,1,1,1,1,1,1),(11,67,1,1,1,1,1,1,1,1,1),(12,68,1,1,1,1,1,1,1,1,1),(14,71,1,1,1,1,1,1,1,1,1),(16,76,1,1,1,1,1,1,1,1,1),(17,77,1,1,1,1,1,1,1,1,1),(18,79,1,1,1,1,1,1,1,1,1),(19,80,1,1,1,1,1,1,1,1,1),(20,82,1,1,1,1,1,1,1,1,1),(21,85,1,1,1,1,1,1,1,1,1),(22,96,1,1,1,1,1,1,1,1,1),(25,100,1,1,1,1,1,1,1,1,1),(26,101,1,1,1,1,1,1,1,1,1),(27,103,1,1,1,1,1,1,1,1,1),(28,105,1,1,1,1,1,1,1,1,1),(29,106,1,1,1,1,1,1,1,1,1),(30,108,1,1,1,1,1,1,1,1,1),(31,109,1,1,1,1,1,1,1,1,1),(32,110,1,1,1,1,1,1,1,1,1),(33,112,1,1,1,1,1,1,1,1,1),(34,113,1,1,1,1,1,1,1,1,1),(35,114,1,1,1,1,1,1,1,1,1),(36,115,1,1,1,1,1,1,1,1,1),(37,119,1,1,1,1,1,1,1,1,1),(38,120,1,1,1,1,1,1,1,1,1),(42,124,1,1,1,1,1,1,1,1,1),(45,128,1,1,1,1,1,1,1,1,1),(46,129,1,1,1,1,1,1,1,1,1),(47,130,1,1,1,1,1,1,1,1,1),(49,132,1,1,1,1,1,1,1,1,1),(50,135,1,1,1,1,1,1,1,1,1),(51,137,1,1,1,1,1,1,1,1,1),(52,138,1,1,1,1,1,1,1,1,1),(53,139,1,1,1,1,1,1,1,1,1),(54,140,1,1,1,1,1,1,1,1,1),(55,141,1,1,1,1,1,1,1,1,1),(56,142,1,1,1,1,1,1,1,1,1),(57,143,1,1,1,1,1,1,1,1,1),(58,144,1,1,1,1,1,1,1,1,1),(59,145,1,1,1,1,1,1,1,1,1),(60,146,1,1,1,1,1,1,1,1,1),(61,147,1,1,1,1,1,1,1,1,1),(62,148,1,1,1,1,1,1,2,2,2),(63,149,1,1,1,1,1,1,1,1,1),(64,151,1,1,1,1,1,1,1,1,1),(65,152,1,1,1,1,1,1,1,1,1),(66,153,1,1,1,1,1,1,1,1,1),(67,154,1,1,1,1,1,1,1,1,1),(68,155,1,1,1,1,1,1,1,1,1),(69,156,1,1,1,1,1,1,1,1,1),(70,158,1,1,1,1,1,1,1,1,1),(71,159,1,1,1,1,1,1,1,1,1),(72,160,1,1,1,1,1,1,1,1,1),(73,161,1,1,1,1,1,1,1,1,1),(74,162,1,1,1,1,1,1,1,1,1),(75,163,1,1,1,1,1,1,1,1,1),(76,166,1,1,1,1,1,1,1,1,1),(77,167,1,1,1,1,1,1,1,1,1),(78,168,1,1,1,1,1,1,1,1,1),(79,169,1,1,1,1,1,1,1,1,1),(80,170,1,1,1,1,1,1,1,1,1),(81,171,1,1,1,1,1,1,1,1,1),(82,172,1,1,1,1,1,1,1,1,1),(83,173,1,1,1,1,1,1,1,1,1),(84,174,1,1,1,1,1,1,1,1,1),(85,175,1,1,1,1,1,1,1,1,1),(86,176,1,1,1,1,1,1,1,1,1),(87,177,1,1,1,1,1,1,1,1,1),(88,178,1,1,1,1,1,1,1,1,1),(89,179,1,1,1,1,1,1,1,1,1),(90,180,1,1,1,1,1,1,1,1,1),(91,181,1,1,1,1,1,1,1,1,1),(92,183,1,1,1,1,1,1,1,1,1),(93,184,1,1,1,1,1,1,1,1,1),(94,185,1,1,1,1,1,1,1,1,1),(95,186,1,1,1,1,1,1,1,1,1),(96,187,1,1,1,1,1,1,1,1,1),(97,188,1,1,1,1,1,1,1,1,1),(98,189,1,1,1,1,1,1,1,1,1),(99,190,1,1,1,1,1,1,1,1,1),(100,191,1,1,1,1,1,1,1,1,1),(101,192,1,1,1,1,1,1,1,1,1),(102,193,1,1,1,1,1,1,1,1,1),(103,194,1,1,1,1,1,1,1,1,1),(104,196,1,1,1,1,1,1,1,1,1),(105,199,1,1,1,1,1,1,1,1,1),(106,200,1,1,1,1,1,1,1,1,1),(107,201,1,1,1,1,1,1,1,1,1),(108,202,1,1,1,1,1,1,1,1,1),(109,203,1,1,1,1,1,1,1,1,1),(110,204,1,1,1,1,1,1,1,1,1),(111,214,1,1,1,1,1,1,1,1,1),(112,216,1,1,1,1,1,1,1,1,1),(113,218,1,1,1,1,1,1,1,1,1),(114,231,1,1,1,1,1,1,1,1,1),(115,237,2,2,1,1,2,1,1,2,2);
/*!40000 ALTER TABLE `privacySetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profilePic`
--

DROP TABLE IF EXISTS `profilePic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profilePic` (
  `profilePicId` smallint(6) NOT NULL AUTO_INCREMENT,
  `userId` int(10) unsigned NOT NULL,
  `profilePic` varchar(255) NOT NULL,
  `defaultPic` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=No Default Set',
  `createdDate` datetime NOT NULL,
  `updatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`profilePicId`),
  UNIQUE KEY `userId` (`userId`,`profilePicId`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profilePic`
--

LOCK TABLES `profilePic` WRITE;
/*!40000 ALTER TABLE `profilePic` DISABLE KEYS */;
INSERT INTO `profilePic` VALUES (1,55,'1412155271.png',0,'2014-10-01 14:51:11','2014-10-01 09:28:36'),(2,55,'1412155286.jpg',1,'2014-10-01 14:51:26','2014-10-01 09:28:36'),(7,150,'1412575861.jpg',0,'2014-10-06 11:41:02','2014-10-09 13:25:48'),(15,130,'1412580164.jpg',1,'2014-10-06 12:52:45','2014-10-06 07:31:44'),(16,130,'1412580503.jpg',0,'2014-10-06 12:58:23','2014-10-06 07:28:23'),(22,151,'1412827537.jpg',1,'2014-10-09 09:35:37','2014-10-10 11:19:29'),(24,151,'1412827608.jpg',0,'2014-10-09 09:36:48','2014-10-10 11:17:52'),(30,151,'1412837573.jpg',0,'2014-10-09 12:22:54','2014-10-10 11:18:10'),(31,151,'1412840244.jpg',0,'2014-10-09 13:07:25','2014-10-10 11:17:56'),(32,151,'1412847549.jpg',0,'2014-10-09 15:09:10','2014-10-10 11:19:29'),(36,150,'1412860005.jpg',1,'2014-10-09 18:36:45','2014-10-09 13:25:48'),(37,150,'1412860009.gif',0,'2014-10-09 18:36:49','2014-10-09 13:06:49'),(38,144,'1413883914.png',1,'2014-10-21 15:01:54','2014-10-21 09:31:54'),(39,144,'1413883921.jpg',0,'2014-10-21 15:02:01','2014-10-21 09:32:01'),(40,144,'1413883925.jpg',0,'2014-10-21 15:02:05','2014-10-21 09:32:05');
/*!40000 ALTER TABLE `profilePic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project` (
  `projectId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userId` int(10) unsigned NOT NULL,
  `projectName` varchar(50) NOT NULL,
  `projectDetail` text,
  `lockProjectDetail` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0=>lock,1=>show',
  `visibility` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Private,2=Public',
  `createdDate` datetime NOT NULL,
  `updatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`projectId`),
  UNIQUE KEY `userId` (`userId`,`projectId`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` VALUES (6,50,'KABIFT','HELLO KABIFT',1,4,'2014-09-16 11:55:31','2014-09-18 10:27:14'),(7,3,'VCA','test',1,4,'2014-09-16 12:00:18','2014-09-16 06:30:18'),(8,126,'aww','asasa',0,3,'2014-09-17 18:47:04','2014-09-17 14:00:11'),(9,126,'aww','asasa',0,4,'2014-09-17 18:47:22','2014-09-17 14:00:11'),(10,126,'aww','asasa',1,4,'2014-09-17 18:47:29','2014-09-17 14:00:11'),(31,55,'test','test',1,1,'2014-09-26 16:29:29','2014-09-26 10:59:29'),(32,130,'testProject','test',1,1,'0000-00-00 00:00:00','2014-10-13 12:51:43');
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectImage`
--

DROP TABLE IF EXISTS `projectImage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectImage` (
  `imageId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `projectId` int(10) unsigned NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`imageId`),
  UNIQUE KEY `projectId` (`projectId`,`imageId`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectImage`
--

LOCK TABLES `projectImage` WRITE;
/*!40000 ALTER TABLE `projectImage` DISABLE KEYS */;
INSERT INTO `projectImage` VALUES (50,31,'1412776551.jpg');
/*!40000 ALTER TABLE `projectImage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectViewCount`
--

DROP TABLE IF EXISTS `projectViewCount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectViewCount` (
  `projectId` int(10) unsigned NOT NULL,
  `userId` int(10) unsigned NOT NULL COMMENT 'Viewer''s userId',
  `createdDate` datetime NOT NULL,
  PRIMARY KEY (`projectId`,`userId`,`createdDate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectViewCount`
--

LOCK TABLES `projectViewCount` WRITE;
/*!40000 ALTER TABLE `projectViewCount` DISABLE KEYS */;
INSERT INTO `projectViewCount` VALUES (0,130,'2014-10-07 14:07:35'),(1,47,'2014-10-07 11:37:12'),(1,47,'2014-10-07 11:39:30'),(1,47,'2014-10-07 11:40:30'),(1,47,'2014-10-07 11:41:13'),(1,47,'2014-10-07 11:41:53'),(1,47,'2014-10-07 11:42:31'),(1,47,'2014-10-07 11:43:44'),(1,47,'2014-10-07 11:46:10'),(1,47,'2014-10-07 11:46:52'),(1,47,'2014-10-07 11:47:56'),(1,55,'2014-10-08 18:35:41'),(1,130,'2014-10-07 12:35:47'),(1,130,'2014-10-07 12:41:29'),(1,130,'2014-10-07 14:14:34'),(1,130,'2014-10-07 18:31:48'),(6,47,'0000-00-00 00:00:00'),(8,2,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `projectViewCount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectViewRequest`
--

DROP TABLE IF EXISTS `projectViewRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectViewRequest` (
  `requestId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `projectId` int(10) unsigned NOT NULL,
  `userId` int(10) unsigned NOT NULL,
  `statusId` tinyint(4) NOT NULL DEFAULT '7',
  `createdDate` datetime NOT NULL COMMENT 'Time when the request will come',
  `updatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Time when owner will change request status',
  PRIMARY KEY (`requestId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectViewRequest`
--

LOCK TABLES `projectViewRequest` WRITE;
/*!40000 ALTER TABLE `projectViewRequest` DISABLE KEYS */;
INSERT INTO `projectViewRequest` VALUES (1,6,47,1,'0000-00-00 00:00:00','2014-10-06 11:24:46'),(2,1,47,1,'0000-00-00 00:00:00','2014-10-07 06:16:55'),(3,1,47,1,'2014-10-07 11:46:10','2014-10-07 06:23:35'),(4,1,47,1,'2014-10-07 11:46:52','2014-10-07 06:24:18'),(5,1,47,1,'2014-10-07 11:47:56','2014-10-07 06:25:21'),(6,1,130,7,'2014-10-07 12:35:47','2014-10-13 12:03:43'),(7,1,130,7,'2014-10-07 12:41:29','2014-10-13 12:03:43'),(8,0,130,7,'2014-10-07 14:07:35','2014-10-13 12:03:43'),(9,1,130,7,'2014-10-07 14:14:34','2014-10-13 12:03:43'),(10,1,130,7,'2014-10-07 18:31:48','2014-10-13 12:03:43'),(11,1,55,1,'2014-10-08 18:35:41','2014-10-08 13:13:08'),(12,32,47,7,'0000-00-00 00:00:00','2014-10-13 12:55:20');
/*!40000 ALTER TABLE `projectViewRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `state` (
  `stateId` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `stateCode` varchar(10) NOT NULL,
  `countryId` smallint(5) unsigned NOT NULL,
  `stateName` varchar(70) NOT NULL,
  `statusId` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`stateId`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `state`
--

LOCK TABLES `state` WRITE;
/*!40000 ALTER TABLE `state` DISABLE KEYS */;
INSERT INTO `state` VALUES (1,'BIR',99,'Bihar',1),(2,'UPE',99,'Uttar Pradesh',1),(4,'TXS',219,'Texas',1),(5,'CLF',219,'California',1),(6,'NVD',219,'Nevada',1),(7,'CNR',188,'Central Region',1),(8,'ESR',188,'East Region',1),(9,'HAT',94,'Faiti',1);
/*!40000 ALTER TABLE `state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tempProjectPic`
--

DROP TABLE IF EXISTS `tempProjectPic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tempProjectPic` (
  `tempId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tempProjectId` int(10) unsigned NOT NULL,
  `imageName` varchar(255) NOT NULL,
  PRIMARY KEY (`tempId`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tempProjectPic`
--

LOCK TABLES `tempProjectPic` WRITE;
/*!40000 ALTER TABLE `tempProjectPic` DISABLE KEYS */;
INSERT INTO `tempProjectPic` VALUES (19,32,'1411726675.gif'),(20,16,'1411726931.gif'),(21,32,'1411726960.jpg'),(22,22,'1411986980.png'),(23,23,'1411987039.png'),(24,24,'1411987178.png'),(25,25,'1411987218.png'),(26,26,'1411987241.png'),(27,27,'1411987279.png'),(28,28,'1411987430.gif'),(29,28,'1411987449.gif'),(30,28,'1411987748.png'),(31,31,'1411989068.jpg'),(32,32,'1411988939.jpg'),(33,33,'1411989289.jpg'),(34,34,'1411989322.jpg'),(35,35,'1411989339.jpg'),(36,36,'1411990388.jpg');
/*!40000 ALTER TABLE `tempProjectPic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `userId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userType` tinyint(4) NOT NULL DEFAULT '2' COMMENT '1=Admin,2=website User',
  `loginFrom` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=userId,1=Facebook,2=Mobile',
  `firstName` varchar(30) DEFAULT NULL,
  `lastName` varchar(30) DEFAULT NULL,
  `gender` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=Unspecified,1=Male,2=Female',
  `profilePicId` smallint(6) NOT NULL COMMENT 'profilePic table Id',
  `userName` varchar(30) DEFAULT NULL,
  `email` varchar(70) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL,
  `accessToken` varchar(255) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `skill` varchar(255) DEFAULT NULL,
  `statusId` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'lookup_status table Id',
  `createdDate` datetime NOT NULL,
  `updatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone` (`phone`),
  UNIQUE KEY `userName` (`userName`)
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,1,1,'Admin','ss',1,0,NULL,'pradeep.singh@clavax.com','+91-9899327550','455760bc0a6689b8a1acb9d54c6ada1b68240e8f','1234',NULL,NULL,1,'2014-08-11 00:00:00','2014-09-23 08:52:17'),(2,1,1,'manish','kumar',1,32767,'ManishTest','manishdlbr@gmail.com','2344444444','455760bc0a6689b8a1acb9d54c6ada1b68240e8f',NULL,'1','PHP',1,'2014-08-14 16:25:03','2014-09-03 07:41:01'),(3,1,1,'manish','kumar',1,32767,'manishM','manish@clavax.us','1212121212','455760bc0a6689b8a1acb9d54c6ada1b68240e8f',NULL,'1','php',1,'2014-08-14 16:28:44','2014-09-04 10:06:05'),(44,2,0,'Clavax','Tech',1,0,NULL,'manish@clavax123.us','2222222222','455760bc0a6689b8a1acb9d54c6ada1b68240e8f',NULL,'Occupation','skill',2,'2014-08-20 16:38:12','2014-09-03 11:19:16'),(47,1,0,'Venture','App',1,20,'VenApp','abc@abc.com','7777777777','455760bc0a6689b8a1acb9d54c6ada1b68240e8f',NULL,NULL,NULL,1,'2014-08-25 19:36:37','2014-10-20 06:11:29'),(50,2,0,'Russell','Captain',1,0,'rksingh','crussell@gmail.com','12-345678901','6f40fc28835c73afc422be73e55aea1ba45fd1a3','1',NULL,NULL,1,'2014-09-01 18:37:18','2014-10-20 06:13:00'),(55,1,0,'Rajeev','kumar',1,2,'rkumar','rajeevk@clavax.us','09-888888888888','ce6bfb8674ef0252f36fa80578db8901e07efd1b',NULL,'software Engineer','Php expert',1,'2014-08-27 14:33:50','2014-10-13 05:14:50'),(58,2,0,'f','testing',0,0,'2222222','1409578137','2223334445','455760bc0a6689b8a1acb9d54c6ada1b68240e8f',NULL,NULL,NULL,1,'2014-09-01 18:58:57','2014-09-22 10:24:07'),(60,2,0,'Rock','Star',0,0,'40985229','1409579203','1113334445','455760bc0a6689b8a1acb9d54c6ada1b68240e8f',NULL,NULL,NULL,1,'2014-09-01 19:16:43','2014-09-03 07:07:35'),(62,2,0,'clavax','tech',0,0,'82368696','1409579322','1113234445','455760bc0a6689b8a1acb9d54c6ada1b68240e8f',NULL,NULL,NULL,2,'2014-09-01 19:18:42','2014-09-03 07:07:40'),(80,2,0,'asdsa','wewew',0,0,'56977773','1409655986','4817234445','455760bc0a6689b8a1acb9d54c6ada1b68240e8f',NULL,NULL,NULL,2,'2014-09-02 16:36:26','2014-09-03 06:48:39'),(83,2,0,'asdsa','wewew',0,0,'988275794','1409662840','4617234445','455760bc0a6689b8a1acb9d54c6ada1b68240e8f',NULL,NULL,NULL,1,'2014-09-02 18:30:40','2014-09-03 11:39:57'),(86,2,0,'asdsa','wewew',0,0,'nitinkpp','1409663047@abc.com','9899326550','455760bc0a6689b8a1acb9d54c6ada1b68240e8f',NULL,NULL,NULL,1,'2014-09-02 18:34:07','2014-10-28 07:00:50'),(95,1,0,'aaaaaaa','aaaaaaaa',0,0,'aaaaaaa','aaaaa11@aaa.org','1111111111','37a4ed502e3e6968bb094aebf7f1cf7034068d62',NULL,'111111','111',1,'2014-09-05 15:57:11','2014-09-05 10:27:11'),(97,2,0,'sadsad','saasdfas',0,0,'862352068','sadasas@dsfsdds.org','+090-222222','455760bc0a6689b8a1acb9d54c6ada1b68240e8f',NULL,NULL,NULL,2,'2014-09-05 18:11:09','2014-09-08 13:27:42'),(103,2,0,'sdfasd','sdfsd',0,0,'nitinkkk','1111@111.org','91-12345','8cb2237d0679ca88db6464eac60da96345513964',NULL,NULL,NULL,1,'2014-09-08 12:58:38','2014-10-28 06:18:21'),(106,2,0,'Nitin','Nitin',0,0,'nitinks','abc@abc102.com','+91-1234567892','7c4a8d09ca3762af61e59520943dc26494f8941b','3071',NULL,NULL,1,'2014-09-08 14:47:03','2014-10-28 06:18:08'),(108,2,0,'Nitin','Nitin',0,0,'556936841','1410167891','+91-123456788','7c4a8d09ca3762af61e59520943dc26494f8941b','5505',NULL,NULL,2,'2014-09-08 14:48:11','2014-09-08 09:18:11'),(109,1,0,'tttttttttttttt','ttttttttttttttt',0,0,'ttttttttttt','tttttttttttt@ttttttttttt.org','+12-43212','da5aa3efabd45533d2f699fa5411a8d55890bb42',NULL,NULL,NULL,1,'2014-09-08 17:35:57','2014-09-08 13:14:11'),(111,1,0,'sdfasdfsd','sdfasdfds',0,0,'aaaaaaasdfdsa','rksingh@gmail.com','+091-33333','f638e2789006da9bb337fd5689e37a265a70f359',NULL,NULL,NULL,1,'2014-09-08 19:00:03','2014-09-08 13:30:03'),(117,1,0,'rtesting','rtesting',0,0,'rtesting111','rtesting1@gmail.com','87-34567822','2ea6201a068c5fa0eea5d81a3863321a87f8d533',NULL,NULL,NULL,1,'2014-09-09 11:37:57','2014-09-09 06:33:34'),(120,2,0,'rrrr','Nitin',0,0,'843575932','1410244325','+91-9899326550','7c4a8d09ca3762af61e59520943dc26494f8941b','1735',NULL,NULL,2,'2014-09-09 12:02:05','2014-09-09 10:04:15'),(121,2,0,'rrrr','Nitin',0,3,'837191078','1410244390','+91-12345678832','455760bc0a6689b8a1acb9d54c6ada1b68240e8f',NULL,NULL,NULL,1,'2014-09-09 12:03:10','2014-09-09 07:31:08'),(122,1,0,'xxxxxxxxx','xxxxxxxxxxxxxxxx',0,3,'xxxxxxxxxxxxx','xxxxxxxxxx@xxxx.xxx','+91-9999999999','2acc6756e4aa393274ae109f91c4ecdf5153604d',NULL,NULL,NULL,1,'2014-09-12 16:54:01','2014-09-16 10:53:11'),(125,2,1,NULL,NULL,0,0,'1410947445','abc@abc1.com','+91-12345678','f49c75d93693fb4bd8d02e6da29705dd92155216','5555',NULL,NULL,1,'2014-09-17 15:20:45','2014-10-06 11:13:41'),(126,2,1,NULL,NULL,0,0,'1410948972','abc@abc12.com','+91-123456789','1b1ae14df4c026785379b30c6e60cc12fcd1f1ee',NULL,NULL,NULL,1,'2014-09-17 15:46:12','2014-09-17 10:16:12'),(127,2,0,'nitin','nitin',0,0,'647436876','1411110572','+1-11111111111','ce6bfb8674ef0252f36fa80578db8901e07efd1b','4018',NULL,NULL,2,'2014-09-19 12:39:33','2014-09-19 07:09:33'),(129,2,0,'nitin','nitin',0,0,'79868973','rajeev111@gmail.com','+1-111111111111','ce6bfb8674ef0252f36fa80578db8901e07efd1b','9932',NULL,NULL,1,'2014-09-19 12:40:25','2014-09-19 12:42:26'),(130,2,0,'siddartha','chowdhary',1,15,'siddarth','siddarth@gmail.com','91-9873252331','bb7a645e65a2af60559d9a06a49d97ad258cbab1',NULL,NULL,NULL,1,'0000-00-00 00:00:00','2014-10-06 07:38:06'),(136,2,0,NULL,NULL,0,0,'mike','mike@gmail.com',NULL,'$2a$10$Gnwiecf.NZtf0qdK0SVEAOnTwcKjWBWsUqkvgln22.9Chf5s8QjCO',NULL,NULL,NULL,1,'0000-00-00 00:00:00','2014-09-24 09:53:29'),(137,2,0,NULL,NULL,0,0,'john','john@gmail.com',NULL,'$2a$10$LWNH8n11QRd8D3ED0ATVMedOY2HpRrROm2vQHEy9JYpvb0g4lw8Gu',NULL,NULL,NULL,1,'0000-00-00 00:00:00','2014-09-24 09:55:45'),(138,2,0,NULL,NULL,0,0,'sonu','sonu@gmail.com',NULL,'$2a$10$tFYZHcQXUrQYyhT/52ms1uwnO5/GnbaEz7P0uIJMI.MLZon7uCLz.',NULL,NULL,NULL,1,'0000-00-00 00:00:00','2014-09-24 09:59:06'),(139,2,0,NULL,NULL,0,0,'ajay','ajay@gmail.com',NULL,'$2a$10$7djiWpiJwd5NFvrFy.Ke3O.nkPHzm6WDQiHKpsPHjBRyAIWdCu/Ly',NULL,NULL,NULL,1,'0000-00-00 00:00:00','2014-09-24 10:00:18'),(141,2,0,NULL,NULL,0,0,'sid','sid@gmail.com',NULL,'$2a$10$4pALYHstEqkghuFL8D1Df.N3fHXulm6EOXVMYEmtWTpp/oA45Mq/C',NULL,NULL,NULL,1,'0000-00-00 00:00:00','2014-09-24 10:08:40'),(142,2,0,NULL,NULL,0,0,'pradeep','pradeep@gmail.com',NULL,'$2a$10$LlfX4Mcu.AZ.qayqLBDMx.3oFsul5RWe5a0bX6GqEKsBiFa6bPHdG',NULL,NULL,NULL,1,'0000-00-00 00:00:00','2014-09-26 06:32:33'),(143,2,0,NULL,NULL,0,0,'vipin','vipin@gmail.com',NULL,'$2a$10$kWpAYH2rNO/594E1tHb1SODmvQvmqfhd.FQ90/8mGS1X.VrGrxb9e',NULL,NULL,NULL,1,'0000-00-00 00:00:00','2014-09-26 06:33:10'),(144,2,0,'ghonchu ghanta',NULL,0,38,'nitinss','nitin@gmail.com',NULL,'6f40fc28835c73afc422be73e55aea1ba45fd1a3',NULL,NULL,NULL,1,'0000-00-00 00:00:00','2014-10-01 11:23:02'),(145,2,1,NULL,'Rockers',2,0,'1411716129','iosrockers2014@gmail.com',NULL,'97fbbc7ac256376eb18edb91a5ec8b1392b28dd4',NULL,NULL,NULL,1,'2014-09-26 12:52:09','2014-09-26 07:22:09'),(146,2,1,NULL,NULL,0,0,'1411733436','skamboj@clavax.us','','14ecf1ef13a33ed9dd993d3dcaee1f677d875ccd',NULL,NULL,NULL,1,'2014-09-26 17:40:36','2014-09-29 06:26:04'),(148,1,0,'Siddarth','Chowdhary',1,0,'siddarthchowdhary','siddarthchowdhary@gmail.com','91-9873252330','bb7a645e65a2af60559d9a06a49d97ad258cbab1',NULL,NULL,NULL,1,'2014-09-30 16:04:08','2014-10-01 12:51:46'),(150,1,0,'fRK','lRK',0,36,'rksinghs','rk@gmail.com','+91-8888888888','ce6bfb8674ef0252f36fa80578db8901e07efd1b',NULL,NULL,NULL,1,'2014-10-01 12:53:25','2014-10-06 11:47:29'),(151,2,1,'sidhart','chawdhary',0,22,'1412592095','siddarth_chowdhary@yahoo.com','1412592095-1412','41d8c72590789b6ae76f70e16db5f77484906fd6',NULL,NULL,NULL,1,'2014-10-06 16:11:35','2014-10-09 07:26:09'),(152,2,1,'test','last',1,0,'testing','test@gmail.com','9873252330','','5555',NULL,NULL,2,'0000-00-00 00:00:00','2014-10-06 11:14:21');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userAddress`
--

DROP TABLE IF EXISTS `userAddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userAddress` (
  `addressId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userId` int(10) unsigned NOT NULL,
  `address` varchar(255) NOT NULL,
  `stateId` mediumint(8) unsigned NOT NULL COMMENT 'state table Id',
  `countryId` smallint(6) NOT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `latitude` decimal(11,8) DEFAULT NULL,
  PRIMARY KEY (`addressId`),
  UNIQUE KEY `userId` (`userId`,`addressId`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userAddress`
--

LOCK TABLES `userAddress` WRITE;
/*!40000 ALTER TABLE `userAddress` DISABLE KEYS */;
INSERT INTO `userAddress` VALUES (9,44,'test',1,1,NULL,NULL),(15,47,'KPS border',1,1,77.08197000,28.52136800),(20,3,'Address',2,1,85.13000000,25.37000000),(22,2,'purnia',1,1,87.46666700,25.78333300),(36,87,'aaaaaaaa',1,99,85.31311940,25.09607420),(37,88,'aaaaaaaa',1,99,85.31311940,25.09607420),(38,90,'aaaaaaaa',1,99,85.31311940,25.09607420),(39,91,'aaaaaaaa',1,99,85.31311940,25.09607420),(40,92,'aaaaaaaa',1,99,85.31311940,25.09607420),(41,93,'aaaaaaaa',1,99,85.31311940,25.09607420),(42,94,'aaaaaaaa',1,99,85.31311940,25.09607420),(43,95,'aaaaaaaa',1,99,85.31311940,25.09607420),(50,103,'11111',1,99,80.28333300,25.01666700),(58,109,'tttttttttttttttttt',1,99,85.31311940,25.09607420),(63,97,'dsfsdafsdfsdfsd',1,99,85.31311940,25.09607420),(66,111,'ewweweewew',1,99,85.31311940,25.09607420),(75,120,'',0,0,12.78900000,12.10000000),(76,121,'',0,0,12.78922222,12.13345679),(77,117,'Address',1,99,85.31311940,25.09607420),(81,122,'xxxxxxxxxxxxxxxxxxx',1,99,85.31311940,25.09607420),(85,50,'Iffco chowk gurgaon',0,1,NULL,NULL),(87,125,'',0,0,20.00000000,12.00000000),(88,126,'',0,0,NULL,NULL),(89,145,'',0,0,NULL,NULL),(90,146,'',0,0,NULL,NULL),(91,148,'Malviya Nagar',7,99,77.21088570,28.53351970),(100,130,'Test Address',0,99,NULL,NULL),(102,150,'here u r',1,99,85.31311940,25.09607420),(103,151,'test',0,2,55.27688650,25.19842490),(104,55,'727 Sector 22B, Sector 22A, Sector 19, Gurgaon, Haryana 122017',1,99,85.31311940,25.09607420);
/*!40000 ALTER TABLE `userAddress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userContact`
--

DROP TABLE IF EXISTS `userContact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userContact` (
  `contactId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `senderId` int(10) unsigned NOT NULL COMMENT 'userId of Requester',
  `receiverId` int(10) unsigned NOT NULL COMMENT 'userId Accepter',
  `statusId` tinyint(4) NOT NULL DEFAULT '8' COMMENT 'statusId from lookup_status table',
  `createdDate` datetime NOT NULL,
  `updatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`contactId`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userContact`
--

LOCK TABLES `userContact` WRITE;
/*!40000 ALTER TABLE `userContact` DISABLE KEYS */;
INSERT INTO `userContact` VALUES (6,50,103,8,'2014-09-10 17:17:08','2014-10-28 07:11:17'),(7,50,86,8,'2014-09-10 17:17:08','2014-10-28 07:11:17'),(8,121,50,8,'2014-09-11 10:58:50','2014-09-11 05:28:50'),(9,121,83,8,'2014-09-11 10:58:50','2014-09-11 05:28:50'),(20,121,47,8,'2014-09-11 14:49:33','2014-09-11 09:19:33'),(21,121,60,8,'2014-09-11 14:49:33','2014-09-11 09:19:33'),(25,55,126,8,'2014-09-22 18:40:24','2014-09-22 13:10:24'),(26,55,125,8,'2014-09-22 18:40:24','2014-09-22 13:10:24'),(27,55,86,8,'2014-09-22 18:40:24','2014-09-22 13:10:24'),(28,55,60,8,'2014-09-22 18:40:24','2014-09-22 13:10:24'),(29,55,121,8,'2014-09-22 18:40:24','2014-09-22 13:10:24'),(30,55,50,8,'2014-09-22 18:40:24','2014-09-22 13:10:24'),(31,55,47,8,'2014-09-22 18:40:24','2014-09-22 13:10:24'),(32,129,126,8,'2014-09-24 11:06:48','2014-09-24 05:36:48'),(33,130,136,8,'0000-00-00 00:00:00','2014-09-24 10:14:33'),(34,130,137,8,'0000-00-00 00:00:00','2014-09-24 10:14:33'),(35,130,138,8,'0000-00-00 00:00:00','2014-09-24 10:14:33'),(36,130,139,8,'0000-00-00 00:00:00','2014-09-24 10:14:33'),(37,130,141,8,'0000-00-00 00:00:00','2014-09-24 10:14:33'),(38,136,130,8,'0000-00-00 00:00:00','2014-09-25 12:36:26'),(39,136,137,8,'0000-00-00 00:00:00','2014-09-25 12:36:26'),(40,136,138,8,'0000-00-00 00:00:00','2014-09-25 12:36:26'),(41,136,139,8,'0000-00-00 00:00:00','2014-09-25 12:36:26'),(42,136,141,8,'0000-00-00 00:00:00','2014-09-25 12:36:26'),(43,142,130,8,'0000-00-00 00:00:00','2014-09-26 06:36:04'),(44,142,143,8,'0000-00-00 00:00:00','2014-09-26 06:36:04'),(45,142,144,8,'0000-00-00 00:00:00','2014-09-26 06:36:04'),(46,142,136,8,'0000-00-00 00:00:00','2014-09-26 06:36:04'),(47,143,130,8,'0000-00-00 00:00:00','2014-09-26 06:36:24'),(48,143,142,8,'0000-00-00 00:00:00','2014-09-26 06:36:24'),(49,143,144,8,'0000-00-00 00:00:00','2014-09-26 06:36:24'),(50,143,136,8,'0000-00-00 00:00:00','2014-09-26 06:36:24'),(51,143,130,8,'0000-00-00 00:00:00','2014-09-26 06:36:44'),(52,143,144,8,'0000-00-00 00:00:00','2014-09-26 06:36:44'),(53,144,143,8,'0000-00-00 00:00:00','2014-09-26 06:36:44'),(54,144,136,8,'0000-00-00 00:00:00','2014-09-26 06:36:44'),(55,130,142,8,'0000-00-00 00:00:00','2014-09-26 06:38:45'),(56,130,143,8,'0000-00-00 00:00:00','2014-09-26 06:38:45'),(57,130,144,8,'0000-00-00 00:00:00','2014-09-26 06:38:45'),(58,144,142,8,'0000-00-00 00:00:00','2014-09-26 06:39:31'),(59,130,47,8,'2014-10-06 15:23:09','2014-10-06 09:53:09'),(60,130,50,8,'2014-10-06 15:23:09','2014-10-06 09:53:09'),(61,151,145,8,'2014-10-17 12:09:15','2014-10-17 06:39:15'),(62,150,129,8,'2014-10-17 18:22:43','2014-10-17 12:52:43'),(63,148,151,8,'2014-10-17 18:53:41','2014-10-17 13:23:41'),(64,145,47,8,'2014-10-17 18:55:53','2014-10-17 13:25:53'),(65,150,50,8,'2014-10-20 19:13:24','2014-10-20 13:43:24');
/*!40000 ALTER TABLE `userContact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userInterest`
--

DROP TABLE IF EXISTS `userInterest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userInterest` (
  `userId` int(10) unsigned NOT NULL,
  `interest1` varchar(100) NOT NULL,
  `interest2` varchar(100) DEFAULT NULL,
  `interest3` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userInterest`
--

LOCK TABLES `userInterest` WRITE;
/*!40000 ALTER TABLE `userInterest` DISABLE KEYS */;
INSERT INTO `userInterest` VALUES (44,'my interest 1','my interest2','my interest3'),(12,'asdsds',NULL,NULL),(3,'TT',NULL,NULL),(111,'',NULL,NULL),(86,'Interest1',NULL,'interest3'),(55,'',NULL,NULL),(87,'111',NULL,NULL),(88,'111',NULL,NULL),(90,'111',NULL,NULL),(91,'111',NULL,NULL),(92,'111',NULL,NULL),(93,'111',NULL,NULL),(94,'111',NULL,NULL),(95,'111',NULL,NULL),(109,'',NULL,NULL),(50,'int1','int2',NULL),(103,'',NULL,NULL),(97,'',NULL,NULL),(117,'Watching Movies',NULL,'Playing Cricket'),(121,'int1','int2','inte3'),(122,'',NULL,NULL),(148,'',NULL,NULL),(150,'',NULL,NULL),(130,'',NULL,NULL),(151,'',NULL,NULL);
/*!40000 ALTER TABLE `userInterest` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-10-31 14:12:23
