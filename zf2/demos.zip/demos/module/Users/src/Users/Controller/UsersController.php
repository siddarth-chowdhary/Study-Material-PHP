<?php

namespace Users\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class UsersController extends AbstractActionController {
	protected $_usersTable;
	
	/* This is a index function of the module */
	public function indexAction() {
		return new ViewModel ( array (
				'users' => $this->getUsersTable ()->fetchAll () 
		) );
	}
	
	/* The following function is used to get users model object */
	public function getUsersTable() {
		if (! $this->_usersTable) {
			$sm = $this->getServiceLocator ();
			$this->_usersTable = $sm->get ( 'Users\Model\UsersTable' );
		}
		return $this->_usersTable;
	}
	
	/* The following function is used to add new records */
	public function addAction() {
		$entryForm = $this->getServiceLocator ()->get ( 'users_entry_form' );
		
		$request = $this->getRequest ();
		
		$response = $this->getResponse ();
		
		if ($request->isPost ()) {
			
			$userAdd = new \Users\Model\Entity\Users ();
			
			$entryForm->setData ( $request->getPost () );
			
			if ($entryForm->isValid ()) {
				
				$userAdd->exchangeArray ( $entryForm->getData () );
				
				if ($this->getUsersTable ()->saveUsers ( $userAdd )) {
					
					$response->setContent ( \Zend\Json\Json::encode ( array (
							'response' => false 
					) ) );
					
					return $this->redirect ()->toRoute ( 'users' );
				} else {
					
					$response->setContent ( \Zend\Json\Json::encode ( array (
							'response' => true,
							'user_id' => $user_id 
					) ) );
				}
			}
		}
		return new ViewModel ( array (
				'entryForm' => $entryForm 
		) );
	}
	
	/* The following function is used to update the records */
	public function editAction() {
		$id = ( int ) $this->params ( 'id' );
		
		if (! $id) {
			return $this->redirect ()->toRoute ( 'users' );
		}
		
		$users = $this->getUsersTable ()->getUser ( $id );
		
		$form = $this->getServiceLocator ()->get ( 'users_entry_form' );
		
		$form->bind ( $users );
		
		$form->get ( 'submit' )->setAttribute ( 'value', 'Edit' );
		
		$request = $this->getRequest ();
		
		if ($request->isPost ()) {
			
			$form->setData ( $request->getPost () );
			
			if ($form->isValid ()) {
				
				$this->getUsersTable ()->saveUsers ( $users );
				
				// Redirect to list of albums
				return $this->redirect ()->toRoute ( 'users' );
			}
		}
		return new ViewModel ( array (
				'entryForm' => $form,
				'id' => $id 
		) );
	}
	
	/* The following function is used to delete the records */
	public function deleteAction() {
		$id = ( int ) $this->params ( 'id' );
		
		if (! $id) {
			return $this->redirect ()->toRoute ( 'users' );
		} else {
			if ($this->getUsersTable ()->deleteUser ( $id )) {
				return $this->redirect ()->toRoute ( 'users' );
			}
		}
	}
}