<?php
namespace Users\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;

class UsersTable extends AbstractTableGateway {

    protected $table = 'users';

    public function __construct(Adapter $adapter) {
        $this->adapter = $adapter;
    }

    public function fetchAll() {
        $resultSet = $this->select(function (Select $select) {
                    $select->order('created ASC');
                });
        $entities = array();

        foreach ($resultSet as $row) {
            $entity = new Entity\Users();
            $entity->setId($row->id)
                    ->setName($row->name)
                    ->setCreated($row->created);
            $entities[] = $entity;
        }
        return $entities;
    }

    
    public function saveUsers($userAdd) {


        $data = array(
            'name' => $userAdd->getName(),
            'created' => $userAdd->getCreated(),
        );
		
        $id = (int) $userAdd->getId();
        
        if ($id == 0) {
            $data['created'] = date("Y-m-d H:i:s");
            if (!$this->insert($data))
                return false;
            return $this->getLastInsertValue();
        }
        elseif ($this->getUser($id)) {
            if (!$this->update($data, array('id' => $id)))
                return false;
            return $id;
        }
        else
            return false;
    }

    public function getUser($id) {
        $row = $this->select(array('id' => (int) $id))->current();
        if (!$row)
            return false;

        $users = new Entity\Users(array(
                    'id' => $row->id,
                    'name' => $row->name,
                    'created' => $row->created,
                ));
        return $users;
    }
    
    
    public function deleteUser($id)
    {
    	$objReturn = $this->delete(array('id' => $id));
    	if($objReturn) {
    		return true;
    	} else {
    		return false;
    	}
    }
}