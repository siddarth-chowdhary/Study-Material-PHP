<?php
namespace Users;

use Zend\Stdlib\Hydrator\ClassMethods;

class Module
{

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

    public function getServiceConfig() {
        return array(
	    'invokables' => array(
				'users_entity_entry' => 'Users\Entity\Entry',
         ),
         'factories' => array(
                'Users\Model\UsersTable' => function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new Model\UsersTable($dbAdapter);
                    return $table;
                },
		        'users_entry_form' => function ($sm) {
                    $form = new Form\Entry();
                    $form->setHydrator(new ClassMethods());
                    return $form;
                },
            ),
        );
    }
}
