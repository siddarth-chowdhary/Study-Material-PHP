<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Roles\Controller\Roles' => 'Roles\Controller\RolesController',
        ),
    ),
    'router' => array(
        'routes' => array(
            'roles' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/roles[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        'controller' => 'Roles\Controller\Roles',
                        'action'     => 'index',
                    ),
                ),
            ),
        ),
    ),
    
    'view_manager' => array(
        'template_path_stack' => array(
            'roles' => __DIR__ . '/../view',
        ),
    ),
);

