<?php

namespace Roles\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class RolesController extends AbstractActionController {
	protected $_rolesTable;
	
	/* This is a index function of the module */
	public function indexAction() {
		
		return new ViewModel ( array (
				'roles' => $this->getRolesTable ()->fetchAll() 
		) );
	}
	
	/* The following function is used to get users model object */
	public function getRolesTable() {
		
		if (! $this->_rolesTable) {
			$sm = $this->getServiceLocator ();
			$this->_rolesTable = $sm->get ( 'Roles\Model\RolesTable' );
		}
		return $this->_rolesTable;
	}
}