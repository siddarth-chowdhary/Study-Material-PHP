<?php
namespace Roles\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;

class RolesTable extends AbstractTableGateway {

    protected $table = 'roles';

    public function __construct(Adapter $adapter) {
        $this->adapter = $adapter;
    }

    public function fetchAll() {
        $resultSet = $this->select(function (Select $select) {
                    $select->order('created ASC');
                });
        $entities = array();

        foreach ($resultSet as $row) {
            $entity = new Entity\Roles();
            $entity->setId($row->id)
                    ->setName($row->name)
                    ->setCreated($row->created);
            $entities[] = $entity;
        }
        return $entities;
    }    
}