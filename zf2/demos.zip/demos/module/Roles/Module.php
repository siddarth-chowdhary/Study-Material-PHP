<?php
namespace Roles;

use Zend\Stdlib\Hydrator\ClassMethods;

class Module
{
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

    public function getServiceConfig() {
        return array(
	    'invokables' => array(
				'roles_entity_entry' => 'Roles\Entity\Entry',
         ),
         'factories' => array(
                'Roles\Model\RolesTable' => function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new Model\RolesTable($dbAdapter);
                    return $table;
                },
		'roles_entry_form' => function ($sm) {
                    $form = new Form\Entry();
                    $form->setHydrator(new ClassMethods());
                    return $form;
                },
            ),
        );
    }
}
