<?php

namespace Batch1\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class Batch1Controller extends AbstractActionController {
	protected $_usersTable;

	/* This is a index function of the module */
	public function indexAction() {
		return new ViewModel ( array (
				'users' => $this->getBatch1Table ()->fetchAll () 
		) );
	}


	public function getBatch1Table() {

		if (! $this->_usersTable) {
			$sm = $this->getServiceLocator ();
			$this->_usersTable = $sm->get ( 'Batch1\Model\Batch1Table' );
		}
		return $this->_usersTable;
	}

/* The following function is used to add new records */
	public function addAction() {

		$entryForm = $this->getServiceLocator ()->get ( 'batch1_entry_form' );

		$request = $this->getRequest ();
		$response = $this->getResponse ();

	if($request->isPost()) {
		$batch1Add = new \Batch1\Model\Entity\Batch1 ();
			
		$entryForm->setData ( $request->getPost () );
		if ($entryForm->isValid ()) {

		$batch1Add->exchangeArray ( $entryForm->getData () );
		
		if ($this->getBatch1Table ()->saveBatch1 ( $batch1Add )) {
			
			
			return $this->redirect ()->toRoute ( 'batch1' );
		} 
	}
	}


		return new ViewModel ( array (
				'entryForm' => $entryForm 
		) );
		
	}


public function editAction() {
die("Sdfsdfsd");
}



	
	
	
	
}

