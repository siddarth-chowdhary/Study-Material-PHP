<?php
namespace Batch1;

use Zend\Stdlib\Hydrator\ClassMethods;

class Module
{
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

public function getServiceConfig() {
        return array(
	    'invokables' => array(
				'batch1_entity_entry' => 'Batch1\Entity\Entry',
         ),
         'factories' => array(
                'Batch1\Model\Batch1Table' => function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new Model\Batch1Table($dbAdapter);
                    return $table;
                },
		 'batch1_entry_form' => function ($sm) {
                    $form = new Form\Entry();
                    $form->setHydrator(new ClassMethods());
                    return $form;
                },
            ),
        );
    }






}
