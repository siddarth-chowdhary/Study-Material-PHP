<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Batch1\Controller\Batch1' => 'Batch1\Controller\Batch1Controller',
        ),
    ),
    'router' => array(
        'routes' => array(
            'batch1' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/batch1[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        'controller' => 'Batch1\Controller\Batch1',
                        'action'     => 'index',
                    ),
                ),
            ),
        ),
    ),
    
    'view_manager' => array(
        'template_path_stack' => array(
            'batch1' => __DIR__ . '/../view',
        ),
    ),
);
