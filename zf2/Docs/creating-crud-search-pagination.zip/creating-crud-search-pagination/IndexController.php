<?php

namespace Shop\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class IndexController extends AbstractActionController
{

    public function indexAction()
    {
        $search = $this->params()->fromQuery('search', array());
        $categoryTable = $this->getServiceLocator()->get('CategoryTable');
        $paginator = $categoryTable->fetchAll(true,$search);
        $paginator->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
        $paginator->setItemCountPerPage(5);
        return new ViewModel(
            array(
                'paginator' => $paginator,
                'search' => $search
            )
        );
    }

    public function addCategoryAction()
    {
        return new ViewModel();
    }

    public function addProductAction()
    {
        return new ViewModel();
    }

    public function editCategoryAction()
    {
        return new ViewModel();
    }

    public function editProductAction()
    {
        return new ViewModel();
    }

    public function deleteCategoryAction()
    {
        return new ViewModel();
    }

    public function deleteProductAction()
    {
        return new ViewModel();
    }


}

