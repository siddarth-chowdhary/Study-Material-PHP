<?php

namespace Shop\Model;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\Sql\Sql;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

class CategoryTable extends AbstractTableGateway {

    protected $adapter;

    public function __construct(Adapter $adapter) {
        $this->adapter = $adapter;
    }
    
    public function fetchAll($paginated=false,$search=array()) {
        $select = new Select();
             
        $select->from('category')
            ->columns(array('cid' => 'id','cname' => 'name'))
            ->join('product', 'product.cId = category.id', array('id', 'name', 'price', 'description'));
            
        if (isset($search['CategoryId']) && ($search['CategoryId'] != ""))
                $select->where->like('category.id', "%" . $search['CategoryId'] . "%");            

        if (isset($search['CategoryName']) && ($search['CategoryName'] != ""))
                $select->where->like('category.name', "%" . $search['CategoryName'] . "%");

        if (isset($search['ProductId']) && ($search['ProductId'] != ""))
                $select->where->like('product.id', "%" . $search['ProductId'] . "%");

        if (isset($search['ProductName']) && ($search['ProductName'] != ""))
                $select->where->like('product.name', "%" . $search['ProductName'] . "%");

        if (isset($search['Price']) && ($search['Price'] != ""))
                $select->where->like('product.price', "%" . $search['Price'] . "%");

        if (isset($search['Description']) && ($search['Description'] != ""))
                $select->where->like('product.description', "%" . $search['Description'] . "%");

            
        $paginatorAdapter = new DbSelect($select,$this->getAdapter());

        $paginator = new Paginator($paginatorAdapter);
        return $paginator;
    }

    public function findOne($id) {
        
    }

    public function save($arrData) {
        
    }

    public function edit($arrData) {
        
    }

    public function delete($arrData) {
        
    }
    
    function object_to_array($object) {
        return (array) $object;
    }
}
