<?php
namespace Market\Factory;

use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\Mail\Transport;

class MailTransportFactory implements FactoryInterface
{
    public function createService(ServiceLocatorInterface $serviceManager)
    {
        $emailParams = $serviceManager->get('email-params');
        $options = new Transport\FileOptions(array('path' => $emailParams['email_dir']));
        $transport = new Transport\File($options);
        return $transport;
    }
}
