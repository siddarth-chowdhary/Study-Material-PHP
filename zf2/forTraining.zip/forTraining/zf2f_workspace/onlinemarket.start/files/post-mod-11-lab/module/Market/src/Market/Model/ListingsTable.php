<?php
namespace Market\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Expression;
use Market\Form\PostForm;

class ListingsTable extends TableGateway
{
	public static $tableName = 'listings';

	// SELECT * FROM `listings` WHERE `category` = ?
	public function getListingsByCategory($category = NULL)
	{
		$select = new Select();
		$select->from(self::$tableName);
		$where = new Where();
		$where->equalTo('category', $category);
		$select->where($where);
		return $this->selectWith($select);
	}
	
	// SELECT * FROM `listings` WHERE `listings_id` = ? LIMIT 1
	public function getListingById($id = 1)
	{
		$select = new Select();
		$select->from(self::$tableName);
		$where = new Where();
		$where->equalTo('listings_id', $id);
		$select->where($where);
		$select->limit(1);
		return $this->selectWith($select)->current();	
	}

	// SELECT * FROM `listings` WHERE `listings_id` IN (SELECT MAX(`listings_id`) FROM `listings`)
	public function getMostRecentListing()
	{
		$adapter = $this->getAdapter();
		$platform = $adapter->getPlatform();
		$quoteId = $platform->quoteIdentifier('listings_id');
		$select = new Select();
		$select->from(self::$tableName);
		$expression = new Expression(sprintf('MAX(%s)', $quoteId));
		$subSelect = new Select();
		$subSelect->from(self::$tableName)->columns(array($expression));
		$where = new Where();
		$where->in('listings_id', $subSelect);
		$select->where($where);
		//echo $select->getSqlString($this->getAdapter()->getPlatform());
		return $this->selectWith($select)->current();
	}

	public function addPosting($data)
	{
		// separate city and country
		$cityCountry = explode(',', PostForm::$cityCodes[$data['cityCode']]);
		$data['city'] = $cityCountry[0];
		$data['country'] = $cityCountry[1];
		// format date_expires
		$date = new \DateTime();
		$interval = '+' . $data['date_expires'] . ' day';
		$date->modify($interval);
		$data['date_expires'] = $date->format('Y-m-d H:i:s');
		// unset fields which are not in table structure
		unset($data['cityCode']);
		unset($data['captcha']);
		unset($data['submit']);
		return $this->insert($data);
	}

}