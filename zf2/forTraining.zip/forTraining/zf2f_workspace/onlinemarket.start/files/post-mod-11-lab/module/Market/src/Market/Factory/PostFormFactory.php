<?php

namespace Market\Factory;

use Market\Form\PostForm;
use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;

class PostFormFactory implements FactoryInterface
{
    public function createService(ServiceLocatorInterface $serviceManager)
    {
        $form = new PostForm();
        $categories = $serviceManager->get('categories');
        $filterCategories = array();
        foreach ($categories as $value) {
        	$filterCategories[$value] = $value;
        }
        $form->prepareElements($filterCategories);
        return $form;
    }
}
