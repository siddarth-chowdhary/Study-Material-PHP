<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Market for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Market\Controller;

use Zend\View\Model\ViewModel;
use Zend\Mvc\Controller\AbstractActionController;

class ViewController extends AbstractActionController
{
	public $listingsTable;
	
	public function indexAction()
    {
    	$categoryParam = $this->params()->fromRoute('category');
    	$listing = $this->listingsTable->getListingsByCategory($categoryParam);
    	return new ViewModel(array('categoryParam' => $categoryParam, 'listing' => $listing));
    }

    public function itemAction()
    {
    	$id = $this->params()->fromRoute('id');
    	if ($id) {
    		$item = $this->listingsTable->getListingById($id);
    		return new ViewModel(array('item' => $item));
    	} else {
    		$this->flashMessenger()->addMessage('Item Not Found');
    		return $this->redirect()->toRoute('market');
    		// alternate syntax:
    		// return $this->redirect()->toUrl('http://onlinemarket.work/');
    	}
    }

}
