<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Market for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Market\Controller;

use Zend\View\Model\ViewModel;
use Zend\Mvc\Controller\AbstractActionController;

class PostController extends AbstractActionController
{
	public $categories;
	public $postForm;
	public $postFormFilter;
	public $listingsTable;
	
    public function indexAction()
    {
    	$data = $this->params()->fromPost();
    	$this->postForm->setData($data);
    	$this->postForm->setAttribute('action', $this->url()->fromRoute('market-post'));
    	$this->postForm->setAttribute('method', 'POST');
    	$viewModel = new ViewModel(array('categories' => $this->categories, 'postForm' => $this->postForm, 'data' => $data));
    	$viewModel->setTemplate('market/post/index.phtml');
    	$returnViewModel = $viewModel;
    	if (isset($data['submit']) && $data['submit']) {
    		$this->postForm->setInputFilter($this->postFormFilter);
    		$this->postForm->setData($data);
    		if ($this->postForm->isValid()) {
    			// save to database
    			if ($this->listingsTable->addPosting($this->postFormFilter->getValues())) {
    				$this->flashMessenger()->addMessage('Your Item Has Been Posted!');
    			} else {
    				$this->flashMessenger()->addMessage('SORRY! Unable to Post.');
    			}
    			return $this->redirect()->toRoute('home');
    		} else {
    			// set alternate view model
		    	// save invalid view module to be rendered in later lab if form data is invalid
		    	$invalidViewModel = new ViewModel();
		    	$invalidViewModel->setTemplate('market/post/invalid.phtml');
		    	$invalidViewModel->addChild($viewModel, 'main');
    			$returnViewModel = $invalidViewModel;
    		}
    	}
    	
        return $returnViewModel;
    }

}

