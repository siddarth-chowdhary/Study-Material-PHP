<?php

//filename : module/Users/src/Users/Form/UploadForm.php

namespace Users\Form;

use Zend\Form\Form;

class UploadForm extends Form 
{
	public function __construct($name = null)
	{
		//initializing the form and seeting form properties
		parent::__construct('Upload');
		$this->setAttribute('method','post');
		$this->setAttribute('enctype','multipart/form-data');

		//adding fields to register form
		$this->add(array(
            'name' => 'user_id',
            'attributes' => array(
                'type' => 'hidden',
            ),
        ));

		//adding fields to Upload form
		$this->add(array(
			'name' => 'filedescription',
			'attributes' => array(
				'type' => 'text',
			),
			'options' => array(
				'label' => 'File Description',
			),
		));

		//file control in upload form added here
		$this->add(array(
			'name' => 'fileupload',
			'attributes' => array(
				'type' => 'file',
			),
			'options' => array(
				'label' => 'File To Upload',
			),
		));

		$this->add(array(
			'name' => 'submit',
			'attributes' => array(
				'type' => 'submit',
				'value' => 'Upload',
			),
		));

	}
} 
