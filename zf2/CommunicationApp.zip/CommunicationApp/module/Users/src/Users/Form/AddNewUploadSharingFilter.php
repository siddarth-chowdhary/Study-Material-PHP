<?php

namespace Users\Form;
use Zend\InputFilter\InputFilter;

class AddNewUploadSharingFilter extends InputFilter
{
	public function __construct()
	{

		
		
	}

}
