<?php


namespace Users\Form;

use Zend\Form\Form;

class AddNewUploadSharingForm extends Form 
{
	public function __construct($name = null)
	{
		parent::__construct('AddNewUploadSharing');
		$this->setAttribute('method','post');
		$this->setAttribute('enctype','multipart/form-data');

		$this->add(array( 
            'name' => 'uploadId', 
            'type' => 'Zend\Form\Element\Hidden', 
            'attributes' => array( 
            ), 
            'options' => array( 
                'label' => 'undefined', 
            ), 
        )); 
		

		/*
		* @desc - DROPDOWN With values from the database.
		* values are set in the controller.
		*/ 
        $this->add(array( 
            'name' => 'SelectUser', 
            'type' => 'Zend\Form\Element\Select', 
            'attributes' => array( 
                'required' => 'required', 
            ), 
            'options' => array( 
                'label' => 'Select User', 
                'empty_option'  => '--- please choose ---'
            ), 
        )); 

		$this->add(array(
			'name' => 'submit',
			'attributes' => array(
				'type' => 'submit',
				'value' => 'submit',
			),
		));

	}
} 
