<?php

namespace Users\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as DbTableAuthAdapter;

// use Users\Form\LoginForm;
// use Users\Form\LoginFilter;


class LoginController extends AbstractActionController
{
	private $authservice;
	/*
	* @desc - created a form instance and then returned it to the view
	*/
	public function indexAction() 
	{
		$form = $this->getServiceLocator()->get('LoginForm');
		$viewModel= new ViewModel(array('form' => $form	));
		return $viewModel;
	}
	
	public function confirmAction()
	{
		$user_email = $this->getAuthService()->getStorage()->read();
		$viewModel = new ViewModel(array(
				'user_email' => $user_email
			));
		return $viewModel;
	}

	public function getAuthService()
	{
		if (! $this->authservice) {
			$dbAdapter = $this->getServiceLocator()->get('Zend\Db\Adapter\Adapter');
			$dbTableAuthAdapter = new DbTableAuthAdapter($dbAdapter,'user','email','password','MD5(?)');
			$authService = new AuthenticationService();
			$authService->setAdapter($dbTableAuthAdapter);
			$this->authservice = $authService;
		}
		return $this->authservice;
	}

	public function processAction()
	{
		#1st condition check - form data is not post
		if (!$this->request->isPost()) {
			return $this->redirect()->toRoute(NULL,array(
			'controller'=>'login',
			'action' => 'index'
			));
		}
		
		$post = $this->request->getPost();
		$form = $this->getServiceLocator()->get('LoginForm');
		
		$inputFilter = $this->getServiceLocator()->get('LoginFilter');
		$form->setInputFilter($inputFilter);
		$form->setData($post);
		
		#2nd condition input validations failed
		if (!$form->isValid()) {
			$model = new ViewModel(array(
				'error' => true,
				'form' => $form,
			));
			$model->setTemplate('users/login/index');
			return $model;
		}

		#3rd  - everything ok, called getAuthService() which helped in checking values in db and 
		# if result is an object the page is redirected to confirm.
		$this->getAuthService()->getAdapter()->setIdentity($this->request->getPost('email'))
											->setCredential($this->request->getPost('password'));
		$result = $this->getAuthService()->authenticate();
		if ($result->isValid()) {
			$this->getAuthService()->getStorage()->write($this->request->getPost('email'));
			return $this->redirect()->toRoute(NULL,array(
				'controller' => 'login',
				'action' =>	'confirm'
			));	
		} else {
			die("login fail,make a page for it");
		}
	}
}
