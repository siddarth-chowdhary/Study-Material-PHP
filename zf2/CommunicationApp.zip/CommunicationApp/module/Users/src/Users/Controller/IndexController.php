<?php

namespace Users\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;


class IndexController extends AbstractActionController
{
	public function indexAction(){
		$view = new ViewModel();
		return $view;
	}

	public function registerAction(){
		$view = new ViewModel();
		//we will create a corresponding view file named new-user
		$view->setTemplate('users/index/new-user');
		return $view;
	}

	public function loginAction(){
		$view = new ViewModel();
		// we will create a corresponding view file namelogin 
		$view->setTemplate('users/index/login');
		return $view;
	}
}
