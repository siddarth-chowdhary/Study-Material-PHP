<?php

namespace Users\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;



use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as DbTableAuthAdapter;

use Zend\Session\Container;

/*
* Used Service Locator in the actions so we dont need to include the model/form/filter/authentication/etc files.
* It makes it easy to use and a central place from where we invoke our services.
*/
class UploadManagerController extends AbstractActionController
{
	private $authservice;

	public function indexAction() 
	{
		$uploadTable 	= 	$this->getServiceLocator()->get('UploadTable');
		$userTable 		=	$this->getServiceLocator()->get('UserTable');
		//get user information from session
		$userEmail  	= 	$this->getAuthService()->getStorage()->read();
		if ($userEmail === NULL) {
			#user is not logged in
			$viewModel 		=	new ViewModel(array(
								'signIn'  	=> 		true,
							));
			return $viewModel;	
		}
		$user 			=	$userTable->getUserById($userEmail);
		$viewModel 		=	new ViewModel(array(
								'myUploads'  	=> 		$uploadTable->getUploadsByUserId($user->id),
							));
		return $viewModel;
	}

	/*
	* for session , get user related information from session.
	*/
	public function getAuthService()
	{
		if (! $this->authservice) {
			$dbAdapter = $this->getServiceLocator()->get('Zend\Db\Adapter\Adapter');
			$dbTableAuthAdapter = new DbTableAuthAdapter($dbAdapter,'user','email','password','MD5(?)');
			$authService = new AuthenticationService();
			$authService->setAdapter($dbTableAuthAdapter);
			$this->authservice = $authService;
		}
		return $this->authservice;
	}

	public function uploadAction()
	{
		$form = $this->getServiceLocator()->get('UploadForm');
		$viewModel = new ViewModel(array('form' => $form));
		return $viewModel;
	}

	public function processAction()
	{
		if ($this->request->isPost()) {

			$post = $this->request->getPost();
			$form = $this->getServiceLocator()->get('UploadForm');
			$inputFilter = $this->getServiceLocator()->get('UploadFilter');
			$form->setInputFilter($inputFilter);
			$form->setData($post);

			#file thatis uploaded with details
			$uploadFile 	=	$this->params()->fromFiles('fileupload');

			if ($form->isValid()) {
				#fetch the configuration for loaction to upload the file
				$uploadPath 	= 	$this->getFileUploadLocation();
				#save file 
				$adapter 	=	new \Zend\File\Transfer\Adapter\Http();
				$adapter->setDestination($uploadPath);

				if ($adapter->receive($uploadFile['name'])) {
					#file upload successfull
					$uploadTable 	= 	$this->getServiceLocator()->get('UploadTable');
					$userTable 		=	$this->getServiceLocator()->get('UserTable');
					
					#get user information from session for user id
					$userEmail  	= 	$this->getAuthService()->getStorage()->read();
					$user 			=	$userTable->getUserById($userEmail);
					
					$exchange_data 				=	array();
					$exchange_data['label']		=	$post['filedescription'];
					$exchange_data['filename']	=	$uploadFile['name'];
					$exchange_data['user_id']	=	$user->id;

					$upload = ''; #will hold the upload model object
					$upload = $this->getServiceLocator()->get('UploadEntity');
					
					#saving the data realated to file upload in database
					$upload->exchangeArray($exchange_data);
					$uploadTable 	= 	$this->getServiceLocator()->get('UploadTable');
					$uploadTable->saveUpload($upload);

					#redirecting to file listing
					return $this->redirect()->toRoute('upload-manager');	
				}
			} else {
				$model = new ViewModel(array(
					'error' => true,
					'form' => $form,
				));
				$model->setTemplate('user-manager');
				return $model;
			}
		} 
	}

		
	/*
	* @date created - 17 May 2014
	* @desc - created for location of files where the files will be uploaded
	*/
	public function getFileUploadLocation() {
		$config		=	$this->getServiceLocator()->get('config');
		return $config['module_config']['upload_location'];
	}	
	
	public function deleteAction()
	{
		die("delete from db and file system");
		#delete from db
		$this->getServiceLocator()->get('UploadTable')->deleteUpload($this->params()->fromRoute('id'));
		#delete from file system
		//use unlink fn first get the file name frm db then delete
		return $this->redirect()->toRoute('upload-manager');
	}

	public function editAction()
	{
		$userTable 				=	$this->getServiceLocator()->get('UserTable');
		$uploadTable 			= 	$this->getServiceLocator()->get('UploadTable');
		$sharedUploads 			=	$uploadTable->getSharedUsers($this->params()->fromRoute('id'));
		$fileSharedWithUsers 	= 	array();
		$i 						= 	0;
		$usersListResult		=	array();
		$usersList 				=	array();
		$uploadId 				=	$this->params()->fromRoute('id');

		#set the uploadId in session
		$session 				= new Container('uploadIdInSession');
		$session->upload_id 	= $uploadId;

		$file 					= 	'';
		$file 					= 	$uploadTable->getUpload($uploadId);	
		
		#create an array for particular file shared with other users.
		foreach ($sharedUploads as $upload) {
			$user = '';
			$user = $userTable->getUser($upload->user_id);
			$fileSharedWithUsers[$i]['user_name'] 	= 	$user->name;
			$i++;
		}

		$usersListResult		=	$userTable->fetchAll();
		foreach ($usersListResult as $key => $value) {
			$usersList[$value->id]	=	$value->name;
		}

		$form = $this->getServiceLocator()->get('AddNewUploadSharingForm');
		#set the dropdown values here
		$form->get('SelectUser')->setAttributes(array(
	        'options' => $usersList,   
	    ));
	    #set the hidden values here
	    $form->get('uploadId')->setAttributes(array(
	        'value'	=>	$uploadId,
	    ));

		#if there is no file sharing
		if ($i == 0) {
			$viewModel 		=	new ViewModel(array(
							'empty'				=> 		true,
							'upload_name'		=> 		$file->label,
							'form'				=>		$form,
						));
			return $viewModel;	
		}
		#files shared with some users
		$viewModel 		=	new ViewModel(array(
								'upload_name'				=> 		$file->label,
								'sharedUploadsWithUsers'  	=> 		$fileSharedWithUsers,
								'form'						=>		$form,
							));
		return $viewModel;
	}

	public function workAction()
	{
		if ($this->request->isPost()) {
			$post = $this->request->getPost();
			$form = $this->getServiceLocator()->get('AddNewUploadSharingForm');
			
			$userTable 				=	$this->getServiceLocator()->get('UserTable');
			$uploadTable 			= 	$this->getServiceLocator()->get('UploadTable');

			$usersListResult		= 	array();
			$usersList 				= 	array();
			$usersListResult		=	$userTable->fetchAll();
			foreach ($usersListResult as $key => $value) {
				$usersList[$value->id]	=	$value->name;
			}

			#get the uploadId from session
			$session 				= 	new Container('uploadIdInSession');
			$uploadId 				= 	$session->upload_id;

			#set the dropdown values here
			$form->get('SelectUser')->setAttributes(array(
		        'options' => $usersList,   
		    ));
		    #set the hidden values here
		    $form->get('uploadId')->setAttributes(array(
		        'value'	=>	$uploadId,
		    ));
			$inputFilter = $this->getServiceLocator()->get('AddNewUploadSharingFilter');
			$form->setInputFilter($inputFilter);
			$form->setData($post);
			
			if ($form->isValid()) {
					$uploadTable->addSharing($post->uploadId,$post->SelectUser);
					#redirecting edit pade with listing of that upload
					return $this->redirect()->toRoute('upload-manager',
					array('action' => 'edit','id' => $uploadId));
				}
		} else {
			$model = new ViewModel(array(
				'error' => true,
				'form' => $form,
			));
			$model->setTemplate('upload-manager');
			return $model;
		}
	} 
	
	// public function addAction()
	// {

	// }
	
}
