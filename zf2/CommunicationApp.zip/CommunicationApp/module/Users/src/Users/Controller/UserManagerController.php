<?php

namespace Users\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

/*
* Used Service Locator in the actions so we dont need to include the model/form/filter/authentication/etc files.
* It makes it easy to use and a central place from where we invoke our services.
*/
class UserManagerController extends AbstractActionController
{

	
	public function indexAction() 
	{
		$userTable 	=	$this->getServiceLocator()->get('UserTable');
		$viewModel 	= 	new ViewModel(array('users'=>$userTable->fetchAll()));
		return $viewModel;
	}

	/*
	* @desc - this function will be used to show a form in the edit view.
	* if ($this->request->isPost()) { - this section works when the the user has made some changes in the edit
	* view of the form and clicked ok other wise the form is opened withe the data. 
	*/
	public function editAction()
	{
		if ($this->request->isPost()) {
			$post = $this->request->getPost();
			$form = $this->getServiceLocator()->get('UserEditForm');
			$inputFilter = $this->getServiceLocator()->get('UserEditFilter');
			$form->setInputFilter($inputFilter);
			$form->setData($post);
			/*
			* @desc - save the data if the validations pass using the filter.
			* then using a hydrator object achieved with exchangeArray()
			              ----------------------------------------------
			* then we save the values in the model.
			*/
			if ($form->isValid()) {
				$user = ''; #will hold the user model object
				$user = $this->getServiceLocator()->get('UserEntity');
				$user->exchangeArray($form->getData());
				$this->getServiceLocator()->get('UserTable')->saveUser($user);
				return $this->redirect()->toRoute('user-manager');
			}
			die("form is not valid");
		}
		$userTable 	= 	$this->getServiceLocator()->get('UserTable');
		$user 		=	$userTable->getUser($this->params()->fromRoute('id'));
		$form 		=	$this->getServiceLocator()->get('UserEditForm');
		$form->bind($user);
		$viewModel 	=	new ViewModel(
						array(
							'form' 		=>	$form,
							'user_id'	=>	$this->params()->fromRoute('id'),
						)
					);
		return $viewModel;		
	}

	public function processAction()
	{

		//get user id from post
		$post 		= 	$this->request->getPost();
		
		$userTable	= 	$this->getServiceLocator()->get('UserTable');
		
		//load user entity
		$user 		= 	$userTable->getUser($post->id);
		//bind user entity to form
		$form 		= 	$this->getServiceLocator()->get('UserEditForm');
		$form->bind($user);
		$form->setData($post);

		//save user
		$this->getServiceLocator()->get('UserTable')->saveUser($user);
		return $this->redirect()->toRoute('user-manager');
	}	
	
	public function deleteAction()
	{
		$this->getServiceLocator()->get('UserTable')->deleteUser($this->params()->fromRoute('id'));
		return $this->redirect()->toRoute('user-manager');
	}

	public function addAction()
	{
		if ($this->request->isPost()) {
			$post = $this->request->getPost();
			$form = $this->getServiceLocator()->get('RegisterForm');
			$inputFilter = $this->getServiceLocator()->get('RegisterFilter');
			$form->setInputFilter($inputFilter);
			$form->setData($post);
			/*
			* @desc - save the data if the validations pass using the filter.
			* then using a hydrator object achieved with exchangeArray()
			              ----------------------------------------------
			* then we save the values in the model.
			*/
			if ($form->isValid()) {
				$user = ''; #will hold the user model object
				$user = $this->getServiceLocator()->get('UserEntity');
				$user->exchangeArray($form->getData());
				$this->getServiceLocator()->get('UserTable')->saveUser($user);
				return $this->redirect()->toRoute('user-manager');
			} else {
				$model = new ViewModel(array(
					'error' => true,
					'form' => $form,
				));
				$model->setTemplate('users/user-manager/add');
				return $model;
			}
		}
		$form = $this->getServiceLocator()->get('RegisterForm');
		$viewModel = new ViewModel(array('form' => $form));
		return $viewModel;
	}
	
}
