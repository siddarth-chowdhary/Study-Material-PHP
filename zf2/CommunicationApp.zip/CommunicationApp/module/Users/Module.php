<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonModule for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Users;

use Zend\ModuleManager\Feature\AutoloaderProviderInterface;
use Zend\Mvc\ModuleRouteListener;
use Zend\Mvc\MvcEvent;


/*added on 21 April 2014*/
use Users\Model\User;
use Users\Model\UserTable;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;
/*till here*/

/*added on 11 May 2014*/
use Users\Model\Upload;
use Users\Model\UploadTable;
/*till here*/


class Module implements AutoloaderProviderInterface
{
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
		    // if we're in a namespace deeper than one level we need to fix the \ in the path
                    __NAMESPACE__ => __DIR__ . '/src/' . str_replace('\\', '/' , __NAMESPACE__),
                ),
            ),
        );
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function onBootstrap(MvcEvent $e)
    {
        // You may not need to do this if you're doing it elsewhere in your
        // application
        $eventManager        = $e->getApplication()->getEventManager();
        $moduleRouteListener = new ModuleRouteListener();
        $moduleRouteListener->attach($eventManager);
    }
	
    /*
    * @date_created  - 21 April 2014
    * @date_modified - 21 April 2014
    * @desc - module level configuration of service manager will be stored in this function.
    */
    public function getServiceConfig() {
	return array(
		'abstract_factories'	=>	array(),
		'aliases' 		=>	array(),
		'factories'		=>	array(
			//Database Configuration
			'UserTable'	=>	function($sm) {
				$tableGateway	= $sm->get('UserTableGateway');
				$table = new UserTable($tableGateway);
				return $table;
			},
			
			'UserTableGateway'	=>	function($sm) {
				$dbAdapter	=	$sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype	= 	new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new User());
				return new TableGateway('user',$dbAdapter,null,$resultSetPrototype);
			},

			'UploadTable'	=>	function($sm) {
				$tableGateway				= $sm->get('UploadTableGateway');
				$uploadSharingTableGateway	= $sm->get('UploadSharingTableGateway');
				$table = new UploadTable($tableGateway,$uploadSharingTableGateway);
				return $table;
			},
			
			'UploadTableGateway'	=>	function($sm) {
				$dbAdapter	=	$sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype	= 	new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new Upload());
				return new TableGateway('uploads',$dbAdapter,null,$resultSetPrototype);
			},

			'UploadSharingTableGateway'	=>	function($sm) {
				$dbAdapter	=	$sm->get('Zend\Db\Adapter\Adapter');
				return new TableGateway('uploads_sharing',$dbAdapter);
			},

			//Entities
			'UserEntity'=>	function($sm) {
				return new \Users\Model\User();
			},
			'UploadEntity'=>	function($sm) {
				return new \Users\Model\Upload();
			},

			
			//Forms
			'LoginForm'	=>	function($sm) {
				$form	=	new \Users\Form\LoginForm();
				$form->setInputFilter($sm->get('LoginFilter'));
				return $form;
			},
			'RegisterForm'	=> function($sm) {
				$form	= new \Users\Form\RegisterForm();
				$form->setInputFilter($sm->get('RegisterFilter'));
				return $form;
			},
			'UserEditForm'	=> function($sm) {
				$form	= new \Users\Form\UserEditForm();
				$form->setInputFilter($sm->get('UserEditFilter'));
				return $form;
			},
			'UploadForm'	=> function($sm) {
				$form	= new \Users\Form\UploadForm();
				$form->setInputFilter($sm->get('UploadFilter'));
				return $form;
			},
			'AddNewUploadSharingForm'	=> function($sm) {
				$form	= new \Users\Form\AddNewUploadSharingForm();
				$form->setInputFilter($sm->get('AddNewUploadSharingFilter'));
				return $form;
			},			

			//Filters
			'LoginFilter'	=>	function($sm) {
				return new \Users\Form\LoginFilter();
			},
			'RegisterFilter'	=>	function($sm) {
				return new \Users\Form\RegisterFilter();
			},
			'UserEditFilter'	=>	function($sm) {
				return new \Users\Form\UserEditFilter();
			},
			'UploadFilter'	=>	function($sm) {
				return new \Users\Form\UploadFilter();
			},
			'AddNewUploadSharingFilter'	=>	function($sm) {
				return new \Users\Form\AddNewUploadSharingFilter();
			},
		),
		'invokables'		=>	array(),
		'services'		=>	array(),
		'shared'		=>	array(),
	);
}

	
}
