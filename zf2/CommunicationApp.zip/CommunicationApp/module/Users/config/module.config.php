<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Users\Controller\Index'           => 'Users\Controller\IndexController',
    	    'Users\Controller\Register'        => 'Users\Controller\RegisterController',
    	    'Users\Controller\Login'           => 'Users\Controller\LoginController',
	        'Users\Controller\UserManager'     => 'Users\Controller\UserManagerController',
            'Users\Controller\UploadManager'   => 'Users\Controller\UploadManagerController',
        ),
    ),
    'router' => array(
        'routes' => array(
            'home' => array(
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array(
                    'route'    => '/',
                    'defaults' => array(
                        'controller' => 'Users\Controller\Index',
                        'action'     => 'index',
                    ),
                ),
            ),
            'users' => array(
                'type'    => 'Literal',
                'options' => array(
                    // Change this to something specific to your module
                    'route'    => '/users',
                    'defaults' => array(
                        // Change this value to reflect the namespace in which
                        // the controllers for your module are found
                        '__NAMESPACE__' => 'Users\Controller',
                        'controller'    => 'Index',
                        'action'        => 'index',
                    ),
                ),
            ),
            'login' => array (
                'type'  =>  'Segment',
                'options'   =>  array(
                    'route'     =>  '/login[/:action][/:id]',
                    'constraints'   =>  array(
                        'action'    =>  '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'        =>  '[a-zA-Z0-9_-]*',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Users\Controller',
                        'controller'    => 'Login',
                        'action'        => 'index',
                    ),
                ),                    
            ),
            'register' => array (
                'type'  =>  'Segment',
                'options'   =>  array(
                    'route'     =>  '/register[/:action][/:id]',
                    'constraints'   =>  array(
                        'action'    =>  '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'        =>  '[a-zA-Z0-9_-]*',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Users\Controller',
                        'controller'    => 'Register',
                        'action'        => 'index',
                    ),
                ),                    
            ),
		    'user-manager' => array(
			    'type' 		=> 'Segment',
			    'options'	=> array(
    				'route' 	=>	'/user-manager[/:action][/:id]',
    				'constraints'	=> 	array(
    					'action'	=> 	'[a-zA-Z][a-zA-Z0-9_-]*',
    					'id'		=> 	'[a-zA-Z0-9_-]*',
    				),
    				'defaults' => array(
                            '__NAMESPACE__' => 'Users\Controller',
                            'controller' => 'Users\Controller\UserManager',
                            'action'     => 'index',
                    ),
			    ),
		    ),
            'upload-manager' => array(
                'type'      => 'Segment',
                'options'   => array(
                    'route'     =>  '/upload-manager[/:action][/:id]',
                    'constraints'   =>  array(
                        'action'    =>  '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'        =>  '[a-zA-Z0-9_-]*',
                    ),
                    'defaults' => array(
                            '__NAMESPACE__' => 'Users\Controller',
                            'controller' => 'Users\Controller\UploadManager',
                            'action'     => 'index',
                    ),
                ),
            ),
        ),
    ),
    
    'service_manager' => array(
        'abstract_factories' => array(
            'Zend\Cache\Service\StorageCacheAbstractServiceFactory',
            'Zend\Log\LoggerAbstractServiceFactory',
        ),
        'aliases' => array(
            'translator' => 'MvcTranslator',
        ),
    ),
    'translator' => array(
        'locale' => 'en_US',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
    
    'view_manager' => array(
        'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'layout/layout'           => __DIR__ . '/../view/layout/layout.phtml',
            'error/404'               => __DIR__ . '/../view/error/404.phtml',
            'error/index'             => __DIR__ . '/../view/error/index.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
    // Placeholder for console routes
    'console' => array(
        'router' => array(
            'routes' => array(
            ),
        ),
    ),

    //MODULE CONFIURATIONS - ADDED ON May 11 2014 for File Upload Location
    'module_config'     =>  array(
        'upload_location'   =>  __DIR__.'/../data/uploads',
    ),
);
