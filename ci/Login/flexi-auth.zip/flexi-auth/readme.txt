flexi auth : a user authentication library for Codeigniter.

Read a list of features available from the flexi auth library.
http://haseydesign.com/flexi-auth/auth_lite/features

To get started with using the library, read the installation guide.
http://haseydesign.com/flexi-auth/user_guide/installation

flexi auth Concept: http://haseydesign.com/flexi-auth/user_guide/concept/
Library Overview: http://haseydesign.com/flexi-auth/
Library Demo: http://haseydesign.com/flexi-auth/auth_lite/demo/
Library User Guide: http://haseydesign.com/flexi-auth/user_guide/

Support : http://ellislab.com/forums/viewthread/224351/