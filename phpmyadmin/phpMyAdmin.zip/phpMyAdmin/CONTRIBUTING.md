# Contributing to phpMyAdmin

As an open source project, phpMyAdmin welcomes contributions of many forms.

## Bug reporting

Please report [bugs on SourceForge.net][1]. 

[1]: https://sourceforge.net/p/phpmyadmin/bugs/new/

## Patches submission

Patches are welcome either as [pull requests on GitHub][2].

[2]: https://github.com/phpmyadmin/phpmyadmin/pulls

## More information

You can find more information on our website:

http://www.phpmyadmin.net/home_page/improve.php
