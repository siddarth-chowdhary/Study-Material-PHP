<?php
ini_set('display_errors', '1');
include "../FluentPDO/FluentPDO.php";
/*connect to the database*/
$pdo = new PDO("mysql:dbname=fblog", "root", "root");
$fpdo = new FluentPDO($pdo);


/*SELECT user.* FROM user WHERE id > ? AND name = ? ORDER BY name*/
$query = $fpdo->from('user')->where('id > ?', 0)->orderBy('name');
$query = $query->where('name = ?', 'Marek');
echo $query->getQuery() . "\n";
p($query->getParameters());
p($query->fetch());


/*see all tests all the queries are defined there*/
function p($data) {
	echo "<pre>";
	print_r($data);
}
