<table>
<tr> <th>Name</th><th>Email</th><th>Addess</th><th>Action</th>
<?php
foreach($student_data as $student) {
?>
<tr>
<td><?php if(isset($student->st_name)) {echo $student->st_name;} ?></td>
<td><?php if(isset($student->st_email)) {echo $student->st_email;} ?></td>
<td><?php if(isset($student->st_address)) {echo $student->st_address;} ?></td>
<td><a href='?q=admin/student/add/<?php echo  $student->st_id;?>'>Edit</a>  <a href='?q=admin/student/delete/<?php echo  $student->st_id;?>'>Delete</a> </td>
</tr>

<?php } ?>
</table>
