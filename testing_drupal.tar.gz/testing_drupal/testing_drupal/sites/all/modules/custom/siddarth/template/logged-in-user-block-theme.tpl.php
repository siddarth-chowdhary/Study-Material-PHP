<?php

echo 'this output is coming from logged-in-user-block-theme.tpl.php file';

//print "<pre>";
//print_r($user_details);
//die;

?>
<ul>
	<li>
	Name: <?php if (isset($user_details->name)) {echo  $user_details->name;} ?>
	</li>
	<li>
	Email: <?php if (isset($user_details->mail)) {echo  $user_details->mail;} ?>
	</li>
</ul>
