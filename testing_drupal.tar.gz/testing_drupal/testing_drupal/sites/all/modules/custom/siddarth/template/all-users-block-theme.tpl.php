<?php
echo 'this output is coming from all-users-block-theme.tpl.php file';
//~ echo '<ul>';
//~ print_r($user_details);die;

//~ foreach ($user_details as $val) {
	//~ echo '<li>'.$val->name.'</li>';
//~ }
//~ echo '</ul>';

/*is loop se humne view generate kara h jisko div me class bana di h
 * and fir content show hoga accordingly jo particular block me jaega jaha ye cal hua h
 * */
foreach ($user_details as $users) {
?>
<div class ="user-listing-section">
	<div class="user-listing-image">
		<a href="?q=user/<?php echo $users->uid ?>">
		<img src="<?php 
		if (isset($users->picture->uri)) {
		echo image_style_url('block_listing',$users->picture->uri);
		}
		?>">
		</a>
	</div>
	<div class="user-listing-name">
		<?php 
		if (isset($users->name)) {
		echo $users->name; 
	}
		?>
	</div>
</div>
<?php
}
?>
